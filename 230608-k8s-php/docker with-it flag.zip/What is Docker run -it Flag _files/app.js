!function(){"use strict";const e=new class{constructor(){this.listeners=new Map,this.counter=0}subscribe(e,t){var i;return this.listeners.has(e)||this.listeners.set(e,new Map),null===(i=this.listeners.get(e))||void 0===i||i.set(++this.counter,t),this.counter}unsubscribe(e,t){const i=this.listeners.get(e);return!!i&&i.delete(t)}async dispatch(e,t){const i=this.listeners.get(e);i&&i.forEach((async i=>{try{await i(t,e)}catch(e){console.error(e)}}))}};var t;!function(e){e.phone="phone",e.tablet="tablet",e.desktop="desktop",e.unknown="unknown"}(t||(t={}));const i="slickssotoken";const s=new Map([["search","Search"],["loading","loading..."],["offline","Offline"],["favorites","Favorites"],["cancel","Cancel"],["my-favorite-pages","My Favorite Pages"],["related","Related"],["popular","Popular"],["latest","Latest"],["no-matches-found","No matches found"],["search-text","search text"],["favorite-added","Added to Favorites"],["forgot-password","Forgot password?"],["reset-code","Reset code"],["password","Password"],["sign-in","Sign in"],["sign-up","Sign up"],["submit","Submit"],["your-name","Your name"],["your-email","Your email"],["sign-out","Sign out"],["reset-password","Reset password"],["default-mandatory-favorites-cta","To use favorites, sign in.  We will synchronize your favorites across all of your devices."],["default-optional-favorites-cta","We save your favorites within your browser.  To ensure they are not lost and to synchronize them between devices, enter your email address."],["favorites-sign-in-cta","Enter your password to sign into your account."],["favorites-sign-up-cta","Enter your name and password to create your account."],["favorites-reset-password-cta","Enter your email address and we will send you an email to reset your password."],["favorites-reset-password-code-cta","Check your email for a message containing a confirmation code.  Enter it here along with a new password."],["notify-about-content","Notify me about new content"],["favorites-panel-optional-cta","Protect your favorites"],["favorites-panel-sign-in-button","Sign in"],["favorites-panel-mandatory-no-favorites","Create a collection of your favorites and synchronize them between devices.  Click on a heart anywhere to add to your list."],["favorites-panel-optional-no-favorites","Create a collection of your favorites.  Click on a heart anywhere to add to your list."],["more-results","More results"],["top-results","Top results"],["categories","Categories"],["searching-in","Searching in"],["my-views","My Visited Pages"],["ingredients","Ingredients"],["ingredient-search-placeholder","Enter comma-separated ingredients"],["notify-about-content-and-personalize","Notify me about new content and personalize my ads"],["prompt-to-sign-in","Saved to Favorites! Sign in to ensure your favorites are not lost."],["prompt-to-sign-in-short","Sign in to ensure your favorites are not lost"],["remove-favorite","Remove from Favorites"],["favorite-removed","Removed from Favorites"],["search4-top-pages","Top Pages"],["search4-pages","Pages"],["search4-top-stories","Top Stories"],["search4-stories","Stories"],["search4-favorite-pages","Favorite Pages"],["search4-my-favorite-stories","My Favorite Stories"],["search4-favorite-stories","Favorite Stories"],["search4-using-these-ingredients","Using These Ingredients"],["search4-using-ingredients","Ingredients"],["search4-my-viewing-history","Recently Viewed"],["search4-my-views","Recently Viewed"],["search4-featured","Featured"],["search4-my-favorites","My Favorites"],["search4-videos","Videos"],["search4-explore","Explore"],["more","More"],["undo","Undo"],["view","View"],["show-all","Show all"],["documents","Documents"],["check-email-for-reset-password","Check your email for a message containing a link to reset your password"],["enter-new-password","Enter your new password"],["exclusive-content-sign-in-cta","Unlock this exclusive content by signing in"],["exclusive-content-dialog-text","We reserve some of our content exclusively for our members.  Enter your email address to sign in or to become a member."]]);function o(e,t){return t.startsWith("/")||(t=`/${t}`),e.endsWith("/")&&(e=e.substr(0,e.length-1)),e+t}const n=new Map;n.set("engagement","engaged"),n.set("utm","campaign"),n.set("search","search"),n.set("form-submission","form submitted"),n.set("key-page","key page"),n.set("ga-goal","goal"),n.set("ga-ecommerce","ecommerce"),n.set("ga-event","event"),n.set("high-activity","active"),n.set("high-pages","many pages"),n.set("slickstream-widget-click","widget clicked"),n.set("conversion","conversion"),n.set("long-term","long-term visitor"),n.set("slickstream-favorite","favorited"),n.set("slickstream-membership","member"),n.set("high-revenue","high revenue"),n.set("suggestion","suggestion"),n.set("chatbot-action","chatbot");class r{constructor(e,t,i){this.config=e,this.requestSender=t,this.siteCode=i}async siteInfo(e,t,i){const s=`${r.Paths.siteInfo}?site=${this.siteCode}&epoch=${e}&auth=${t}${i?`&language=${i}`:""}`;return this.sendRequest(this.config.cacheableApiBaseUri,s,"GET",null,!1)}async siteInfoV2(e,t,i){const s=`${r.Paths.siteInfoV2}?site=${this.siteCode}&epoch=${e}&auth=${t}${i?`&language=${i}`:""}`;return this.sendRequest(this.config.cacheableApiBaseUri,s,"GET",null,!1)}async theme(e,t){const i=`${r.Paths.themeTemplates}?site=${this.siteCode}&theme=${e}&version=${t}`;return this.sendRequest(this.config.cacheableApiBaseUri,i,"GET",null,!1)}async localizationPhrases(e,t){const i=`${r.Paths.localizationPhrases}?site=${this.siteCode}&language=${e}&version=${t}`;return this.sendRequest(this.config.cacheableApiBaseUri,i,"GET",null,!1)}pageImage(e,t,i,s){const n=`${r.Paths.pageImage}${this.siteCode}/${e}?site=${this.siteCode}&epoch=${s}${t?`&w=${t}`:""}${i?`&h=${i}`:""}`;return{method:"GET",url:o(this.config.cacheableApiBaseUri,n)}}async endSession(e){return this.sendRequest(this.config.nonCacheableApiBaseUri,r.Paths.endSession,"POST",e)}async sendRequest(e,t,i,s,n=!0,r=!1){return this.requestSender({method:i,url:o(e,t+(n?`?site=${this.siteCode}`:""))},s,r)}}r.Paths={siteInfo:"/p/embed-site-info",siteInfoV2:"/p/embed-site-info-v2",pageImage:"/p/pageimg/",endSession:"/d/embed-end-session",themeTemplates:"/p/theme",localizationPhrases:"/p/localization"};const a=(e,t)=>t.some((t=>e instanceof t));let l,c;const h=new WeakMap,d=new WeakMap,p=new WeakMap,u=new WeakMap,g=new WeakMap;let f={get(e,t,i){if(e instanceof IDBTransaction){if("done"===t)return d.get(e);if("objectStoreNames"===t)return e.objectStoreNames||p.get(e);if("store"===t)return i.objectStoreNames[1]?void 0:i.objectStore(i.objectStoreNames[0])}return y(e[t])},set:(e,t,i)=>(e[t]=i,!0),has:(e,t)=>e instanceof IDBTransaction&&("done"===t||"store"===t)||t in e};function v(e){return e!==IDBDatabase.prototype.transaction||"objectStoreNames"in IDBTransaction.prototype?(c||(c=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])).includes(e)?function(...t){return e.apply(b(this),t),y(h.get(this))}:function(...t){return y(e.apply(b(this),t))}:function(t,...i){const s=e.call(b(this),t,...i);return p.set(s,t.sort?t.sort():[t]),y(s)}}function m(e){return"function"==typeof e?v(e):(e instanceof IDBTransaction&&function(e){if(d.has(e))return;const t=new Promise(((t,i)=>{const s=()=>{e.removeEventListener("complete",o),e.removeEventListener("error",n),e.removeEventListener("abort",n)},o=()=>{t(),s()},n=()=>{i(e.error||new DOMException("AbortError","AbortError")),s()};e.addEventListener("complete",o),e.addEventListener("error",n),e.addEventListener("abort",n)}));d.set(e,t)}(e),a(e,l||(l=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]))?new Proxy(e,f):e)}function y(e){if(e instanceof IDBRequest)return function(e){const t=new Promise(((t,i)=>{const s=()=>{e.removeEventListener("success",o),e.removeEventListener("error",n)},o=()=>{t(y(e.result)),s()},n=()=>{i(e.error),s()};e.addEventListener("success",o),e.addEventListener("error",n)}));return t.then((t=>{t instanceof IDBCursor&&h.set(t,e)})).catch((()=>{})),g.set(t,e),t}(e);if(u.has(e))return u.get(e);const t=m(e);return t!==e&&(u.set(e,t),g.set(t,e)),t}const b=e=>g.get(e);const w=["get","getKey","getAll","getAllKeys","count"],x=["put","add","delete","clear"],k=new Map;function S(e,t){if(!(e instanceof IDBDatabase)||t in e||"string"!=typeof t)return;if(k.get(t))return k.get(t);const i=t.replace(/FromIndex$/,""),s=t!==i,o=x.includes(i);if(!(i in(s?IDBIndex:IDBObjectStore).prototype)||!o&&!w.includes(i))return;const n=async function(e,...t){const n=this.transaction(e,o?"readwrite":"readonly");let r=n.store;return s&&(r=r.index(t.shift())),(await Promise.all([r[i](...t),o&&n.done]))[0]};return k.set(t,n),n}function _(){var e;if(!(!navigator.userAgentData&&/Safari\//.test(navigator.userAgent)&&!/Chrom(e|ium)\//.test(navigator.userAgent))||!indexedDB.databases)return Promise.resolve();var t=function(){return clearInterval(e)};return new Promise((function(t){var i=function(){return t()},s=function(){return indexedDB.databases().then(i).catch(i)};e=setInterval(s,100),s()})).then(t).catch(t)}f=(e=>({...e,get:(t,i,s)=>S(t,i)||e.get(t,i,s),has:(t,i)=>!!S(t,i)||e.has(t,i)}))(f);const C={get(e,t=!1){if(!e)return null;const i=localStorage.getItem(e);return i&&t?JSON.parse(i):i},set(e,t){e&&t&&("string"==typeof t?localStorage.setItem(e,t):localStorage.setItem(e,JSON.stringify(t)))},delete(e){e&&localStorage.removeItem(e)}},$=window.location.href,P="slick-debug-log",I="slick-debug-log-enabled",T={_records:[],_enabled:$.indexOf("127.0.0.1")>=0||$.indexOf("localhost")>=0||$.indexOf("slickLogging")>=0||"true"===C.get(I),print(e,t,i){const{message:s,time:o,object:n}=i;n?console.log(`[Slick ${o} ${t}] ${e} : ${s}`,n):console.log(`[Slick ${o} ${t}] ${e} : ${s}`)},log(e,t,i,s){const o={message:i,object:s,time:Date.now()};this._records.push(o),this._records.length>200&&this._records.shift(),this._enabled&&this.print(e,t,o)},enable(){this._enabled=!0,C.set(I,"true")},storeLog(){const e=this._records.map((e=>({message:e.message,time:e.time})));C.set(P,e)},clearStoredLog(){const e=C.get(P,!0);return e&&C.delete(P),e}};function O(e,t,i,s){T.log(e,t,i,s)}window.$slickLoggger=T;const R="slickstream",E="urls",j="settings",L="themes",z="localizations",M="search-results",A="last-search",D="last-theme";class H{constructor(){this._ready=!1,this._blockedOnce=!1}async _waitForIdb(){this._ready||(await _(),this._ready=!0)}async getDB(){let e=!1,t=0;return new Promise((i=>{t=window.setTimeout((()=>{t=0,e||(e=!0,this._blockedOnce||(this._blockedOnce=!0,O("db-store","warn","Timed out opening DB. Treating as blocked")),i(null))}),this._blockedOnce?500:2500),(async()=>{try{await this._waitForIdb();const s=await function(e,t,{blocked:i,upgrade:s,blocking:o,terminated:n}={}){const r=indexedDB.open(e,t),a=y(r);return s&&r.addEventListener("upgradeneeded",(e=>{s(y(r.result),e.oldVersion,e.newVersion,y(r.transaction))})),i&&r.addEventListener("blocked",(()=>i())),a.then((e=>{n&&e.addEventListener("close",(()=>n())),o&&e.addEventListener("versionchange",(()=>o()))})).catch((()=>{})),a}("slickstream-app",2,{upgrade(e){const t=e.objectStoreNames;t.contains(E)||e.createObjectStore(E),t.contains(j)||e.createObjectStore(j),t.contains(L)||e.createObjectStore(L),t.contains(M)||e.createObjectStore(M),t.contains(z)||e.createObjectStore(z)},blocked:()=>{O("db-store","warn","IndexdDB blocked"),e||(e=!0,this._blockedOnce=!0,t&&(window.clearTimeout(t),t=0),i(null))}});e||(t&&(window.clearTimeout(t),t=0),e=!0,i(s))}catch(t){O("db-store","error","Failed to open DB",t),e=!0,i(null)}})()}))}async closeDB(e){try{e.close()}catch(e){O("db-store","error","Failed to close DB",e)}}async addCachedUrl(e){const t=await this.getDB();if(t)try{t.put(E,{time:Date.now()},e)}catch(e){O("db-store","error","DB add fail",e)}finally{this.closeDB(t)}}async listCachedUrls(){const e=await this.getDB();if(e)try{return e.getAllKeys(E)}catch(e){O("db-store","error","Db error: listCachedUrls",e)}finally{this.closeDB(e)}return[]}async deleteCachedUrl(e){const t=await this.getDB();if(t)try{t.delete(E,e)}catch(e){O("db-store","error","Db error: deleteCachedUrl",e)}finally{this.closeDB(t)}}async _getSettings(e){const t=await this.getDB();if(t)try{return await t.get(j,e)||null}catch(e){O("db-store","error","Db error: _getSettings",e)}finally{this.closeDB(t)}return null}async getSettings(e,t=!1){try{let i=await this._getSettings(e);return!i&&t&&(i=await this._getSettings("/")),(null==i?void 0:i.settings)||null}catch(e){O("db-store","error","Db error: getSettings",e)}return null}async addSettings(e,t){const i=await this.getDB();if(i)try{await i.put(j,{time:Date.now(),settings:t},e)}catch(e){O("db-store","error","Db error: addSettings",e)}finally{this.closeDB(i)}}async deleteSettings(e){const t=await this.getDB();if(t)try{return t.delete(j,e)}catch(e){O("db-store","error","Db error: deleteSettings",e)}finally{this.closeDB(t)}}async getLocalization(e,t){const i=await this.getDB();if(i)try{const s=await i.get(z,e);if(s&&s.version===t)return s.data}catch(e){O("db-store","error","Db error: getLocalization",e)}finally{this.closeDB(i)}return null}async setLocalization(e,t,i){const s=await this.getDB();if(s)try{await s.put(z,{language:e,version:t,data:i},e)}catch(e){O("db-store","error","Db error: setLocalization",e)}finally{this.closeDB(s)}}async _addTheme(e,t){const i=await this.getDB();if(i)try{await i.put(L,e,t||e.themeId)}catch(e){O("db-store","error","Db error: _addTheme",e)}finally{this.closeDB(i)}}async addTheme(e){await this._addTheme(e),await this._addTheme(e,D),await this.deleteLastSearch()}async getLastTheme(){const e=await this.getDB();if(e)try{return await e.get(L,D)||null}catch(e){O("db-store","error","Db error: getLastTheme",e)}finally{this.closeDB(e)}return null}async getTheme(e,t){if(e&&t){const i=await this.getDB();if(i)try{const s=await i.get(L,e);if(s&&s.version===t){return await i.count(L,D)||this._addTheme(s,D),s}}catch(e){O("db-store","error","Db error: getTheme",e)}finally{this.closeDB(i)}}return null}searchKey(e,t){return`q:${e}|c:${t||""}`}async addSearchResponse(e,t,i,s,o,n,r){const a=await this.getDB();if(a)try{await a.put(M,{time:Date.now(),url:e,q:i,scrollOffset:n,context:s,group:o,response:t},r||this.searchKey(i,s))}catch(e){O("db-store","error","Db error: addSearchResponse",e)}finally{this.closeDB(a)}}async deleteSearchResponse(e){const t=await this.getDB();if(t)try{await t.delete(M,e)}catch(e){O("db-store","error","Db error: deleteSearchResponse",e)}finally{this.closeDB(t)}}async deleteLastSearch(){await this.deleteSearchResponse(A)}async setLastSearch(e,t,i,s,o,n){await this.addSearchResponse(e,t,i,s,o,n,A)}async getLastSearch(e,t=3e5){const i=await this.getDB();if(i)try{const s=await i.get(M,A)||null;if(s){if(Date.now()-s.time>t)return await this.deleteLastSearch(),null;if(s.url!==e)return null}return s}catch(e){O("db-store","error","Db error: getLastSearch",e)}finally{this.closeDB(i)}return null}}let F;async function B(){return F||(F=new H),F}async function U(){return await _(),function(e,{blocked:t}={}){const i=indexedDB.deleteDatabase(e);return t&&i.addEventListener("blocked",(()=>t())),y(i).then((()=>{}))}(R)}function N(e,t,i){i=i||new Date(Date.now()+31536e8);const s=function(){const e=window.location.hostname;if("127.0.0.1"===e)return e;const t=e.split(".");if(t.length<=2)return e;const i=t[t.length-3],s=t[t.length-2],o=t[t.length-1];return"co"===s?[i,s,o].join("."):[s,o].join(".")}();document.cookie=`${e}=${t}; expires=${i.toUTCString()}; path=/; domain=${s}; Secure`}function V(e){const t=document.cookie.split("; ").find((t=>0===t.indexOf(`${e}=`)));return t?t.split("=")[1]:null}const q="slick-connection-stats",W="slick-navigation-info",G="slick-reader-id",K="slick-server-debug-messages",Y="slick-ab";class Z{constructor(e){if(this._localStorageAllowed=!0,"denied"===e)return this._readerId=this._generateReaderId(),void(this._localStorageAllowed=!1);this._readerId=V(G)||C.get(G)||this._generateReaderId(),C.set(G,this._readerId),N(G,this._readerId)}get adthriveSessionInfo(){if(!this._localStorageAllowed)return null;const e=C.get("adthrive_session_key",!0);return e||null}get abFeatureTestInfo(){if(!this._localStorageAllowed)return null;const e=C.get(Y,!0);return e||null}set abFeatureTestInfo(e){this._localStorageAllowed&&(e?C.set(Y,e):C.delete(Y))}get readerId(){return this._readerId}_generateReaderId(){return`${Date.now()}.${Math.floor(Math.random()*Number.MAX_SAFE_INTEGER)}`}get clientFailureStats(){if(!this._localStorageAllowed)return null;const e=C.get(q,!0);return e?(C.delete(q),e):null}set clientFailureStats(e){this._localStorageAllowed&&(e?C.set(q,e):C.delete(q))}get navigationInfo(){if(!this._localStorageAllowed)return null;const e=C.get(W,!0);if(e){const t=Date.now()-e.timestamp;if(C.delete(W),t<3e4)return e}return null}set navigationInfo(e){this._localStorageAllowed&&(e?C.set(W,e):C.delete(W))}getDeferredServerLogMessages(e=!1){if(!this._localStorageAllowed)return[];const t=C.get(K,!0)||[];return e&&C.set(K,[]),t}deferredLogOnserver(e){if(!this._localStorageAllowed)return;const t=this.getDeferredServerLogMessages();t.push(e),C.set(K,t)}}function Q(e,t){if(t)for(const i in t)e.append(i,t[i])}async function X(e){return new Promise((t=>{setTimeout(t,e)}))}function J(e){let t=e?e.split("?")[1]:window.location.search.slice(1);const i={};if(t){t=t.split("#")[0];const e=t.split("&");for(let t=0;t<e.length;t++){const s=e[t].split("="),o=s[0].toLowerCase(),n=void 0===s[1]?"":s[1];i[o]||(i[o]=decodeURIComponent(n))}}return i}function ee(e){const t=[];for(const i of Object.keys(e)){const s=e[i];if(s){const e=encodeURIComponent(s);t.push(`${i}=${e}`)}}return t.length?`?${t.join("&")}`:""}function te(e,t,i,s){let o=0;return()=>{const n=arguments,r=i&&!o;clearTimeout(o),o=window.setTimeout((()=>{o=0,i||e.apply(s,n)}),t),r&&e.apply(s,n)}}function ie(e){return/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(String(e).toLowerCase())}class se{addToQueue(e){pbjs.que.push(e)}isPrebidLoaded(){return window.pbjs&&window.pbjs.libLoaded}waitForQueue(){return new Promise((async e=>{await this.waitForPrebid()||e(!1),pbjs.que.push((()=>{e(!0)}))}))}async waitForPrebid(){if(window.pbjs)return window.pbjs;for(let e=0;e<10;e++)if(await X(1e3),window.pbjs)return window.pbjs;return null}offEvent(e,t){this.addToQueue((()=>{pbjs.offEvent(e,t)}))}onEvent(e,t){this.addToQueue((()=>{pbjs.onEvent(e,t)}))}getHighestCpmBids(e){return pbjs.getHighestCpmBids(e)}getAllWinningBids(){return pbjs.getAllWinningBids()}}class oe{constructor(e){this.reportedBids=new Set,this.samplingRate=.05,window.pbjs=window.pbjs||{},window.pbjs.que=window.pbjs.que||[],this.reporter=e,this.prebidMethods=new se}async run(){if(Math.random()<this.samplingRate){this.prebidMethods.onEvent("bidWon",(e=>{e&&this.reportAds([e],"pbjs-bidwon")}));const e=e=>{e.adUnitCodes&&this.logHighstCPMBids(e.adUnitCodes)};this.prebidMethods.onEvent("auctionEnd",e)}}logHighstCPMBids(e){const t=new Set;e.forEach((e=>{if(!t.has(e)){const i=this.prebidMethods.getHighestCpmBids(e);i.length>0&&this.reportAds(i,"pbjs-highestcpm"),t.add(e)}}))}async reportAds(e,t){const i=e.map((e=>this.cloneAd(e)));i.length&&(i.forEach((e=>{e.adId&&this.reportedBids.add(e.adId)})),await this.reporter.reportPageAction(t,void 0,{bids:i,samplingRate:this.samplingRate}))}cloneAd(e){const t=JSON.parse(JSON.stringify(e));return delete t.ad,t}}class ne{constructor(e,t){this.stateMap=new Map,this.eventQueue=[],this._state=e;for(const e of t)this.stateMap.set(e.name,e)}get state(){return this._state}dispatch(e,t){this.eventQueue.push({event:e,data:t}),1===this.eventQueue.length&&this.processNextEvent()}processNextEvent(){if(!this.eventQueue.length)return;const e=this.eventQueue[0];if(e)try{const{event:t,data:i}=e;O("fsm","info",`SM: Event: ${t} CurrentState: ${this._state}`);const s=this.stateMap.get(this._state);if(s)for(const e of s.events)if(e.name===t){const o=this.stateMap.get(e.to);o&&(s.onExit&&(O("fsm","info",`SM: Exit ${this._state}`),s.onExit(s.name,e.to,t,i)),e.handler&&e.handler(s.name,o.name,t,i),this._state=o.name,O("fsm","info",`SM: Enter ${this._state}`),o.onEnter&&o.onEnter(s.name,o.name,t,i));break}}catch(t){O("fsm","error","Error processing socket fsm event",{item:e,err:t})}this.eventQueue.shift(),this.eventQueue.length&&this.processNextEvent()}}const re={appStart:Date.now(),clientVersion:""};class ae extends Error{constructor(e,t){super(t),this.messageTimeout=!0,this.messageId=e}}class le{constructor(e,t,i,s){var o;if(this.sessionRetryAttempts=0,this.sessionRetryTimer=0,this.pingTimer=0,this.lastPong=0,this.firtSessionConnection=!0,this.messageIdCounter=0,this.requestMap=new Map,this.failureStats={pageviewFailures:0,priorSocketRetries:0,priorStartFailures:0,priorDisconnects:0,priorReconnectFailures:0,priorRestartFailures:0,socketFailures:0},this.onVisibilityChange=()=>{this.machine.dispatch(document.hidden?"tab-inactive":"tab-active")},this.closeListener=e=>{O("socket","info","Socket closed",e),this.disconnectSocket(),this.machine.dispatch("socket-close")},this.messageListener=e=>{try{const t=JSON.parse(e.data);switch(t.direction){case"request":break;case"response":this.handleResponseMessage(t);break;case"error":this.handleErrorMessage(t);break;case"notify":this.handleNotificationMessage(t);break;case"pong":this.lastPong=Date.now();break;case"ping":this.send("pong");break;default:throw new Error(`Slick: Unexpected socket message direction: ${t.direction}`)}}catch(e){O("socket","error","Error parsing socket message",e)}},this.listener=i,this.sessionRequest=t,this.uri=e,this.uri.indexOf("?")>=0){const e=this.uri.split("?");this.uri=[e[0],"?site=",t.site].join("")}else this.uri=[this.uri,"?site=",t.site].join("");this._embedLocalStorage=s,this.priorFailureStats=s.clientFailureStats,this.sessionRequest.failureStats=this.priorFailureStats||this.failureStats,this.failureStats.pageviewFailures=(null===(o=this.priorFailureStats)||void 0===o?void 0:o.pageviewFailures)||0,this.machine=new ne("initial",[{name:"initial",onExit:()=>this.onMachineStart(),events:[{name:"start",to:"connecting"}]},{name:"idle-no-session",onEnter:()=>this.onIdle(),events:[{name:"tab-active",to:"connecting"}]},{name:"connecting",onEnter:()=>this.startConnection(),events:[{name:"tab-inactive",to:"idle-no-session"},{name:"socket-timeout",to:"waiting-retry-no-session"},{name:"socket-error",to:"waiting-retry-no-session"},{name:"socket-connect",to:"starting-session"}]},{name:"waiting-retry-no-session",onEnter:e=>this.retryEnter(e),onExit:()=>this.retryExit(),events:[{name:"tab-inactive",to:"idle-no-session"},{name:"retry",to:"connecting"},{name:"disable",to:"disabled"}]},{name:"starting-session",onEnter:()=>this.startSession(),events:[{name:"tab-inactive",to:"idle-no-session"},{name:"session-established",to:"connected"},{name:"message-timeout",to:"waiting-retry-no-session"},{name:"socket-close",to:"waiting-retry-no-session"},{name:"disable",to:"disabled"}]},{name:"connected",onEnter:()=>this.sessionConnected(),onExit:()=>this.sessionDisconnected(),events:[{name:"disable",to:"disabled"},{name:"tab-inactive",to:"idle"},{name:"socket-close",to:"waiting-retry"},{name:"ping-timeout",to:"reconnecting"},{name:"reconnect-request",to:"reconnecting"}]},{name:"idle",onEnter:()=>this.onIdle(),events:[{name:"tab-active",to:"reconnecting"}]},{name:"reconnecting",onEnter:()=>this.startReconnection(),events:[{name:"tab-inactive",to:"idle"},{name:"socket-error",to:"waiting-retry"},{name:"socket-timeout",to:"waiting-retry"},{name:"socket-connect",to:"restarting-session"}]},{name:"restarting-session",onEnter:()=>this.restartSession(),events:[{name:"tab-inactive",to:"idle"},{name:"socket-close",to:"waiting-retry"},{name:"message-timeout",to:"waiting-retry"},{name:"disable",to:"disabled"},{name:"session-restarted",to:"connected",handler:this.onSessionRestarted.bind(this)}]},{name:"waiting-retry",onEnter:e=>this.retryEnter(e),onExit:()=>this.retryExit(),events:[{name:"tab-inactive",to:"idle"},{name:"retry",to:"reconnecting"},{name:"disable",to:"disabled"}]},{name:"disabled",onEnter:()=>this.onDisable(),events:[]}])}start(){this.machine.dispatch("start")}get session(){return this.sessionResponse}updateFailureStats(){this._embedLocalStorage.clientFailureStats=this.failureStats}onMachineStart(){document.addEventListener("visibilitychange",this.onVisibilityChange,!1)}startConnection(){this.socket=new WebSocket(this.uri,"SLICK_CLIENT_1"),re.socketCreated||(re.socketCreated=Date.now());let e=0;const t=()=>{e&&(window.clearTimeout(e),e=0)},i=()=>{if(this.socket){this.socket.removeEventListener("error",s),this.socket.removeEventListener("open",o);try{this.socket.close()}catch(e){}this.socket=void 0}},s=e=>{t(),i(),O("socket","error","Socket connect error",e),this.machine.dispatch("socket-error")},o=()=>{t(),this.socket&&(this.socket.removeEventListener("error",s),this.socket.removeEventListener("open",o)),O("socket","info","Socket opened"),this.machine.dispatch("socket-connect")};this.socket.addEventListener("error",s),this.socket.addEventListener("open",o),e=window.setTimeout((()=>{i(),this.machine.dispatch("socket-timeout")}),3e4)}async startSession(){re.socketConnected=Date.now(),this.attachSocketListeners();try{this.sessionRequest.failureStats&&(this.sessionRequest.failureStats.socketFailures=this.failureStats.priorSocketRetries),re.sessionRequested=Date.now(),this.sessionResponse=await this.request("start-session",this.sessionRequest),re.sessionConnected=Date.now(),O("socket","info","Session established",this.sessionResponse)}catch(e){return re.sessionError=e.messageTimeout?"Message timeout for start-session":e.message||e.toString(),void(e.messageTimeout?(O("socket","error","Message timeout for start-session",e),this.machine.dispatch("message-timeout")):(O("socket","error","Error starting session",e),this.machine.dispatch("disable")))}this.machine.dispatch("session-established")}sessionConnected(){if(!this.sessionResponse)return void this.machine.dispatch("disable");"disable"!==(this.sessionResponse.settings.activation||"active")?(this.sessionRetryAttempts=0,this.startPinging(),this.firtSessionConnection?(this.firtSessionConnection=!1,this.listener.handleSocketSessionEstablished(this.sessionResponse)):this.listener.handleSocketSessionUpdated(this.sessionResponse),this.failureStats.pageviewFailures=0,this.updateFailureStats()):this.machine.dispatch("disable")}sessionDisconnected(){this.stopPinging(),this.detachSocketLiseteners(),this.listener.handleSocketSessionDisconnected()}startReconnection(){this.startConnection()}async restartSession(){this.attachSocketListeners();try{const e={site:this.sessionRequest.site,reader:this.sessionRequest.reader,start:this.sessionRequest.start,clientVersion:this.sessionRequest.clientVersion},t=await this.request("restart-session",e);this.machine.dispatch("session-restarted",t)}catch(e){e.messageTimeout?(O("socket","error","Message timeout for restart-session",e),this.machine.dispatch("message-timeout")):(O("socket","error","Error restarting session",e),this.machine.dispatch("disable"))}}onSessionRestarted(e,t,i,s){O("socket","info","Session restarted. updating session object."),this.sessionResponse&&s&&(this.sessionResponse.currentPage&&(this.sessionResponse.currentPage.totalFavorites=s.totalFavorites,this.sessionResponse.currentPage.isFavorite=s.isFavorite),this.sessionResponse.totalUserFavorites=s.totalUserFavorites||0,this.sessionResponse.activeVisitors=s.activeVisitors)}retryEnter(e){switch(this.cancelRetryTimer(),this.sessionRetryAttempts++,e){case"connecting":this.failureStats.priorSocketRetries=this.sessionRetryAttempts;break;case"starting-session":this.failureStats.priorStartFailures=this.sessionRetryAttempts;break;case"connected":this.failureStats.priorDisconnects++;break;case"reconnecting":this.failureStats.priorReconnectFailures=Math.max(this.failureStats.priorReconnectFailures,this.sessionRetryAttempts);break;case"restarting-session":this.failureStats.priorStartFailures=Math.max(this.failureStats.priorStartFailures,this.sessionRetryAttempts)}this.sessionRetryAttempts>3?this.machine.dispatch("disable"):this.sessionRetryTimer=window.setTimeout((()=>{this.machine.dispatch("retry")}),2*this.sessionRetryAttempts*1e3)}retryExit(){this.cancelRetryTimer()}cancelRetryTimer(){this.sessionRetryTimer&&(window.clearTimeout(this.sessionRetryTimer),this.sessionRetryTimer=0)}stopAndDie(){this.onDisable()}onDisable(){this.disconnectSocket(),this.listener.handleSocketSessionDisabled(),document.removeEventListener("visibilitychange",this.onVisibilityChange,!1),T.storeLog(),this.sessionResponse||this.failureStats.pageviewFailures++,this.updateFailureStats()}onIdle(){this.disconnectSocket()}disconnectSocket(){if(this.socket){this.detachSocketLiseteners();try{this.socket.close()}catch(e){}this.socket=void 0}}attachSocketListeners(){this.detachSocketLiseteners(),this.socket&&(this.socket.addEventListener("close",this.closeListener),this.socket.addEventListener("message",this.messageListener))}detachSocketLiseteners(){this.socket&&(this.socket.removeEventListener("close",this.closeListener),this.socket.removeEventListener("message",this.messageListener))}handleResponseMessage(e){const t=e.messageId,i=this.requestMap.get(t);i&&(this.requestMap.delete(t),i[0](e.payload||{}))}handleErrorMessage(e){const t=e.messageId,i=this.requestMap.get(t);i?(this.requestMap.delete(t),i[1](new Error(e.payload.description))):O("socket","error","Error response message: ",e)}handleNotificationMessage(e){if("reconnect"===e.msgType)this.machine.dispatch("reconnect-request");this.listener.handleSocketSessionNotification(e)}handleMessageTimeout(e,t){const i=this.requestMap.get(e);i&&(this.requestMap.delete(e),i[1](new ae(e,`Message timeout for #${e}: ${t}`)))}nextId(){return++this.messageIdCounter}sendMessage(e){if(this.socket)switch(this.machine.state){case"starting-session":case"restarting-session":case"connected":return this.socket.send(JSON.stringify(e)),!0}return!1}send(e,t,i={},s){const o={at:Date.now(),messageId:s||this.nextId(),direction:e,payload:i};t&&(o.msgType=t),this.sendMessage(o)}async request(e,t,i=8e3){const s=this.nextId();return new Promise(((o,n)=>{this.requestMap.set(s,[o,n]),window.setTimeout((()=>this.handleMessageTimeout(s,i)),i),this.send("request",e,t,s)}))}startPinging(){this.pingTimer||(this.lastPong=Date.now(),this.nextPing())}stopPinging(){this.pingTimer&&(window.clearTimeout(this.pingTimer),this.pingTimer=0)}nextPing(){this.pingTimer=window.setTimeout((()=>{this.pingTimer=0,this.socket&&this.socket.readyState===WebSocket.OPEN&&(Date.now()-this.lastPong>4e4?this.machine.dispatch("ping-timeout"):(this.send("ping"),this.nextPing()))}),3e4)}}const ce={testNodeClasses:"pub_300x250 pub_300x250m pub_728x90 text-ad textAd text_ad text_ads text-ads text-ad-links",testNodeStyle:"height: 10px !important; font-size: 20px; color: transparent; position: absolute; bottom: 0; left: -10000px;",testInterval:51,testRuns:4};async function he(){try{const e=ce,t=function(e,t){const i=window.document,s=i.createElement("div");return s.innerHTML="&nbsp;",s.setAttribute("class",e),s.setAttribute("style",t),i.body.appendChild(s),s}(e.testNodeClasses,e.testNodeStyle);let i=0,s=!1;return new Promise((o=>{const n=window.setInterval((()=>{try{i++,s=function(e){return 0===e.offsetHeight||!document.body.contains(e)||"none"===e.style.display||"hidden"===e.style.visibility}(t),(s||i===e.testRuns)&&(window.clearInterval(n),t.parentNode&&t.parentNode.removeChild(t),o(s))}catch(e){console.error(e),window.clearInterval(n),o(!1)}}),e.testInterval)}))}catch(e){return console.error(e),!1}}function de(...e){const t=window.dataLayer;t&&Array.isArray(t)&&t.push(arguments)}function pe(){const e=window,t=[];return e.__gaTracker&&t.push("monster"),e.ga&&t.push("ga"),e.dataLayer&&t.push("dataLayer"),t}async function ue(e){const t=await async function(e,t,i){let s=0;return await new Promise((o=>{const n=setInterval((()=>{const t=e();t||s>i?(o(t),clearInterval(n)):s+=1}),t)}))}(pe,200,25),i=function(){const e=[],t=window.dataLayer;if(t&&Array.isArray(t))for(const i of t)if(i&&"config"===i[0]){const t=i[1];t&&"string"==typeof t&&e.push(t)}return e}();if(t.includes("monster"))return void function(e){try{const t=window.__gaTracker;t&&"function"==typeof t&&t("send","event",{eventCategory:e.category,eventAction:e.action,eventLabel:e.label,eventValue:e.value,nonInteraction:e.nonInteraction})}catch(e){console.warn("Slickstream detected Monster Plugin but could not report event",e)}}(e);i.length>0&&function(e,t){try{let i=window.gtag;i&&"function"==typeof i||(i=de),i("event",e.action,{send_to:t,event_category:e.category,event_label:e.label,value:e.value,non_interaction:e.nonInteraction})}catch(e){console.warn("Slickstream detected gtag.js but could not report event",e)}}(e,i);const s=!!i.find((e=>e.startsWith("UA-")));t.includes("ga")&&!s&&function(e){try{const t=window.ga;t&&"function"==typeof t&&t((()=>{const i=new Set,s=t.getAll();for(const t of s){const s=t.get("trackingId");i.has(s)||(i.add(s),t.send("event",e.category,e.action,e.value))}}))}catch(e){console.warn("Slickstream detected analytics.js but could not report event",e)}}(e),t.includes("dataLayer")&&function(e){if(window.dataLayer&&Array.isArray(window.dataLayer))try{window.dataLayer.push({event:"slickstream_event",slickstream_event_data:{event_category:e.category,event_action:e.action,event_label:e.label,value:e.value},non_interaction:e.nonInteraction})}catch(e){console.warn("Slickstream detected dataLayer but could not report event",e)}}(e)}let ge="";function fe(e){var t,i;if(e===ge)return;const s=()=>{var t;const i=null===(t=window.$mediavine)||void 0===t?void 0:t.web;try{i.identityOptIn({email:e},(t=>{t?O("adtech","error","Error Opting-in with Mediavine",t):(ge=e,O("adtech","info","Opted in with Mediavine"))}))}catch(e){O("adtech","error","Exception Opting-in with Mediavine",e)}};(null===(i=null===(t=window.$mediavine)||void 0===t?void 0:t.web)||void 0===i?void 0:i.identityOptIn)?s():(O("adtech","info","Mediavine identityOptIn not present. Waiting for ready event."),window.addEventListener("mediavineIdentityReady",(()=>{O("adtech","info","Mediavine Identity ready event fired."),s()})))}let ve="";function me(e,t){if(e===ve)return;let i=window.adthrive;(t||i)&&(window.adthrive=i||{},i=window.adthrive,i.cmd=i.cmd||[],i.cmd.push((()=>{window.adthrive.identityApi?window.adthrive.identityApi({source:"slickstream",plainText:e},(({success:t,data:i})=>{t?(ve=e,O("adtech","info","Identity registered with Adthrive")):O("adtech","error","Adthrive Identity API error:",i)})):O("adtech","warn","Adthrive Identity API not present")})))}function ye(e){const t=window;t.adthrive=t.adthrive||{},t.adthrive.cmd=t.adthrive.cmd||[];const i="anonymous"===e?"off":"on";t.adthrive.cmd.push((()=>{t.adthrive.config&&t.adthrive.config.abGroup?t.adthrive.config.abGroup.set("slkid",i):O("adtech","warn","reportMemberShipStatusToGAM: adthrive config abGroup not present")}))}async function be(e,t,i){const s=new Map([["favorites","fav"],["filmstrip","flm"],["filmstrip-toolbar","flmtb"],["heart-button","hrt"],["heart-fluttering","hrtfltr"],["inline-search","insrch"],["recommendations-all","recall"],["search-all","srchall"],["search-box","srchbox"],["search-button","srchbt"],["search-hook","srchhk"]]),o=!0===e.value?"off":"on";if(e.type&&"activation"===e.type){const i="slkab_all"+we(e.devices);xe(i,o).catch((()=>{O("adtech","error","sendTargetingKeyToGam:",i)})),ke(t,i,o).catch((()=>{O("adtech","error","sendAbTestResultToAdslogger:",i)}))}else if(e.type&&"feature-switches"===e.type&&e.feature&&s.get(e.feature)){const n="slkab_"+s.get(e.feature)+we(e.devices);xe(n,o).catch((()=>{O("adtech","error","sendTargetingKeyToGam:",n)}));let r=null;"inline-search"===e.feature&&(!function(e){if(e.inlineSearch&&e.inlineSearch.length>0){const t=[];for(const i of e.inlineSearch)t.push(i.id);xe("slk_dcm",t).catch((()=>{O("adtech","error","sendTargetingKeyToGam","sendInlineSearchKeytoGam")}))}}(i),r=function(e){const t=[];if(e.inlineSearch&&e.inlineSearch.length>0)for(const i of e.inlineSearch){const e={id:i.id,selector:i.selector,position:i.position};t.push(e)}return t}(i)),ke(t,n,o,r).catch((()=>{O("adtech","error","sendAbTestResultToAdslogger:",n)}))}}function we(e){let t="";return e&&e.length>0&&(t="_",e.includes("desktop")&&(t+="d"),e.includes("phone")&&(t+="p"),e.includes("tablet")&&(t+="t"),e.includes("unknown")&&(t+="u")),t}async function xe(e,t){const i=window;i.adthrive=i.adthrive||{},i.adthrive.cmd=i.adthrive.cmd||[],i.adthrive.cmd.push((()=>{i.adthrive.setTargetingFlag(e,Array.isArray(t)?t:[t])}))}async function ke(e,t,i,s){const o=null==e?void 0:e.adthriveSessionInfo;if(!o)return;const n=Object.assign(Object.assign({key:t,value:i},s&&{dcmInfo:s}),{adthrive_sess:o.value}),r=`https://logger.adthrive.com/event?message=slickstream%3A%3Aslick-ab&body=${encodeURIComponent(JSON.stringify(n))}&pageurl=${encodeURIComponent(window.location.href)}`;fetch(r)}class Se{constructor(e){this._attched=!1,this._route={path:"",segments:[],params:{}},this._listener=e,window.addEventListener("hashchange",this.onHashChange.bind(this))}attach(){this._attched||(this._attched=!0,setTimeout((()=>this.onHashChange())))}onHashChange(){this._route=Se.getHashRoute(),this._listener.handleHashChange(this._route)}computeHash(e,t=!1){const i=(Array.isArray(e)?e:[e]).filter((e=>!!e));let s="#";if(i&&i.length){const e=t?i:i.map((e=>encodeURIComponent(e)));s+=e.join("/")}return s}constructPath(e){const t=[];for(const i in e){t.length&&t.push("&"),t.push(i);const s=e[i];s&&t.push("=",encodeURIComponent(s))}return t.join("")}goto(e){const t=this.computeHash(e);this.gotoHash(t)}gotoHash(e){if("#"===e){const e=window.location.hash.length>1;window.history.pushState("",document.title,window.location.pathname+window.location.search),e&&this.onHashChange()}else window.history.pushState("",document.title,e),this.onHashChange()}computeHashUrl(e,t){return t?this.computeHash([encodeURIComponent(e),this.constructPath(t)],!0):this.computeHash([e])}gotoWithParams(e,t){const i=t?this.computeHash([encodeURIComponent(e),this.constructPath(t)],!0):this.computeHash([e]);this.gotoHash(i)}push(e,t){const i=t?this.computeHash([encodeURIComponent(e),this.constructPath(t)],!0):this.computeHash([e]);i.length>1?window.history.pushState("",document.title,i):window.history.pushState("",window.location.pathname+window.location.search)}replace(e,t){const i=t?this.computeHash([encodeURIComponent(e),this.constructPath(t)],!0):this.computeHash([e]);i.length>1?window.history.replaceState("",document.title,i):window.history.replaceState("",window.location.pathname+window.location.search)}static getHashRoute(){let e=window.location.hash||"";e&&(e=e.substring(1));const t=(e.split("/")||[]).map((e=>decodeURIComponent(e)));return{path:t[0]||"",segments:t,params:t[1]?J(`?${t[1]}`):{}}}}let _e=!1;const Ce=new WeakSet;let $e=0;function Pe(e,t){e.addEventListener("submit",(()=>{const i={},s=e.attributes;if(s&&s.length)for(let e=0;e<s.length;e++){const t=s[e];i[t.name]=t.value}const o={},n=["name","email","website","company"];if("FormData"in window){new FormData(e).forEach(((e,t)=>{if("string"==typeof e){t=(t||"").toLowerCase();let i=n.some((e=>t.indexOf(e)>=0));i||(i=ie(e)),i&&(o[t]=e)}})),e.querySelectorAll("input").forEach((e=>{const t=(e.name||e.placeholder||e.id||"unknown_field").toLowerCase(),i=e.value.trim();if(i){let e=n.some((e=>t.indexOf(e)>=0));e||(e=ie(i)),e&&!o[t]&&(o[t]=i)}}))}t.notifyFormSubmit(i,o)})),Ce.add(e)}function Ie(e){Te(document,e);Date.now()-$e<3e4&&setTimeout((()=>{Ie(e)}),1e3)}function Te(e,t){const i=e.querySelectorAll("form");if(i&&i.length)for(let e=0;e<i.length;e++){const s=i[e];Ce.has(s)||Pe(s,t)}}function Oe(e,t){e.enabled&&(_e||($e=Date.now(),Ie(t),function(e){const t=document.querySelectorAll("iframe"),i=t=>{Te(t,e)};t.forEach((e=>{try{e.contentWindow&&("complete"===e.contentWindow.document.readyState?i(e.contentWindow.document):e.contentWindow.addEventListener("load",(()=>{e.contentWindow&&i(e.contentWindow.document)})))}catch(e){}}))}(t),_e=!0))}const Re=e=>new Request(e,{cache:"no-store"});class Ee{async cache(){if(this._cache)return this._cache;if("caches"in self)try{this._cache=await caches.open("slickstream-code")}catch(e){O("url-cache","error","Failed to open cache",e)}return this._cache||null}async addUrl(e){await this.removeUrl(e);const t=await this.cache();if(t)try{return await t.add(Re(e)),!0}catch(e){O("url-cache","error","Failed to add Url",e)}return!1}async addUrlIfNotCached(e){const t=await this.cache();if(t){const i=Re(e),s=await t.match(i);if(s&&s.ok)return;await t.add(i)}}async getUrl(e,t=!1){const i=await this.cache();if(i){const s=await i.match(Re(e));if(s&&s.ok)return t?await s.text():await s.json()}return null}async removeUrl(e){const t=await this.cache();t&&await t.delete(Re(e),{ignoreVary:!0})}async removeAllBootData(e){const t=await this.cache();if(t){const i=await t.keys(Re(`${e}/d/page-boot-data`),{ignoreSearch:!0});for(const e of i)await t.delete(e)}}async resetExpiredBootData(e,t){const i=`${e}/d/page-boot-data?site=${t}&url=${encodeURIComponent(location.href.split("#")[0])}`,s=await this.getUrl(i);s&&(s.bestBy||0)<Date.now()&&this.addUrl(i)}}let je;function Le(){return je||(je=new Ee),je}class ze{constructor(e,t){if(this.language=e,"en"!==e&&t){this.phrases=new Map;for(const e in t.phrases)this.phrases.set(e,t.phrases[e])}else this.phrases=new Map(s)}getPhrase(e){return this.phrases.get(e)||e}setOverrides(e){for(const t of e)t.language===this.language&&this.phrases.set(t.phrase,t.override)}}const Me=window;async function Ae(e){const t=await async function(){for(let e=0;e<10;e++){if(Me.drift)return Me.drift;await X(3e3)}}();t&&t.on&&t.on("startConversation",(t=>{e.notifyChatStarted("drift",t)}))}const De=window;async function He(e){const t=await async function(){for(let e=0;e<10;e++){if(De.insent)return De.insent;await X(3e3)}}();t&&t.listener&&t.listener("onShow",(t=>{e.notifyChatStarted("insent",t)}))}const Fe=window;function Be(e){Fe.HubSpotConversations&&Fe.HubSpotConversations.on("conversationStarted",(t=>{e.notifyChatStarted("hubspot",t)}))}const Ue=document.querySelector('link[rel="canonical"]'),Ne=Ue&&Ue.href,Ve=!!(null==Ue?void 0:Ue.hasAttribute("slickstream-force-canonical")),qe=1e4,We="slick-snackbar",Ge=".slick-film-strip",Ke=".slick-inline-search-panel",Ye="addfavorite";const Ze=new class{constructor(){this.readerId="",this.sessionTimestamp=Date.now(),this.firstEngagementTimestamp=0,this.lastEnagementTimestamp=0,this.lastPollTimestamp=Date.now(),this.userAuthenticated=!1,this.authenticatedUser=null,this.appSearchMode=!!window.slickAppSearchPreview,this.dictionary=new ze("en",null),this.widgetActionDebounceMap=new Map,this.gaClients=new Map,this.connectionState="offline",this.pendingSocketMessages=[],this.router=new Se(this),this.cachedSettings=null,this.requestSender=async(e,t)=>{switch(e.method){case"GET":return async function(e,t=!0,i){const s={credentials:t?"include":"same-origin"};if(i){const e=new Headers;Q(e,i),s.headers=e}const o=await fetch(e,s);if(!o.ok){const e=await o.text();throw{status:o.status,message:e,response:o}}return await o.json()}(e.url,!1);case"POST":return async function(e,t,i=!0,s){const o={method:"POST",credentials:i?"include":"same-origin",body:JSON.stringify(t)},n=new Headers;n.append("Content-Type","application/json"),Q(n,s),o.headers=n;const r=new Request(e,o),a=await fetch(r);if(!a.ok){const e=await a.text();throw{status:a.status,message:e,response:a}}return await a.json()}(e.url,t,!1)}},this.windowEventsAttached=!1,this.engagementHandler=t=>{if(setTimeout((()=>{e.dispatch("engagement")}),10),t&&"click"===t.type){const e=t.srcElement||t.target;if(e){let i=null,s=e;const o=["body","head","html"];for(;s&&s.tagName;){const e=s.tagName.toLowerCase();if(o.indexOf(e)>=0)break;if("a"===e){i=s;break}s=s.parentElement}if(i){const e=t;if(!(e.button||0)){const t=e.shiftKey||e.ctrlKey||e.altKey||e.metaKey||!1;return i.href&&!t&&this.saveNavigatingAwayInfo("link-click"),void this.reportPageAction("link-click",i.href,{modifier:t})}}}}if(this.lastEnagementTimestamp=Date.now(),!this.firstEngagementTimestamp){this.firstEngagementTimestamp=this.lastEnagementTimestamp;const e=this.getUnreportedActivity(!1);setTimeout((async()=>{this.pingSession(e),setTimeout((()=>{this.lastEnagementTimestamp=0,setInterval((()=>{this.pingSession(qe)}),qe)}),1e3)}))}},this._gaPollCount=0,this._gaClientPollTimer=0}set membershipService(e){this._membershipService=e}get membershipService(){return this._membershipService||{memberSignin(){}}}get currentSession(){return this.sessionResponse}get sessionConnectionState(){return this.connectionState}initializeWPUser(){const e=document.querySelector('meta[property="slick:wpuser"]'),t=e?e.getAttribute("content"):null;if(t&&t.trim().length>0)this.userAuthenticated=!0,this.authenticatedUser=t.trim();else{let e=document.querySelector('meta[name="user-authenticated"]');e||(e=document.querySelector('meta[property="user-authenticated"]'));let t=document.querySelector('meta[name="authenticated-user"]');t||(t=document.querySelector('meta[property="authenticated-user"]'));const i=e?e.getAttribute("content"):null;"true"===i?this.userAuthenticated=!0:"false"===i?this.userAuthenticated=!1:i&&i.length>0&&(this.userAuthenticated=!0,this.authenticatedUser=i),this.userAuthenticated=!!i&&"true"===i;const s=t?t.getAttribute("content"):null;s&&s.length>0&&(this.userAuthenticated=!0,this.authenticatedUser=s)}}async _detectNewGAClients(){return new Promise((e=>{let t=!1;const i=window.setTimeout((()=>{t||(t=!0,e(!1))}),300);try{(async function(){const e=new Map;return new Promise((t=>{const i=window,s=i.ga||i.__gaTracker;if(s){let i=window.setTimeout((()=>{t(e)}),200);s((()=>{if(i){window.clearTimeout(i),i=0;const o=s.getAll();if(o)for(const t of o){const i=t.get("clientId"),s=t.get("trackingId");if(i&&s){const t=`${i}-${s}`;e.has(t)||e.set(t,{clientId:i,propertyId:s})}}t(e)}}))}else t(e)}))})().then((s=>{if(t)return;let o=!1;if(s&&s.size)for(const e of s.keys())if(!this.gaClients.has(e)){const t=s.get(e);t&&(this.gaClients.set(e,t),o=!0)}window.clearTimeout(i),t=!0,e(o)})).catch((e=>{throw e}))}catch(s){O("services","error","_detectNewGAClients",s),window.clearTimeout(i),t||(t=!0,e(!1))}}))}_gaClientsAsArray(){const e=[];for(const t of this.gaClients.keys()){const i=this.gaClients.get(t);i&&e.push(i)}return e}get siteCode(){var e;return(null===(e=this.appContext)||void 0===e?void 0:e.bootData.siteCode)||""}async start(e){if((window.navigator.userAgent||"").match(/googlebot|bot|crawler|spider|crawling/i))return void O("services","info","Disabling Slickstream socket because bot/crawler agent was detected");this.appContext=e,this.sessionTimestamp=Date.now(),re.appStart=this.sessionTimestamp,re.clientVersion=e.clientVersion,document.addEventListener("slick-boot-no-consent",(()=>{this.stop()}));let t,s=e.clientType;document.querySelector('meta[name="slick-extension-active"]')?s="browser-extension":document.querySelector('meta[name="slick-shadow-proxy-active"]')&&(s="shadow-proxy",t=window.location.origin);let o=window.location.href;"shadow-proxy"===s&&(o=window.location.href.substring(window.origin.length+1)||o);const n=J(o),a=!(!n||!("enable-slickstream"in n));this._embedLocalStorage=this._embedLocalStorage||new Z(e.consentStatus);const l=new Set;let c;!a&&e.bootData.abTests&&e.bootData.abTests.length>0&&(c=this.getABTestResult(e.bootData.abTests,this._embedLocalStorage,this.appContext.bootData.siteCode,e.device),c&&(be(c,this._embedLocalStorage,e.bootData),c.value&&this.getClsDivFromAbResult(c).forEach((e=>{l.add(e)})))),e.bootData.filmstrip||l.add(Ge),e.bootData.inlineSearch||l.add(Ke),this.removeClsDivs(l),window.addEventListener("beforeunload",(()=>{var e;re.sessionConnected||Date.now()-this.sessionTimestamp>=3e4&&(null===(e=this._embedLocalStorage)||void 0===e||e.deferredLogOnserver({message:"Failed to connect session in 30s.",severity:"debug",data:re}))})),this.readerId=this._embedLocalStorage.readerId,this.initializeWPUser();const h=e.bootData.services,d=e.bootData.siteCode;this.restApi=new r({cacheableApiBaseUri:h.engagementCacheableApiDomain,nonCacheableApiBaseUri:h.engagementNonCacheableApiDomain,resourcesBaseUri:h.engagementResourcesDomain},this.requestSender,d);const p=document.querySelector('meta[property="article:published_time"]'),u=p&&p.getAttribute("content");let g=document.querySelector('meta[property="article:modified_time"]');g||(g=document.querySelector('meta[property="og:updated_time"]'));const f=g&&g.getAttribute("content"),v={w:window.innerWidth,h:window.innerHeight},m=document.querySelector('meta[name="robots"]'),y=m&&m.getAttribute("content")||void 0;re.adBlockDetectStart=Date.now();let b=!1;try{b=!!await he()||!1}catch(e){b=!1}re.adBlockDetectEnd=Date.now(),re.gaDetectStart=Date.now();try{await this._detectNewGAClients()}catch(e){console.error(e)}re.gaDetectEnd=Date.now();const w=this._gaClientsAsArray(),x=n&&n[i]||void 0,k=n&&n[Ye];if(x){this._pendingPageToHeart=k?+k:void 0,void 0!==this._pendingPageToHeart&&isNaN(this._pendingPageToHeart)&&(this._pendingPageToHeart=void 0),delete n[i],delete n[Ye];const e=new URL(window.location.href);e.search=ee(n),window.history.replaceState({},document.title,e.href)}else this._pendingPageToHeart=void 0;const S=V("usprivacy"),_=S&&S.match(/^1[YyNn-]{3}$/)?S:void 0,C={site:d,reader:this.readerId,start:this.sessionTimestamp,url:Ve&&Ne||o,canonical:Ne||void 0,publishedTime:u,updatedTime:f,referer:document.referrer,display:v,clientVersion:e.clientVersion,embedCodeVersion:e.embedCodeVersion,userAuthenticated:this.userAuthenticated,adBlockerDetected:b,error404Detected:document.body.classList.contains("error404")||!1,robotsContent:y,clientMetrics:e.metrics,clientType:s,shadowProxyBaseUrl:t,gaClients:w,pageTitle:document.title,useGenericPageDescriptors:!0,ssoToken:x,consentStatus:e.consentStatus,usPrivacyString:_,abTest:c,device:e.device};C.clientMetrics&&(C.clientMetrics.sessionStart=performance.now()),this.authenticatedUser&&(C.authenticatedUser=this.authenticatedUser),this.appSearchMode&&(C.siteSearchMode=!0);const $=this._embedLocalStorage.navigationInfo;$&&(C.priorPageInfo=$),re.initializingSocket=Date.now(),this.socketManager=new le(h.websocketUri||window.slickSocketUri,C,this,this._embedLocalStorage),this.socketManager.start()}getABTestResult(e,t,i,s){if(e.length>0&&e[0].startDate<Date.now()&&e[0].endDate>Date.now()){const o=null==t?void 0:t.abFeatureTestInfo;if(o&&(1===e.length&&o.id===e[0].id||e.length>1&&(o.id===e[0].id||o.id===e[1].id)))return o;let n=e[0];e.length>1&&Math.random()<.5&&(n=e[1]);const r=null!==n.excludeSites&&n.excludeSites.includes(i),a=!s||!n.devices||n.devices.includes(s);if(!r&&a){const e={id:n.id,feature:n.feature,fraction:n.fraction,startDate:n.startDate,endDate:n.endDate,type:n.type,devices:n.devices,value:Math.random()>=n.fraction/100};return t.abFeatureTestInfo=e,e}}t.abFeatureTestInfo=null}removeElementsByQuerySelector(e){document.querySelectorAll(e).forEach((e=>{e.parentNode&&e.parentNode.removeChild(e)}))}removeClsDivs(e){e.forEach((e=>{this.removeElementsByQuerySelector(e)}))}getClsDivFromAbResult(e){const t=[];return"inline-search"!==e.feature&&"all-features"!==e.feature||t.push(Ke),"filmstrip"!==e.feature&&"recommendations-all"!==e.feature&&"all-features"!==e.feature||t.push(Ge),t}stop(){this.socketManager&&(this.socketManager.stopAndDie(),this.socketManager=void 0)}async handleSocketSessionEstablished(t){var i,s;this.sessionResponse=t,this.connectionState="online",(null===(i=this.appContext)||void 0===i?void 0:i.consentStatus)&&"denied"!==this.appContext.consentStatus&&this.initializePrebidMonitor(),this.attachWindowEvents(),this.initializeEmbedStoryMonitor(),this._pendingThemePromise=void 0,this.getTheme(!0);const o=t.language;if("en"!==o){const e=await this._loadLanguage(o,t.phraseVersion||"");this.dictionary=new ze(o,e)}t.localizationOverrides&&this.dictionary.setOverrides(t.localizationOverrides);const n=t.gaEvent;n&&setTimeout((()=>{ue(n)})),t.settings.forms&&Oe(t.settings.forms,this);const r=this.sessionResponse.settings.chatbotMonitoring;if(r&&r.chatbotType)switch(r.chatbotType){case"none":break;case"drift":Ae(this);break;case"insent":He(this);break;case"hubspot":a=this,Fe.HubSpotConversations?Be(a):(Fe.hsConversationsOnReady=Fe.hsConversationsOnReady||[],Fe.hsConversationsOnReady.push((()=>{Be(a)})))}var a;this.registerWidthAdNetworks(),setTimeout((()=>{this.resolvePendingSocketMessages(),e.dispatch("session-established",t),e.dispatch("session-updated",t)})),this.startRouter(),setTimeout((()=>{var e;(null===(e=this.appContext)||void 0===e?void 0:e.addCurrentPageAsFavorite)&&(this.addHearts(1),this.appContext.addCurrentPageAsFavorite=!1)})),this._pendingPageToHeart&&setTimeout((()=>{this._pendingPageToHeart&&(this.addHearts(1,this._pendingPageToHeart),this._pendingPageToHeart=void 0)})),t.flushBootData&&this.appContext&&Le().removeAllBootData(this.appContext.embedCodeRoot),this._startGaClientPollTimer();const l=(null===(s=this._embedLocalStorage)||void 0===s?void 0:s.getDeferredServerLogMessages(!0))||[];for(const e of l)this.logOnServer(e.message,e.severity,e.data)}startRouter(){this.router.attach()}handleSocketSessionUpdated(t){this.sessionResponse=t,this.connectionState="online",setTimeout((()=>{this.resolvePendingSocketMessages(),e.dispatch("session-updated",t)})),this._startGaClientPollTimer()}handleSocketSessionNotification(t){e.dispatch(`notification-${t.msgType}`,t)}handleSocketSessionDisconnected(){this.connectionState="offline",setTimeout((()=>{e.dispatch("session-offline")})),this._stopGaClientPollTimer()}handleSocketSessionDisabled(){this.connectionState="disabled",setTimeout((()=>{e.dispatch("session-disabled")})),this._stopGaClientPollTimer()}async handleHashChange(t){e.dispatch("route",t)}computeHashUrl(e,t){return this.router.computeHashUrl(e,t)}goto(e){this.router.goto(e)}gotoWithParams(e,t){this.router.gotoWithParams(e,t)}pushHash(e,t){this.router.push(e,t)}replaceHash(e,t){this.router.replace(e,t)}phrase(e){return this.dictionary.getPhrase(e)||""}initializePrebidMonitor(){if(!this.prebidMonitor){this.prebidMonitor=new oe(this);try{this.prebidMonitor.run()}catch(e){console.error("Failed to initialize prebid",e)}}}attachWindowEvents(){this.windowEventsAttached||(this.windowEventsAttached=!0,window.addEventListener("beforeunload",(()=>{this.sessionResponse&&this.endSession()}),!1),window.addEventListener("slick-engagement",this.engagementHandler,{passive:!0}),window.addEventListener("scroll",this.engagementHandler,{passive:!0}),window.addEventListener("keydown",this.engagementHandler,{passive:!0}),window.addEventListener("mousedown",this.engagementHandler,{passive:!0}),window.addEventListener("click",this.engagementHandler,{passive:!0}),window.addEventListener("touchstart",this.engagementHandler,{passive:!0}),window.addEventListener("touchmove",this.engagementHandler,{passive:!0}),window.addEventListener("mousewheel",this.engagementHandler,{passive:!0}),window.addEventListener("DOMMouseScroll",this.engagementHandler,{passive:!0}))}initializeEmbedStoryMonitor(){document.addEventListener("story-analytics",(e=>{const t=e.detail;if(t&&t.action)switch(t.action.type){case"story-loaded":this.widgetAction("story-viewer","story-loaded",0,void 0,t.storyId,{storyId:t.storyId,channelId:t.channelId});break;case"page-impression":this.widgetAction("story-viewer","story-page-impression",0,void 0,t.action.pageId,{storyId:t.storyId,channelId:t.channelId,pageId:t.action.pageId})}}))}saveNavigatingAwayInfo(e,t){this._embedLocalStorage&&(this._embedLocalStorage.navigationInfo={navType:e,originalStart:this.sessionTimestamp,timestamp:Date.now(),pageUrl:window.location.href,widgetType:t})}getUnreportedActivity(e){const t=Math.max(0,Math.min(qe,this.lastEnagementTimestamp-(this.lastPollTimestamp||this.sessionTimestamp)));return e&&(this.lastPollTimestamp=Date.now()),t}pingSession(e){if("online"===this.connectionState&&this.lastEnagementTimestamp>this.lastPollTimestamp){const t={activity:e};this.lastPollTimestamp=Date.now(),this.send("notify","activity",t)}}async notifyFormSubmit(e,t){const i={attributes:e,fields:t};this.send("notify","notify-form-submit",i)}async notifyContentHidden(){this.send("notify","notify-exclusive-content-hidden",{})}async widgetAction(e,t,i,s,o,n){const r=`${e}-${t}`,a=Date.now();if(i>0){if(a-(this.widgetActionDebounceMap.get(r)||0)<=i)return}if(this.widgetActionDebounceMap.set(r,a),"online"===this.connectionState){"nav"===t?this.saveNavigatingAwayInfo("widget-click",e):"link-nav"===t&&this.saveNavigatingAwayInfo("link-click");const i={action:t,type:e,data:n,url:s,variant:o};await this.send("notify","widget-action",i)}}async _send(e,t,i={},s){"online"===this.connectionState&&this.socketManager&&this.socketManager.send(e,t,i,s)}async _request(e,t,i=3e4){if("online"===this.connectionState&&this.socketManager)return this.socketManager.request(e,t,i);throw new Error("Seems like slickstream is offline. try again later.")}async send(e,t,i={},s){return"online"===this.connectionState?this._send(e,t,i,s):new Promise(((o,n)=>{this.pendingSocketMessages.push({isRequest:!1,payload:i,type:t,direction:e,messageId:s,promisePair:[o,n]})}))}async request(e,t,i=3e4){return"online"===this.connectionState?this._request(e,t,i):new Promise(((s,o)=>{this.pendingSocketMessages.push({isRequest:!0,type:e,timeout:i,payload:t,promisePair:[s,o]})}))}async resolvePendingSocketMessages(){for(;this.pendingSocketMessages.length;){const e=this.pendingSocketMessages.shift();if(e)if(e.isRequest)try{const t=await this._request(e.type,e.payload,e.timeout);e.promisePair[0](t)}catch(t){e.promisePair[1](t)}else if(e.direction)try{await this._send(e.direction,e.type,e.payload,e.messageId),e.promisePair[0]()}catch(t){e.promisePair[1](t)}}}async reportPageAction(e,t,i){if("online"===this.connectionState){const s={action:e,url:t,data:i};await this.send("notify","page-action",s)}}_startGaClientPollTimer(){this._gaClientPollTimer||(this._gaClientPollTimer=window.setInterval((()=>{this._reportNewGaClients(),this._gaPollCount++,this._gaPollCount>=3&&this._stopGaClientPollTimer()}),5e3))}_stopGaClientPollTimer(){this._gaClientPollTimer&&(window.clearInterval(this._gaClientPollTimer),this._gaClientPollTimer=0)}async _reportNewGaClients(){if("online"===this.connectionState){if(await this._detectNewGAClients()&&"online"===this.connectionState){const e={gaClients:this._gaClientsAsArray()};await this.send("notify","notify-ga-clients",e)}}}async logOnServer(e,t="debug",i){if(this.sessionResponse){const s={message:e,severity:t,data:i};await this.send("notify","log",s)}}async endSession(){var e,t;if("online"===this.connectionState){const i=this.getUnreportedActivity(!0);if(i){const s={site:(null===(e=this.appContext)||void 0===e?void 0:e.bootData.siteCode)||"",reader:this.readerId,start:this.sessionTimestamp,activity:i,currentTimestamp:Date.now()};this.firstEngagementTimestamp&&(s.firstActivityTimestamp=this.firstEngagementTimestamp),await(null===(t=this.restApi)||void 0===t?void 0:t.endSession(s))}}}registerWidthAdNetworks(){var e,t,i,s,o;if((null===(e=this.sessionResponse)||void 0===e?void 0:e.identity.email)&&(null===(t=this.sessionResponse)||void 0===t?void 0:t.identity.optedIn)){(null===(i=this.sessionResponse)||void 0===i?void 0:i.settings.membership.ignoreMediavineApis)||fe(null===(s=this.sessionResponse)||void 0===s?void 0:s.identity.email);switch((null===(o=this.sessionResponse)||void 0===o?void 0:o.settings.membership.useAdThriveApis)||"if-present"){case"never":break;case"if-present":me(this.sessionResponse.identity.email,!1);break;case"always":me(this.sessionResponse.identity.email,!0)}}}reportGAEvent(e,t,i=!1){var s;if(null===(s=this.sessionResponse)||void 0===s?void 0:s.gaEvent){ue({action:e,label:t,nonInteraction:i,category:"slickstream",value:0})}}async notifyWidgetsRendered(e){if("online"===this.connectionState){const t={timestamp:e};await this.send("notify","widgets-rendered",t)}}async notifyWebVitals(e){const t={stats:e};if("online"!==this.connectionState)return new Promise(((e,i)=>{this.pendingSocketMessages.push({isRequest:!1,payload:t,type:"vital-stats",direction:"notify",promisePair:[e,i]})}));await this.send("notify","vital-stats",t)}async notifyChatStarted(e,t){if("online"===this.connectionState){const i={action:"open",type:e,data:t};await this.send("notify","notify-chatbot-action",i)}}thumbnailUrl(e,t,i){return e.image?this.thumbnailByPageId(e.image.pageId||e.id,t,i):null}thumbnailByPageId(e,t,i){var s;return this.restApi?this.restApi.pageImage(e,t||null,i||null,(null===(s=this.sessionResponse)||void 0===s?void 0:s.imageEpoch)||"0").url:null}getEpoch(){return this.sessionResponse?`${this.sessionResponse.siteEpoch}`:"0"}async getSiteInfo(){var e;if(this.pendingSiteInfo)return Promise.resolve(this.pendingSiteInfo);if(this.siteInfo)return this.siteInfo;this.pendingSiteInfo=this.restApi.siteInfoV2(this.getEpoch(),this.userAuthenticated,(null===(e=this.sessionResponse)||void 0===e?void 0:e.language)||"en");try{return this.siteInfo=await Promise.resolve(this.pendingSiteInfo),this.pendingSiteInfo=void 0,this.siteInfo}catch(e){throw this.pendingSiteInfo=void 0,e}}shouldPinFilmstripOnMobile(){var e;return!this.sessionResponse||!(null===(e=this.sessionResponse.settings.filmstrip)||void 0===e?void 0:e.omitPinnedOnMobile)}async getStripPages(e){var t,i;const s=null===(i=null===(t=this.sessionResponse)||void 0===t?void 0:t.currentPage)||void 0===i?void 0:i.id,o=await this.getRecommendedPages(),n=(await this.getSiteInfo()).pages;e&&o.sort(((e,t)=>e.pinned?-1:t.pinned?1:0));const r=new Set;o.forEach((e=>r.add(e.id)));const a=n.filter((e=>!r.has(e.id)));let l=o.concat(a);return s&&(l=l.filter((e=>e.id!==s))),l}async getRecommendedPages(){return this.sessionResponse?[...this.sessionResponse.recommendedPages]:[]}async adminSignin(e){const t={emailAddress:e};return this.request("admin-start-sign-in",t)}async adminSigninCode(e){const t={confirmationCode:e},i=await this.request("admin-confirm-sign-in",t);return i.success&&this.sessionResponse&&(this.sessionResponse.isSiteAdmin=!0),i}async adminSignOut(){await this.request("admin-sign-out",{}),this.sessionResponse&&(this.sessionResponse.isSiteAdmin=!1)}async adminGetSummary(){return this.request("admin-get-summary",{})}async memberSignout(){return this.memberSignoutWithDelete(!1)}async memberSignoutWithDelete(t){const i={deleteAccountPermanently:t||!1},s=await this.request("signout-membership",i);if(this.sessionResponse){const i=this.sessionResponse.identity;this.sessionResponse.identity=s.identity||{signoutAllowed:!1,status:"anonymous"},this.sessionResponse.totalUserFavorites=s.totalUserFavorites,s.page&&(this.sessionResponse.currentPage=s.page),t&&i.optedIn&&function(){var e,t;ge="";const i=()=>{var e;const t=null===(e=window.$mediavine)||void 0===e?void 0:e.web;try{t.identityOptOut((e=>{e?O("adtech","error","Error Opting out from Mediavine",e):O("adtech","info","Opted out from Mediavine")}))}catch(e){O("adtech","error","Exception Opting out from Mediavine",e)}};(null===(t=null===(e=window.$mediavine)||void 0===e?void 0:e.web)||void 0===t?void 0:t.identityOptOut)?i():(O("adtech","info","Mediavine identityOptOut not present. Waiting for ready event."),window.addEventListener("mediavineIdentityReady",(()=>{O("adtech","info","Mediavine Identity ready event fired."),i()})))}(),setTimeout((()=>{e.dispatch("membership-updated",this.sessionResponse),e.dispatch("membership-status-changed")}))}return s}updateSessionFromMembership(t,i){this.sessionResponse&&(this.sessionResponse.identity=t.identity,this.sessionResponse.totalUserFavorites=t.totalUserFavorites,t.page&&(this.sessionResponse.currentPage=t.page),setTimeout((()=>{e.dispatch("membership-updated",this.sessionResponse),e.dispatch("membership-status-changed")}))),i&&this.registerWidthAdNetworks()}async memberSignin(e,t){const i={isSignUp:!1,emailAddress:e,password:window.btoa(t)},s=await this.request("set-membership",i);return this.updateSessionFromMembership(s,!0),s}async memberSignup(e,t,i,s){var o,n;const r={isSignUp:!0,emailAddress:e,password:window.btoa(t),name:s,allowEmailContact:i},a=await this.request("set-membership",r);if(this.updateSessionFromMembership(a,!1),i){(null===(o=this.sessionResponse)||void 0===o?void 0:o.settings.membership.ignoreMediavineApis)||fe(e);switch((null===(n=this.sessionResponse)||void 0===n?void 0:n.settings.membership.useAdThriveApis)||"if-present"){case"never":break;case"if-present":me(e,!1);break;case"always":me(e,!0)}}return a}async memberResetPassword(e,t,i){const s={isSignUp:!1,emailAddress:e,password:window.btoa(t),confCode:i},o=await this.request("set-membership",s);return this.updateSessionFromMembership(o,!1),o}async requestMemberPasswordReset(e){const t={emailAddress:e,returnToUrl:window.location.href};await this.request("request-reset-membership-password",t)}async resetPasswordWithCode(e,t){const i={code:e,password:window.btoa(t)},s=await this.request("reset-password-with-code",i);return this.updateSessionFromMembership(s,!1),s}async validateResetPasswordCode(e){return this.request("validate-reset-password-code",{code:e})}async checkMembership(e){const t={emailAddress:e};return this.request("check-membership",t)}async addHearts(t,i){var s;i||this.sessionResponse&&this.sessionResponse.currentPage&&(i=this.sessionResponse.currentPage.id);let o=!1;const n={count:t,pageId:i},r=null===(s=this.sessionResponse)||void 0===s?void 0:s.currentPage;this.sessionResponse&&r&&r.id===i?r.isFavorite||(r.totalFavorites=(r.totalFavorites||0)+1,r.isFavorite=!0,this.sessionResponse.totalUserFavorites=(this.sessionResponse.totalUserFavorites||0)+1,o=!0):i&&this.sessionResponse&&(this.sessionResponse.totalUserFavorites=(this.sessionResponse.totalUserFavorites||0)+1,o=!0),o&&setTimeout((()=>{e.dispatch("membership-updated",this.sessionResponse)}));const a=await this.request("heart",n);return this.reportGAEvent("favorite-added","Slickstream favorite added"),a}async removeFavorite(t){const i={pageId:t};await this.request("delete-favorite",i),this.sessionResponse&&this.sessionResponse.currentPage&&this.sessionResponse.currentPage.id===t&&(this.sessionResponse.currentPage.totalFavorites=Math.max(0,(this.sessionResponse.currentPage.totalFavorites||1)-1),this.sessionResponse.currentPage.isFavorite=!1),this.sessionResponse&&(this.sessionResponse.totalUserFavorites=Math.max(0,(this.sessionResponse.totalUserFavorites||0)-1),setTimeout((()=>{e.dispatch("membership-updated",this.sessionResponse)})))}isMemberSignedIn(){var e,t;return!!(null===(t=null===(e=this.sessionResponse)||void 0===e?void 0:e.identity)||void 0===t?void 0:t.email)}shouldSigninToFav(){return!!this.sessionResponse&&((!this.sessionResponse.identity||!this.sessionResponse.identity.email)&&"mandatory-membership"===this.sessionResponse.settings.membership.behavior)}async getGame(e){const t={slot:e||""};return this.request("get-game",t)}async updateGame(e,t,i){const s={id:e,status:t,data:i};await this.request("update-game",s)}async fastSearch(e,t,i,s,o,n,r){const a={searchString:t,speed:"fast",drillContext:o,width:i,height:s,arrangement:n,action:"type",widgetId:r,widgetType:e};return this.request("search4-search",a)}async fullSearch(e,t,i,s,o,n,r,a,l){const c={searchString:t,speed:"full",drillContext:n,width:i,height:s,arrangement:a,requestedGroup:r,action:o,widgetId:l,widgetType:e};return this.request("search4-search",c)}async fetchMoreSearchResults(e,t,i){const s={moreContext:e,width:t,height:i};return this.request("search4-more",s)}async search(e,t,i){const s={searchString:e,maxItems:100,userAction:t,contextId:i};return this.request("search3-search",s)}async searchSelectCard(e,t,i){const s={maxItems:100,searchString:e,selectedCardId:t,contextId:i};return this.request("search3-select-card",s)}async searchMoreCards(e){const t={type:"more-cards",maxItems:100,moreContext:e};return this.request("search3-more",t)}async searchMorePages(e,t,i=100){const s={type:"more-pages",maxItems:i,moreContext:e,reason:t};return this.request("search3-more",s)}async getPageInfo(e){const t={storyUrl:e};return this.request("query-page",t)}async getStoryPageInfo(e,t){const i={storyIds:{channelId:e,storyId:t}};return this.request("query-page",i)}async populateStories(){if(this._storyItems&&this._storyItems.length)return[...this._storyItems];const e=await this.request("populate-story-carousel",{});return this._storyItems=e.items,[...this._storyItems]}async contentGridItems(e,t){const i={id:t||"",count:e};return(await this.request("populate-content-grid",i)).items}async populateSlots(e){const t={slots:e};return(await this.request("populate-slots",t)).slots||[]}async notifySlotImpression(e){const t={id:e};this.send("notify","notify-slot-impression",t)}async notifySlotAction(e,t){const i={id:e,data:{href:t}};this.send("notify","notify-slot-action",i)}async getTheme(e=!1){if(this._pendingThemePromise)return Promise.resolve(this._pendingThemePromise);this._pendingThemePromise=this._getTheme(e);try{return await this._pendingThemePromise}finally{this._pendingThemePromise=void 0}}async _getTheme(e=!1){const t=await B();if(!e){if(this.currentTheme)return this.currentTheme;if(!this.currentSession){const e=await t.getLastTheme();if(e)return this.currentTheme=e,this.currentTheme}}if(this.currentSession)try{const e=await B();let t=await e.getTheme(this.currentSession.settings.themeId,this.currentSession.settings.themeVersion);t?this.currentTheme=t:this.restApi&&(t=await this.restApi.theme(this.currentSession.settings.themeId,this.currentSession.settings.themeVersion),t&&(this.currentTheme=t,e.addTheme(t)))}catch(e){O("services","error","Failed to load theme",e)}return this.currentTheme||null}async _loadLanguage(e,t){try{const i=await B();let s=await i.getLocalization(e,t);if(!s&&this.restApi)try{s=await this.restApi.localizationPhrases(e,t),s&&await i.setLocalization(e,t,s)}catch(e){O("services","error","Failed to fetch language data",e),s=null}return s}catch(e){O("services","error","Failed to load language data",e)}return null}toast(e){this.snackbar||(this.snackbar=document.querySelector(We)),this.snackbar&&this.snackbar.show(e)}},Qe=window,Xe=Qe.ShadowRoot&&(void 0===Qe.ShadyCSS||Qe.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,Je=Symbol(),et=new WeakMap;class tt{constructor(e,t,i){if(this._$cssResult$=!0,i!==Je)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o;const t=this.t;if(Xe&&void 0===e){const i=void 0!==t&&1===t.length;i&&(e=et.get(t)),void 0===e&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),i&&et.set(t,e))}return e}toString(){return this.cssText}}const it=(e,...t)=>{const i=1===e.length?e[0]:t.reduce(((t,i,s)=>t+(e=>{if(!0===e._$cssResult$)return e.cssText;if("number"==typeof e)return e;throw Error("Value passed to 'css' function must be a 'css' function result: "+e+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(i)+e[s+1]),e[0]);return new tt(i,e,Je)},st=Xe?e=>e:e=>e instanceof CSSStyleSheet?(e=>{let t="";for(const i of e.cssRules)t+=i.cssText;return(e=>new tt("string"==typeof e?e:e+"",void 0,Je))(t)})(e):e;var ot;const nt=window,rt=nt.trustedTypes,at=rt?rt.emptyScript:"",lt=nt.reactiveElementPolyfillSupport,ct={toAttribute(e,t){switch(t){case Boolean:e=e?at:null;break;case Object:case Array:e=null==e?e:JSON.stringify(e)}return e},fromAttribute(e,t){let i=e;switch(t){case Boolean:i=null!==e;break;case Number:i=null===e?null:Number(e);break;case Object:case Array:try{i=JSON.parse(e)}catch(e){i=null}}return i}},ht=(e,t)=>t!==e&&(t==t||e==e),dt={attribute:!0,type:String,converter:ct,reflect:!1,hasChanged:ht};class pt extends HTMLElement{constructor(){super(),this._$Ei=new Map,this.isUpdatePending=!1,this.hasUpdated=!1,this._$El=null,this.u()}static addInitializer(e){var t;this.finalize(),(null!==(t=this.h)&&void 0!==t?t:this.h=[]).push(e)}static get observedAttributes(){this.finalize();const e=[];return this.elementProperties.forEach(((t,i)=>{const s=this._$Ep(i,t);void 0!==s&&(this._$Ev.set(s,i),e.push(s))})),e}static createProperty(e,t=dt){if(t.state&&(t.attribute=!1),this.finalize(),this.elementProperties.set(e,t),!t.noAccessor&&!this.prototype.hasOwnProperty(e)){const i="symbol"==typeof e?Symbol():"__"+e,s=this.getPropertyDescriptor(e,i,t);void 0!==s&&Object.defineProperty(this.prototype,e,s)}}static getPropertyDescriptor(e,t,i){return{get(){return this[t]},set(s){const o=this[e];this[t]=s,this.requestUpdate(e,o,i)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)||dt}static finalize(){if(this.hasOwnProperty("finalized"))return!1;this.finalized=!0;const e=Object.getPrototypeOf(this);if(e.finalize(),void 0!==e.h&&(this.h=[...e.h]),this.elementProperties=new Map(e.elementProperties),this._$Ev=new Map,this.hasOwnProperty("properties")){const e=this.properties,t=[...Object.getOwnPropertyNames(e),...Object.getOwnPropertySymbols(e)];for(const i of t)this.createProperty(i,e[i])}return this.elementStyles=this.finalizeStyles(this.styles),!0}static finalizeStyles(e){const t=[];if(Array.isArray(e)){const i=new Set(e.flat(1/0).reverse());for(const e of i)t.unshift(st(e))}else void 0!==e&&t.push(st(e));return t}static _$Ep(e,t){const i=t.attribute;return!1===i?void 0:"string"==typeof i?i:"string"==typeof e?e.toLowerCase():void 0}u(){var e;this._$E_=new Promise((e=>this.enableUpdating=e)),this._$AL=new Map,this._$Eg(),this.requestUpdate(),null===(e=this.constructor.h)||void 0===e||e.forEach((e=>e(this)))}addController(e){var t,i;(null!==(t=this._$ES)&&void 0!==t?t:this._$ES=[]).push(e),void 0!==this.renderRoot&&this.isConnected&&(null===(i=e.hostConnected)||void 0===i||i.call(e))}removeController(e){var t;null===(t=this._$ES)||void 0===t||t.splice(this._$ES.indexOf(e)>>>0,1)}_$Eg(){this.constructor.elementProperties.forEach(((e,t)=>{this.hasOwnProperty(t)&&(this._$Ei.set(t,this[t]),delete this[t])}))}createRenderRoot(){var e;const t=null!==(e=this.shadowRoot)&&void 0!==e?e:this.attachShadow(this.constructor.shadowRootOptions);return((e,t)=>{Xe?e.adoptedStyleSheets=t.map((e=>e instanceof CSSStyleSheet?e:e.styleSheet)):t.forEach((t=>{const i=document.createElement("style"),s=Qe.litNonce;void 0!==s&&i.setAttribute("nonce",s),i.textContent=t.cssText,e.appendChild(i)}))})(t,this.constructor.elementStyles),t}connectedCallback(){var e;void 0===this.renderRoot&&(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),null===(e=this._$ES)||void 0===e||e.forEach((e=>{var t;return null===(t=e.hostConnected)||void 0===t?void 0:t.call(e)}))}enableUpdating(e){}disconnectedCallback(){var e;null===(e=this._$ES)||void 0===e||e.forEach((e=>{var t;return null===(t=e.hostDisconnected)||void 0===t?void 0:t.call(e)}))}attributeChangedCallback(e,t,i){this._$AK(e,i)}_$EO(e,t,i=dt){var s;const o=this.constructor._$Ep(e,i);if(void 0!==o&&!0===i.reflect){const n=(void 0!==(null===(s=i.converter)||void 0===s?void 0:s.toAttribute)?i.converter:ct).toAttribute(t,i.type);this._$El=e,null==n?this.removeAttribute(o):this.setAttribute(o,n),this._$El=null}}_$AK(e,t){var i;const s=this.constructor,o=s._$Ev.get(e);if(void 0!==o&&this._$El!==o){const e=s.getPropertyOptions(o),n="function"==typeof e.converter?{fromAttribute:e.converter}:void 0!==(null===(i=e.converter)||void 0===i?void 0:i.fromAttribute)?e.converter:ct;this._$El=o,this[o]=n.fromAttribute(t,e.type),this._$El=null}}requestUpdate(e,t,i){let s=!0;void 0!==e&&(((i=i||this.constructor.getPropertyOptions(e)).hasChanged||ht)(this[e],t)?(this._$AL.has(e)||this._$AL.set(e,t),!0===i.reflect&&this._$El!==e&&(void 0===this._$EC&&(this._$EC=new Map),this._$EC.set(e,i))):s=!1),!this.isUpdatePending&&s&&(this._$E_=this._$Ej())}async _$Ej(){this.isUpdatePending=!0;try{await this._$E_}catch(e){Promise.reject(e)}const e=this.scheduleUpdate();return null!=e&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){var e;if(!this.isUpdatePending)return;this.hasUpdated,this._$Ei&&(this._$Ei.forEach(((e,t)=>this[t]=e)),this._$Ei=void 0);let t=!1;const i=this._$AL;try{t=this.shouldUpdate(i),t?(this.willUpdate(i),null===(e=this._$ES)||void 0===e||e.forEach((e=>{var t;return null===(t=e.hostUpdate)||void 0===t?void 0:t.call(e)})),this.update(i)):this._$Ek()}catch(e){throw t=!1,this._$Ek(),e}t&&this._$AE(i)}willUpdate(e){}_$AE(e){var t;null===(t=this._$ES)||void 0===t||t.forEach((e=>{var t;return null===(t=e.hostUpdated)||void 0===t?void 0:t.call(e)})),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$Ek(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$E_}shouldUpdate(e){return!0}update(e){void 0!==this._$EC&&(this._$EC.forEach(((e,t)=>this._$EO(t,this[t],e))),this._$EC=void 0),this._$Ek()}updated(e){}firstUpdated(e){}}var ut;pt.finalized=!0,pt.elementProperties=new Map,pt.elementStyles=[],pt.shadowRootOptions={mode:"open"},null==lt||lt({ReactiveElement:pt}),(null!==(ot=nt.reactiveElementVersions)&&void 0!==ot?ot:nt.reactiveElementVersions=[]).push("1.6.1");const gt=window,ft=gt.trustedTypes,vt=ft?ft.createPolicy("lit-html",{createHTML:e=>e}):void 0,mt="$lit$",yt=`lit$${(Math.random()+"").slice(9)}$`,bt="?"+yt,wt=`<${bt}>`,xt=document,kt=()=>xt.createComment(""),St=e=>null===e||"object"!=typeof e&&"function"!=typeof e,_t=Array.isArray,Ct=e=>_t(e)||"function"==typeof(null==e?void 0:e[Symbol.iterator]),$t="[ \t\n\f\r]",Pt=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,It=/-->/g,Tt=/>/g,Ot=RegExp(`>|${$t}(?:([^\\s"'>=/]+)(${$t}*=${$t}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,"g"),Rt=/'/g,Et=/"/g,jt=/^(?:script|style|textarea|title)$/i,Lt=(e=>(t,...i)=>({_$litType$:e,strings:t,values:i}))(1),zt=Symbol.for("lit-noChange"),Mt=Symbol.for("lit-nothing"),At=new WeakMap,Dt=xt.createTreeWalker(xt,129,null,!1),Ht=(e,t)=>{const i=e.length-1,s=[];let o,n=2===t?"<svg>":"",r=Pt;for(let t=0;t<i;t++){const i=e[t];let a,l,c=-1,h=0;for(;h<i.length&&(r.lastIndex=h,l=r.exec(i),null!==l);)h=r.lastIndex,r===Pt?"!--"===l[1]?r=It:void 0!==l[1]?r=Tt:void 0!==l[2]?(jt.test(l[2])&&(o=RegExp("</"+l[2],"g")),r=Ot):void 0!==l[3]&&(r=Ot):r===Ot?">"===l[0]?(r=null!=o?o:Pt,c=-1):void 0===l[1]?c=-2:(c=r.lastIndex-l[2].length,a=l[1],r=void 0===l[3]?Ot:'"'===l[3]?Et:Rt):r===Et||r===Rt?r=Ot:r===It||r===Tt?r=Pt:(r=Ot,o=void 0);const d=r===Ot&&e[t+1].startsWith("/>")?" ":"";n+=r===Pt?i+wt:c>=0?(s.push(a),i.slice(0,c)+mt+i.slice(c)+yt+d):i+yt+(-2===c?(s.push(void 0),t):d)}const a=n+(e[i]||"<?>")+(2===t?"</svg>":"");if(!Array.isArray(e)||!e.hasOwnProperty("raw"))throw Error("invalid template strings array");return[void 0!==vt?vt.createHTML(a):a,s]};class Ft{constructor({strings:e,_$litType$:t},i){let s;this.parts=[];let o=0,n=0;const r=e.length-1,a=this.parts,[l,c]=Ht(e,t);if(this.el=Ft.createElement(l,i),Dt.currentNode=this.el.content,2===t){const e=this.el.content,t=e.firstChild;t.remove(),e.append(...t.childNodes)}for(;null!==(s=Dt.nextNode())&&a.length<r;){if(1===s.nodeType){if(s.hasAttributes()){const e=[];for(const t of s.getAttributeNames())if(t.endsWith(mt)||t.startsWith(yt)){const i=c[n++];if(e.push(t),void 0!==i){const e=s.getAttribute(i.toLowerCase()+mt).split(yt),t=/([.?@])?(.*)/.exec(i);a.push({type:1,index:o,name:t[2],strings:e,ctor:"."===t[1]?qt:"?"===t[1]?Gt:"@"===t[1]?Kt:Vt})}else a.push({type:6,index:o})}for(const t of e)s.removeAttribute(t)}if(jt.test(s.tagName)){const e=s.textContent.split(yt),t=e.length-1;if(t>0){s.textContent=ft?ft.emptyScript:"";for(let i=0;i<t;i++)s.append(e[i],kt()),Dt.nextNode(),a.push({type:2,index:++o});s.append(e[t],kt())}}}else if(8===s.nodeType)if(s.data===bt)a.push({type:2,index:o});else{let e=-1;for(;-1!==(e=s.data.indexOf(yt,e+1));)a.push({type:7,index:o}),e+=yt.length-1}o++}}static createElement(e,t){const i=xt.createElement("template");return i.innerHTML=e,i}}function Bt(e,t,i=e,s){var o,n,r,a;if(t===zt)return t;let l=void 0!==s?null===(o=i._$Co)||void 0===o?void 0:o[s]:i._$Cl;const c=St(t)?void 0:t._$litDirective$;return(null==l?void 0:l.constructor)!==c&&(null===(n=null==l?void 0:l._$AO)||void 0===n||n.call(l,!1),void 0===c?l=void 0:(l=new c(e),l._$AT(e,i,s)),void 0!==s?(null!==(r=(a=i)._$Co)&&void 0!==r?r:a._$Co=[])[s]=l:i._$Cl=l),void 0!==l&&(t=Bt(e,l._$AS(e,t.values),l,s)),t}class Ut{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){var t;const{el:{content:i},parts:s}=this._$AD,o=(null!==(t=null==e?void 0:e.creationScope)&&void 0!==t?t:xt).importNode(i,!0);Dt.currentNode=o;let n=Dt.nextNode(),r=0,a=0,l=s[0];for(;void 0!==l;){if(r===l.index){let t;2===l.type?t=new Nt(n,n.nextSibling,this,e):1===l.type?t=new l.ctor(n,l.name,l.strings,this,e):6===l.type&&(t=new Yt(n,this,e)),this._$AV.push(t),l=s[++a]}r!==(null==l?void 0:l.index)&&(n=Dt.nextNode(),r++)}return o}v(e){let t=0;for(const i of this._$AV)void 0!==i&&(void 0!==i.strings?(i._$AI(e,i,t),t+=i.strings.length-2):i._$AI(e[t])),t++}}class Nt{constructor(e,t,i,s){var o;this.type=2,this._$AH=Mt,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=i,this.options=s,this._$Cp=null===(o=null==s?void 0:s.isConnected)||void 0===o||o}get _$AU(){var e,t;return null!==(t=null===(e=this._$AM)||void 0===e?void 0:e._$AU)&&void 0!==t?t:this._$Cp}get parentNode(){let e=this._$AA.parentNode;const t=this._$AM;return void 0!==t&&11===(null==e?void 0:e.nodeType)&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=Bt(this,e,t),St(e)?e===Mt||null==e||""===e?(this._$AH!==Mt&&this._$AR(),this._$AH=Mt):e!==this._$AH&&e!==zt&&this._(e):void 0!==e._$litType$?this.g(e):void 0!==e.nodeType?this.$(e):Ct(e)?this.T(e):this._(e)}k(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}$(e){this._$AH!==e&&(this._$AR(),this._$AH=this.k(e))}_(e){this._$AH!==Mt&&St(this._$AH)?this._$AA.nextSibling.data=e:this.$(xt.createTextNode(e)),this._$AH=e}g(e){var t;const{values:i,_$litType$:s}=e,o="number"==typeof s?this._$AC(e):(void 0===s.el&&(s.el=Ft.createElement(s.h,this.options)),s);if((null===(t=this._$AH)||void 0===t?void 0:t._$AD)===o)this._$AH.v(i);else{const e=new Ut(o,this),t=e.u(this.options);e.v(i),this.$(t),this._$AH=e}}_$AC(e){let t=At.get(e.strings);return void 0===t&&At.set(e.strings,t=new Ft(e)),t}T(e){_t(this._$AH)||(this._$AH=[],this._$AR());const t=this._$AH;let i,s=0;for(const o of e)s===t.length?t.push(i=new Nt(this.k(kt()),this.k(kt()),this,this.options)):i=t[s],i._$AI(o),s++;s<t.length&&(this._$AR(i&&i._$AB.nextSibling,s),t.length=s)}_$AR(e=this._$AA.nextSibling,t){var i;for(null===(i=this._$AP)||void 0===i||i.call(this,!1,!0,t);e&&e!==this._$AB;){const t=e.nextSibling;e.remove(),e=t}}setConnected(e){var t;void 0===this._$AM&&(this._$Cp=e,null===(t=this._$AP)||void 0===t||t.call(this,e))}}class Vt{constructor(e,t,i,s,o){this.type=1,this._$AH=Mt,this._$AN=void 0,this.element=e,this.name=t,this._$AM=s,this.options=o,i.length>2||""!==i[0]||""!==i[1]?(this._$AH=Array(i.length-1).fill(new String),this.strings=i):this._$AH=Mt}get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}_$AI(e,t=this,i,s){const o=this.strings;let n=!1;if(void 0===o)e=Bt(this,e,t,0),n=!St(e)||e!==this._$AH&&e!==zt,n&&(this._$AH=e);else{const s=e;let r,a;for(e=o[0],r=0;r<o.length-1;r++)a=Bt(this,s[i+r],t,r),a===zt&&(a=this._$AH[r]),n||(n=!St(a)||a!==this._$AH[r]),a===Mt?e=Mt:e!==Mt&&(e+=(null!=a?a:"")+o[r+1]),this._$AH[r]=a}n&&!s&&this.j(e)}j(e){e===Mt?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,null!=e?e:"")}}class qt extends Vt{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===Mt?void 0:e}}const Wt=ft?ft.emptyScript:"";class Gt extends Vt{constructor(){super(...arguments),this.type=4}j(e){e&&e!==Mt?this.element.setAttribute(this.name,Wt):this.element.removeAttribute(this.name)}}class Kt extends Vt{constructor(e,t,i,s,o){super(e,t,i,s,o),this.type=5}_$AI(e,t=this){var i;if((e=null!==(i=Bt(this,e,t,0))&&void 0!==i?i:Mt)===zt)return;const s=this._$AH,o=e===Mt&&s!==Mt||e.capture!==s.capture||e.once!==s.once||e.passive!==s.passive,n=e!==Mt&&(s===Mt||o);o&&this.element.removeEventListener(this.name,this,s),n&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){var t,i;"function"==typeof this._$AH?this._$AH.call(null!==(i=null===(t=this.options)||void 0===t?void 0:t.host)&&void 0!==i?i:this.element,e):this._$AH.handleEvent(e)}}class Yt{constructor(e,t,i){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(e){Bt(this,e)}}const Zt={O:mt,P:yt,A:bt,C:1,M:Ht,L:Ut,D:Ct,R:Bt,I:Nt,V:Vt,H:Gt,N:Kt,U:qt,F:Yt},Qt=gt.litHtmlPolyfillSupport;null==Qt||Qt(Ft,Nt),(null!==(ut=gt.litHtmlVersions)&&void 0!==ut?ut:gt.litHtmlVersions=[]).push("2.7.2");var Xt,Jt;class ei extends pt{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){var e,t;const i=super.createRenderRoot();return null!==(e=(t=this.renderOptions).renderBefore)&&void 0!==e||(t.renderBefore=i.firstChild),i}update(e){const t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=((e,t,i)=>{var s,o;const n=null!==(s=null==i?void 0:i.renderBefore)&&void 0!==s?s:t;let r=n._$litPart$;if(void 0===r){const e=null!==(o=null==i?void 0:i.renderBefore)&&void 0!==o?o:null;n._$litPart$=r=new Nt(t.insertBefore(kt(),e),e,void 0,null!=i?i:{})}return r._$AI(e),r})(t,this.renderRoot,this.renderOptions)}connectedCallback(){var e;super.connectedCallback(),null===(e=this._$Do)||void 0===e||e.setConnected(!0)}disconnectedCallback(){var e;super.disconnectedCallback(),null===(e=this._$Do)||void 0===e||e.setConnected(!1)}render(){return zt}}ei.finalized=!0,ei._$litElement$=!0,null===(Xt=globalThis.litElementHydrateSupport)||void 0===Xt||Xt.call(globalThis,{LitElement:ei});const ti=globalThis.litElementPolyfillSupport;null==ti||ti({LitElement:ei}),(null!==(Jt=globalThis.litElementVersions)&&void 0!==Jt?Jt:globalThis.litElementVersions=[]).push("3.3.1");const ii=e=>t=>"function"==typeof t?((e,t)=>(customElements.define(e,t),t))(e,t):((e,t)=>{const{kind:i,elements:s}=t;return{kind:i,elements:s,finisher(t){customElements.define(e,t)}}})(e,t),si=(e,t)=>"method"===t.kind&&t.descriptor&&!("value"in t.descriptor)?{...t,finisher(i){i.createProperty(t.key,e)}}:{kind:"field",key:Symbol(),placement:"own",descriptor:{},originalKey:t.key,initializer(){"function"==typeof t.initializer&&(this[t.key]=t.initializer.call(this))},finisher(i){i.createProperty(t.key,e)}};function oi(e){return(t,i)=>void 0!==i?((e,t,i)=>{t.constructor.createProperty(i,e)})(e,t,i):si(e,t)}function ni(e){return oi({...e,state:!0})}const ri=({finisher:e,descriptor:t})=>(i,s)=>{var o;if(void 0===s){const s=null!==(o=i.originalKey)&&void 0!==o?o:i.key,n=null!=t?{kind:"method",placement:"prototype",key:s,descriptor:t(i.key)}:{...i,key:s};return null!=e&&(n.finisher=function(t){e(t,s)}),n}{const o=i.constructor;void 0!==t&&Object.defineProperty(i,s,t(s)),null==e||e(o,s)}};function ai(e,t){return ri({descriptor:i=>{const s={get(){var t,i;return null!==(i=null===(t=this.renderRoot)||void 0===t?void 0:t.querySelector(e))&&void 0!==i?i:null},enumerable:!0,configurable:!0};if(t){const t="symbol"==typeof i?Symbol():"__"+i;s.get=function(){var i,s;return void 0===this[t]&&(this[t]=null!==(s=null===(i=this.renderRoot)||void 0===i?void 0:i.querySelector(e))&&void 0!==s?s:null),this[t]}}return s}})}var li;null===(li=window.HTMLSlotElement)||void 0===li||li.prototype.assignedElements;const ci="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=",hi=it`
.layout.horizontal,
.layout.vertical {
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
}
.layout.horizontal {
  -ms-flex-direction: row;
  -webkit-flex-direction: row;
  flex-direction: row;
}
.layout.vertical {
  -ms-flex-direction: column;
  -webkit-flex-direction: column;
  flex-direction: column;
}
.layout.center {
  -ms-flex-align: center;
  -webkit-align-items: center;
  align-items: center;
}
.layout.wrap {
  -ms-flex-wrap: wrap;
  -webkit-flex-wrap: wrap;
  flex-wrap: wrap;
}
.flex {
  -ms-flex: 1 1 0.000000001px;
  -webkit-flex: 1;
  flex: 1;
  -webkit-flex-basis: 0.000000001px;
  flex-basis: 0.000000001px;
}
`,di=window;function pi(e,t,i,s=!0,o=!0){if(t){const n={bubbles:"boolean"!=typeof s||s,composed:"boolean"!=typeof o||o};i&&(n.detail=i);const r=di.SlickCustomEvent||CustomEvent;e.dispatchEvent(new r(t,n))}}function ui(e,t){const i={bubbles:!0,composed:!0};t&&(i.detail=t);return new(di.SlickCustomEvent||CustomEvent)(e,i)}async function gi(e,t){const i=Date.now();for(;;){const s=document.querySelector(e);if(s)return s;if(Date.now()-i>=t)throw new Error("Timeout");await X(200)}}async function fi(e){try{const t=await gi(e,3e3);return function(e){const t=e.getBoundingClientRect();if(t.width&&t.height){if(void 0!==window.getComputedStyle){const t=window.getComputedStyle(e);if("0"===t.opacity||"hidden"===t.visibility)return!1}return!0}return!1}(t)?t:null}catch(e){}return null}async function vi(e,t){const i=Date.now();for(;;){const s=document.querySelectorAll(e);if(s&&s.length){const e=[];for(let t=0;t<s.length;t++)e.push(s.item(t));return e}if(Date.now()-i>=t)return[];await X(200)}}let mi;function yi(){const e=document.querySelector("slick-boot-search-loading");e&&e.remove()}function bi(){const e=document.querySelector("slick-boot-hearts");e&&e.remove()}class wi{constructor(e,t,i){this.itemwidth=100,this.buffer=4,this.resizeDebounceInterval=250,this.endpadding=0,this.count=0,this.cells=[],this.scrollHandler=()=>this.position(),this.currentRenderRange=[-1,-1],this.renderRangeDirty=!1,this.container=e,this.dir=i||"ltr",this.scrollElement=t}set delegate(e){this._delegate=e,this.refresh()}get scroller(){return this.scrollElement||this.container.parentElement||document.body}clear(){for(;this.container.hasChildNodes()&&this.container.lastChild;)this.container.removeChild(this.container.lastChild);this.cells=[],this.scroller.removeEventListener("scroll",this.scrollHandler),this.resizeHandler&&window.removeEventListener("resize",this.resizeHandler)}refresh(){this.clear(),this.count=this._delegate?this._delegate.length:0;const e=this.count*this.itemwidth+this.endpadding;this.container.style.minWidth=`${e}px`,this.renderRangeDirty=!0,this.position(),this.scroller.addEventListener("scroll",this.scrollHandler),this.resizeHandler=te(this.position.bind(this),this.resizeDebounceInterval,!1,this),window.addEventListener("resize",this.resizeHandler)}position(){if(!this._delegate)return;const e=this.computeRanges()[1];if(!this.renderRangeDirty&&e[0]===this.currentRenderRange[0]&&e[1]===this.currentRenderRange[1])return;this.renderRangeDirty=!1,this.currentRenderRange=e;const t=new Map,i=this.cells.filter((i=>i.index<e[0]||i.index>e[1]||(t.set(i.index,i),!1))),s=[];for(let i=e[0];i<=e[1];i++)t.has(i)||s.push(i);for(;s.length&&i.length;){const e=s.shift(),o=i.shift();if(void 0===e||void 0===o)break;o.index=e,this._delegate.updateElement(o.node,e),this.positionCell(o.node,e),t.set(e,o)}for(;i.length;){const e=i.shift();if(void 0===e)break;this.container.removeChild(e.node)}for(;s.length;){const e=s.shift();if(void 0===e)break;const i=this._delegate.createElement();i.style.position="absolute",this.container.appendChild(i),this._delegate.updateElement(i,e),this.positionCell(i,e),t.set(e,{index:e,node:i})}this.cells=Array.from(t.values())}positionCell(e,t){e.style.transform=`translate(${Math.round(t*this.itemwidth)*("rtl"===this.dir?-1:1)}px, 0)`}computeRanges(){const e=Math.abs(this.scroller.scrollLeft),t=this.count*this.itemwidth||1,i=Math.max(0,Math.min(this.count-1,Math.floor(e/(t||1)*this.count))),s=Math.max(0,Math.min(this.count-1,Math.floor((e+this.scroller.getBoundingClientRect().width)/(t||1)*this.count))),o=Math.max(0,i-Math.floor(this.buffer/2));return[[i,s],[o,Math.min(this.count-1,s+this.buffer-(i-o))]]}scrollToIndex(e){this._delegate&&Number.isFinite(e)&&(e=Math.min(this._delegate.length,Math.max(0,e)),this.scroller.scrollLeft=e*this.itemwidth)}}var xi=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},ki=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Si=class extends ei{constructor(){super(...arguments),this.dir="ltr",this.itemwidth=100,this.buffer=2,this.endpadding=0}render(){return Lt`
    <style>
      :host {
        display: block;
        overflow: auto;
        box-sizing: border-box;
        width: 100%;
        height: var(--slick-virtual-list-height, 100px);
      }
      #container {
        position: relative;
        height: var(--slick-virtual-list-height, 100px);
        box-sizing: border-box;
      }
    </style>
    <div id="container"></div>
    `}updated(){this.vl||(this.vl=new wi(this._container,this,this.dir)),this.vl.itemwidth=this.itemwidth,this.vl.buffer=this.buffer,this.vl.endpadding=this.endpadding,this._delegate&&(this.vl.delegate=this._delegate)}connectedCallback(){this.dir="rtl"===document.documentElement.dir?"rtl":"ltr",super.connectedCallback()}disconnectedCallback(){super.disconnectedCallback(),this.vl&&this.vl.clear()}set delegate(e){this._delegate=e,this.vl&&(this.vl.delegate=e)}refresh(){this.vl&&this.vl.position()}scrollToIndex(e){this.vl&&this.vl.scrollToIndex(e)}get container(){return this._container}};xi([oi({type:Number}),ki("design:type",Object)],Si.prototype,"itemwidth",void 0),xi([oi({type:Number}),ki("design:type",Object)],Si.prototype,"buffer",void 0),xi([oi({type:Number}),ki("design:type",Object)],Si.prototype,"endpadding",void 0),xi([ai("#container"),ki("design:type",HTMLDivElement)],Si.prototype,"_container",void 0),Si=xi([ii("virtual-list")],Si);var _i=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Ci=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let $i=class extends ei{constructor(){super(...arguments),this.dir="ltr",this.cellheight=80,this.cellwidth=80,this.arrows=!1,this.endpadding=0,this.firstVisibleIndex=-1,this.lastVisibleIndex=-1,this.animating=!1,this.animationStart=0,this.scrollAnimationData=[0,0],this.connected=!1}render(){const e=`--slick-virtual-list-height: ${this.cellheight}px;`;return Lt`
    <style>
      :host {
        display: block;
      }
      #hs {
        -webkit-overflow-scrolling: touch;
        overflow-x: auto;
        overflow-y: hidden;
        -ms-overflow-style: none;
        scrollbar-width: none;
      }
      #hs::-webkit-scrollbar {
        width: 0px;
        height: 0px;
        background: transparent;
      }
    </style>
    <virtual-list id="hs" .endpadding="${this.endpadding}" .itemwidth="${this.cellwidth}" style="${e}" @scroll="${()=>this.onScroll()}"></virtual-list>
    `}connectedCallback(){this.dir="rtl"===document.documentElement.dir?"rtl":"ltr",super.connectedCallback()}firstUpdated(){this.connected=!0,this.refreshSliderDelegate()}set delegate(e){this._delegate=e,this.refreshSliderDelegate()}refreshSliderDelegate(){this.connected&&this._delegate&&(this.$("hs").delegate=this._delegate,this.slideToValue(0),this._onScroll(!0))}slideToValue(e){if(this._delegate){const t=this.$("hs");t.getBoundingClientRect().width?t.scrollLeft=e*this.cellwidth:window.setTimeout((()=>{this.slideToValue(e)}),1e3)}}onScroll(){this._onScroll(!1)}_onScroll(e){this.refreshVisibilityWindow(e);const t=this.$("hs");pi(this,"scrolled",{range:[this.firstVisibleIndex,this.lastVisibleIndex],scrollWidth:t.scrollWidth,scrollLeft:t.scrollLeft})}refreshVisibilityWindow(e=!1){const t=this.$("hs"),i=Math.floor(t.scrollWidth/this.cellwidth),s=Math.abs(t.scrollLeft),o=Math.max(0,Math.min(i-1,Math.floor((s+5)/t.scrollWidth*i))),n=Math.max(0,Math.min(i-1,Math.floor((s+t.getBoundingClientRect().width-5)/t.scrollWidth*i)));isNaN(o)||isNaN(n)||(e||o!==this.firstVisibleIndex||n!==this.lastVisibleIndex)&&(this.firstVisibleIndex=o,this.lastVisibleIndex=n,pi(this,"range-change",{range:[o,n]}))}nextScrollPage(){this.animateToValue(this.lastVisibleIndex)}prevScrollPage(){const e=this.firstVisibleIndex-(this.lastVisibleIndex-this.firstVisibleIndex);this.animateToValue(Math.max(0,e))}animateToValue(e){if(!this.animating){this.animating=!0,this.animationStart=0;const t=this.$("hs");this.scrollAnimationData[0]=t.scrollLeft,this.scrollAnimationData[1]=e*this.cellwidth*("rtl"===this.dir?-1:1)-t.scrollLeft,requestAnimationFrame(this.nextScrollAnimationFrame.bind(this))}}nextScrollAnimationFrame(e){this.animationStart||(this.animationStart=e);const t=Math.max(0,Math.min(1,(e-this.animationStart)/500));this.$("hs").scrollLeft=this.scrollAnimationData[0]+this.scrollAnimationData[1]*t,t<1?requestAnimationFrame(this.nextScrollAnimationFrame.bind(this)):this.animating=!1}$(e){return this.shadowRoot.querySelector(`#${e}`)}};_i([oi({type:Number}),Ci("design:type",Number)],$i.prototype,"cellheight",void 0),_i([oi({type:Number}),Ci("design:type",Number)],$i.prototype,"cellwidth",void 0),_i([oi({type:Boolean}),Ci("design:type",Boolean)],$i.prototype,"arrows",void 0),_i([oi({type:Number}),Ci("design:type",Object)],$i.prototype,"endpadding",void 0),$i=_i([ii("horiz-slider-view")],$i);const Pi=new class{constructor(){this.listeners=new Map,this.counter=0}subscribe(e,t){return this.listeners.has(e)||this.listeners.set(e,new Map),this.listeners.get(e).set(++this.counter,t),this.counter}unsubscrive(e,t){return!!this.listeners.has(e)&&this.listeners.get(e).delete(t)}async dispatch(e,t){const i=this.listeners.get(e);i&&i.forEach((async i=>{try{await i(t,e)}catch(e){console.error(e)}}))}},Ii=new Map;function Ti(e,t){try{customElements.get(e)||customElements.define(e,t)}catch(t){console.log("Failed to register element: "+e,t)}}function Oi(e){return t=>{window.customElements?Ti(e,t):Ii.set(e,t)}}Pi.subscribe("webcomponents-ready",(()=>{for(const[e,t]of Ii)Ti(e,t);Ii.clear()}));const Ri=1,Ei=2,ji=e=>(...t)=>({_$litDirective$:e,values:t});class Li{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,i){this._$Ct=e,this._$AM=t,this._$Ci=i}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}}class zi extends Li{constructor(e){if(super(e),this.et=Mt,e.type!==Ei)throw Error(this.constructor.directiveName+"() can only be used in child bindings")}render(e){if(e===Mt||null==e)return this.ft=void 0,this.et=e;if(e===zt)return e;if("string"!=typeof e)throw Error(this.constructor.directiveName+"() called with a non-string value");if(e===this.et)return this.ft;this.et=e;const t=[e];return t.raw=t,this.ft={_$litType$:this.constructor.resultType,strings:t,values:[]}}}zi.directiveName="unsafeHTML",zi.resultType=1;const Mi=ji(zi);const Ai=new class{constructor(){this.map=new Map,this.maps=new Map}get(e,t){const i=t?this.maps.get(t):this.map;return i&&i.has(e)?i.get(e):""}define(e,t){let i=this.map;t&&(this.maps.has(t)||this.maps.set(t,new Map),i=this.maps.get(t));for(const t in e)i.set(t,e[t])}};var Di=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Hi=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Fi=class extends ei{static get styles(){return it`
      :host {
        display: -ms-inline-flexbox;
        display: -webkit-inline-flex;
        display: inline-flex;
        -ms-flex-align: center;
        -webkit-align-items: center;
        align-items: center;
        -ms-flex-pack: center;
        -webkit-justify-content: center;
        justify-content: center;
        position: relative;
        vertical-align: middle;
        fill: currentColor;
        stroke: none;
        width: 24px;
        height: 24px;
        box-sizing: initial;
      }
      svg {
        pointer-events: none;
        display: block;
        width: 100%;
        height: 100%;
      }
    `}render(){const e=this.icon||"",t=Ai.get(e,this.iconkey);return this.customSvg?Lt`${Mi(this.customSvg)}`:Lt`
    <svg viewBox="0 0 24 24" preserveAspectRatio="xMidYMid meet" focusable="false">
      <g>
        <path d="${t}"></path>
      </g>
    </svg>
    `}};Di([oi({type:String}),Hi("design:type",String)],Fi.prototype,"icon",void 0),Di([oi({type:String}),Hi("design:type",String)],Fi.prototype,"iconkey",void 0),Di([oi(),Hi("design:type",String)],Fi.prototype,"customSvg",void 0),Fi=Di([Oi("soso-icon")],Fi);var Bi=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Ui=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Ni=class extends ei{constructor(){super(...arguments),this.disabled=!1}static get styles(){return it`
    :host {
      display: inline-block;
      line-height: 1;
    }
    button {
      background: none;
      cursor: pointer;
      outline: none;
      border: none;
      border-radius: 50%;
      overflow: hidden;
      padding: var(--soso-icon-button-padding, 10px);
      color: inherit;
      user-select: none;
      position: relative;
      display: block;
    }
    button::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: currentColor;
      opacity: var(--soso-icon-button-before-opacity, 0);
      pointer-events: none;
    }
    button:focus::before {
      opacity: var(--soso-icon-button-before-opacity, 0.1);
    }
    button soso-icon {
      transition: transform 0.3s ease;
      width: var(--soso-button-icon-size, 24px);
      height: var(--soso-button-icon-size, 24px);
    }
    button:active soso-icon {
      transform: scale(1.15);
    }
    button:disabled {
      opacity: 0.8;
      color: var(--soso-disabled-color, #808080);
      cursor: initial;
      pointer-events: none;
    }

    @media (hover: hover) {
      button:hover::before {
        opacity: var(--soso-icon-button-before-opacity, 0.05);
      }
      button:focus::before {
        opacity: var(--soso-icon-button-before-opacity, 0.1);
      }
    }
    `}render(){return Lt`
    <button aria-label="${this.label||this.icon}" ?disabled="${this.disabled}">
      <soso-icon .icon="${this.icon}" .iconkey="${this.iconkey}" .customSvg="${this.customSvg}"></soso-icon>
    </button>`}updated(e){e.has("disabled")&&(this.style.pointerEvents=this.disabled?"none":"")}focus(){if(this.shadowRoot){const e=this.shadowRoot.querySelector("button");e&&e.focus()}}};Bi([oi({type:String}),Ui("design:type",String)],Ni.prototype,"icon",void 0),Bi([oi({type:String}),Ui("design:type",String)],Ni.prototype,"iconkey",void 0),Bi([oi({type:Boolean}),Ui("design:type",Object)],Ni.prototype,"disabled",void 0),Bi([oi(),Ui("design:type",String)],Ni.prototype,"customSvg",void 0),Bi([oi(),Ui("design:type",String)],Ni.prototype,"label",void 0),Ni=Bi([Oi("soso-icon-button")],Ni);var Vi=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},qi=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const Wi=new Map;let Gi=class extends ei{constructor(){super(...arguments),this.pinningEnabled=!0,this.showStoryIndicators=!1,this.containment="cover",this.dir="ltr",this.pendingImage=!1,this.pendingImageTimer=0,this.fetchedImages=new Map}static get styles(){return hi}connectedCallback(){this.dir="rtl"===document.documentElement.dir?"rtl":"ltr",super.connectedCallback()}render(){if(this.pendingImage=!1,this.pendingImageTimer&&(window.clearTimeout(this.pendingImageTimer),this.pendingImageTimer=0),!this.site||!this.page)return Lt``;let e=Wi.get(this.page.id);e||(e=new URL(this.page.viewerUrl||this.page.url,this.site.homePageUrl).toString(),Wi.set(this.page.id,e));const t=this.pinningEnabled&&(this.page.pinned||!1),i=this.showStoryIndicators&&"web-story"===this.page.type;let s="";if(this.fetchedImages.get(this.page.id))s=`background-image: url("${this.fetchedImages.get(this.page.id)}");`;else if(0===this.fetchedImages.size){const e=this.thumbnailUrl();this.fetchedImages.set(this.page.id,e),s=`background-image: url("${e}");`}else this.page.image&&(this.pendingImage=!0);return Lt`
    <style>
      :host {
        display: block;
        height: 100%;
        position: relative;
        box-sizing: border-box;
        clear: both;
        text-align: var(--slick-filmstrip-text-align, left);
      }
      a, a:visited, a:hover {
        color: inherit;
        text-decoration: none;
        display: block;
        height: 100%;
      }
      #card {
        height: 100%;
        position: relative;
        background: var(--slick-filmstrip-card-background);
        border-radius: var(--film-strip-card-radius);
        overflow: hidden;
      }
      #card::before {
        content: '';
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        background: var(--slick-filmstrip-before-color, var(--slick-discovery-highlight-color, #2196f3));
        opacity: 0;
        transition: opacity 0.28s ease;
      }
      #imageCell {
        border-radius: var(--film-strip-card-image-radius, 5px);
        height: 100%;
        width: var(--slick-filmstrip-image-width, var(--slick-filmstrip-image-width-internal, 64px));
        background-color: transparent;
        background-size: cover;
        background-origin: border-box;
        background-position: 50% 50%;
        background-repeat: no-repeat;
        box-sizing: border-box;
        position: relative;
        overflow: hidden;
      }
      #imageCell.contain {
        background-size: contain;
      }
      #imageCell soso-icon {
        width: 20px;
        height: 20px;
        background: rgba(0,0,0,0.3);
        color: white;
        padding: 4px;
        border-radius: 0 0 5px 0;
        pointer-events: none;
        position: relative;
      }
      #textCell {
        padding: var(--slick-filmstrip-text-padding, 0 5px 0 8px);
        font-size: var(--slick-filmstrip-font-size, 13px);
        box-sizing: border-box;
        line-height: var(--slick-filmstrip-line-height, 1.3);
        letter-spacing: var(--slick-filmstrip-letter-spacing, 0);
        font-weight: var(--slick-filmstrip-font-weight, 400);
      }
      #pin {
        position: absolute;
        width: 16px;
        height: 16px;
        top: -2px;
        right: -5px;
        color: var(--slick-discovery-highlight-color, #2196f3);
        display: none;
      }
      #textCell #pageTitle {
        overflow: hidden;
        width: 100%;
        box-sizing: border-box;
        word-break: break-word;
        max-height: calc((var(--slick-filmstrip-text-lines,  3) * 1.3em) - 0.15em);
        -webkit-line-clamp: var(--slick-filmstrip-text-lines,  3);
        -webkit-box-orient: vertical;
        display: -webkit-box;
        -webkit-hyphens: var(--slick-filmstrip-hyphens, auto);
        -moz-hyphens: var(--slick-filmstrip-hyphens, auto);
        hyphens: var(--slick-filmstrip-hyphens, auto);
      }

      #card.pinned::before {
        opacity: 0.1;
      }
      #card.pinned #pin {
        display: block;
      }

      @media (hover: hover) {
        #imageCell {
          transition: transform 0.3s ease;
        }
        #card:hover #imageCell {
          transform: scale(1.1);
        }
        #card:hover::before {
          opacity: 0.05;
        }
        #card:hover.pinned::before {
          opacity: 0.1;
        }
      }
    </style>
    <style rtl>
      :host([dir="rtl"]) {
        text-align: var(--slick-filmstrip-text-align);
      }
      :host([dir="rtl"]) #textCell {
        padding: var(--slick-filmstrip-text-padding, 0 8px 0 5px);
      }
      :host([dir="rtl"]) #pin {
        top: -2px;
        left: -5px;
        right: initial;
        transform: scaleX(-1);
      }
    </style>
    <a href="${e}" @click="${this.onNav}">
      <div id="card" class="horizontal layout center ${t?"pinned":""}">
        <div id="imageCell" class="${this.containment}" style="${s}" role="img" aria-label="Image for ${this.page.titleText||""}">
          ${i?Lt`<soso-icon icon="carousel"></soso-icon>`:""}
        </div>
        <div id="textCell" class="flex">
          <soso-icon id="pin" icon="pin" title="Pinned"></soso-icon>
          <div id="pageTitle">${this.page.titleText||this.page.titleHtml}</div>
        </div>
      </div>
    </a>
    `}updated(){this.pendingImage&&(this.pendingImageTimer=window.setTimeout((()=>{if(this.page&&this.pendingImage&&this.page.image){let e=this.fetchedImages.get(this.page.id);e||(e=this.thumbnailUrl(),this.fetchedImages.set(this.page.id,e)),this.imageCell.style.backgroundImage=`url("${e}")`}this.pendingImage=!1}),100))}thumbnailUrl(){var e,t;if(this.page){if("contain"===this.containment)return Ze.thumbnailUrl(this.page,void 0,64)||"";{let i=(null===(e=this.thumbnailSize)||void 0===e?void 0:e.height)||64,s=(null===(t=this.thumbnailSize)||void 0===t?void 0:t.width)||64;return i<96&&(i=64),s<96&&(s=64),Ze.thumbnailUrl(this.page,s,i)||""}}return""}onNav(e){e.stopPropagation(),pi(this,"nav",this.page)}};Vi([oi({type:Object}),qi("design:type",Object)],Gi.prototype,"site",void 0),Vi([oi({type:Object}),qi("design:type",Object)],Gi.prototype,"page",void 0),Vi([oi({type:Boolean}),qi("design:type",Object)],Gi.prototype,"pinningEnabled",void 0),Vi([oi({type:Boolean}),qi("design:type",Object)],Gi.prototype,"showStoryIndicators",void 0),Vi([oi(),qi("design:type",String)],Gi.prototype,"containment",void 0),Vi([oi({reflect:!0}),qi("design:type",String)],Gi.prototype,"dir",void 0),Vi([ai("#imageCell"),qi("design:type",HTMLDivElement)],Gi.prototype,"imageCell",void 0),Gi=Vi([ii("film-strip-item")],Gi);var Ki=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Yi=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const Zi=new Map;let Qi=class extends ei{constructor(){super(...arguments),this.pinningEnabled=!0,this.showStoryIndicators=!1,this.thumbnailSize={width:96,height:64},this.containment="cover",this.pendingImage=!1,this.pendingImageTimer=0,this.fetchedImages=new Map}static get styles(){return hi}render(){if(this.pendingImage=!1,this.pendingImageTimer&&(window.clearTimeout(this.pendingImageTimer),this.pendingImageTimer=0),!this.site||!this.page)return Lt``;let e=Zi.get(this.page.id);e||(e=new URL(this.page.viewerUrl||this.page.url,this.site.homePageUrl).toString(),Zi.set(this.page.id,e));const t=this.pinningEnabled&&(this.page.pinned||!1),i=this.showStoryIndicators&&"web-story"===this.page.type;let s="";if(this.fetchedImages.get(this.page.id))s=`background-image: url("${this.fetchedImages.get(this.page.id)}");`;else if(0===this.fetchedImages.size){const e=this.thumbnailUrl();this.fetchedImages.set(this.page.id,e),s=`background-image: url("${e}");`}else this.page.image&&(this.pendingImage=!0);return Lt`
    <style>
      :host {
        display: block;
        height: 100%;
        position: relative;
        box-sizing: border-box;
        clear: both;
        text-align: left;
      }
      a, a:visited, a:hover {
        color: inherit;
        text-decoration: none;
        display: block;
        height: 100%;
      }
      #card {
        height: 100%;
        position: relative;
        background: var(--slick-filmstrip-card-background);
        padding-top: 4%;
        box-sizing: border-box;
      }
      #imageCell {
        border-radius: var(--film-strip-card-image-radius, 5px);
        height: 92%;
        width: var(--slick-filmstrip-image-width, 64px);
        background-color: transparent;
        background-size: cover;
        background-origin: border-box;
        background-position: 50% 50%;
        box-sizing: border-box;
        position: relative;
        overflow: hidden;
      }
      #imageCell soso-icon {
        width: 20px;
        height: 20px;
        background: rgba(0,0,0,0.3);
        color: white;
        padding: 4px;
        border-radius: 0 0 5px 0;
        pointer-events: none;
        position: relative;
      }
      #pin {
        position: absolute;
        width: 16px;
        height: 16px;
        top: 4%;
        right: 3px;
        padding: 4px;
        margin-top: 5px;
        background: var(--slick-strip-icon-bg, rgba(255,255,255,0.8));
        color: var(--slick-discovery-highlight-color, #2196f3);
        display: none;
        border-radius: 50%;
      }
      #card.pinned #pin {
        display: block;
      }

      @media (hover: hover) {
        #imageCell {
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        #card:hover #imageCell {
          box-shadow: 0 3px 3px -2px rgba(0,0,0,.2), 0 3px 4px 0 rgba(0,0,0,.14), 0 1px 8px 0 rgba(0,0,0,.12);
        }
      }
    </style>
    <a href="${e}" @click="${this.onNav}">
      <div id="card" class="horizontal layout ${t?"pinned":""}">
        <div id="imageCell" class="flex" style="${s}" role="img" aria-label="Image for ${this.page.titleText||""}">
          ${i?Lt`<soso-icon icon="carousel"></soso-icon>`:""}
        </div>
        <soso-icon id="pin" icon="pin" title="Pinned"></soso-icon>
      </div>
    </a>
    `}updated(){this.pendingImage&&(this.pendingImageTimer=window.setTimeout((()=>{if(this.page&&this.pendingImage&&this.page.image){let e=this.fetchedImages.get(this.page.id);e||(e=this.thumbnailUrl(),this.fetchedImages.set(this.page.id,e)),this.imageCell.style.backgroundImage=`url("${e}")`}this.pendingImage=!1}),100))}thumbnailUrl(){return this.page&&Ze.thumbnailUrl(this.page,this.thumbnailSize.width,this.thumbnailSize.height)||""}onNav(e){e.stopPropagation(),pi(this,"nav",this.page)}};Ki([oi({type:Object}),Yi("design:type",Object)],Qi.prototype,"site",void 0),Ki([oi({type:Object}),Yi("design:type",Object)],Qi.prototype,"page",void 0),Ki([oi({type:Boolean}),Yi("design:type",Object)],Qi.prototype,"pinningEnabled",void 0),Ki([oi({type:Boolean}),Yi("design:type",Object)],Qi.prototype,"showStoryIndicators",void 0),Ki([oi({type:Object}),Yi("design:type",Object)],Qi.prototype,"thumbnailSize",void 0),Ki([oi(),Yi("design:type",String)],Qi.prototype,"containment",void 0),Ki([ai("#imageCell"),Yi("design:type",HTMLDivElement)],Qi.prototype,"imageCell",void 0),Qi=Ki([ii("thumbnail-strip-item")],Qi);var Xi=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Ji=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const es=new Map;let ts=class extends ei{constructor(){super(...arguments),this.pinningEnabled=!0,this.showStoryIndicators=!1,this.containment="cover"}static get styles(){return hi}render(){if(!this.site||!this.page)return Lt``;let e=es.get(this.page.id);e||(e=new URL(this.page.viewerUrl||this.page.url,this.site.homePageUrl).toString(),es.set(this.page.id,e));const t=this.page.titleText||this.page.titleHtml||this.page.descriptionHtml||"",i=this.pinningEnabled&&(this.page.pinned||!1);let s=this.page.sectionHtml;return!s&&i&&(s="Pinned"),Lt`
    <style>
      :host {
        display: block;
        height: 100%;
        position: relative;
        box-sizing: border-box;
        clear: both;
        text-align: left;
      }
      a, a:visited, a:hover {
        color: inherit;
        text-decoration: none;
        display: block;
        height: 100%;
        padding-top: 2%;
        box-sizing: border-box;
      }
      #card {
        height: 96%;
        position: relative;
        background: var(--slick-filmstrip-card-background);
        box-shadow: var(--slick-filmstrip-card-shadow, none);
      }
      #textCell {
        padding: var(--slick-filmstrip-text-padding, 0 5px 0 8px);
        font-size: var(--slick-filmstrip-font-size, 13px);
        box-sizing: border-box;
        line-height: var(--slick-filmstrip-line-height, 1.3);
        letter-spacing: var(--slick-filmstrip-letter-spacing, 0);
        font-weight: var(--slick-filmstrip-font-weight, 400);
      }
      #pin {
        width: 16px;
        height: 16px;
        color: var(--slick-discovery-highlight-color, #2196f3);
        margin-right: 6px;
        display: none;
      }
      #textCell #pageTitle {
        overflow: hidden;
        width: 100%;
        box-sizing: border-box;
        word-break: break-word;
        max-height: calc((var(--slick-filmstrip-text-lines,  2) * 1.3em) - 0.15em);
        -webkit-line-clamp: var(--slick-filmstrip-text-lines,  2);
        -webkit-box-orient: vertical;
        display: -webkit-box;
        -webkit-hyphens: var(--slick-filmstrip-hyphens, auto);
        -moz-hyphens: var(--slick-filmstrip-hyphens, auto);
        hyphens: var(--slick-filmstrip-hyphens, auto);
      }
      #card.pinned #pin {
        display: block;
      }
      .sectionTitle {
        font-size: var(--slick-filmstrip-section-size, 10px);
        text-transform: uppercase;
        letter-spacing: 1px;
        padding: var(--slick-filmstrip-section-padding, 4px 0 6px);
        font-weight: var(--slick-filmstrip-section-font-weight, bold);
        font-family: var(--slick-filmstrip-section-font, sans-serif);
        word-break: break-word;
        -webkit-hyphens: var(--slick-filmstrip-hyphens, auto);
        -moz-hyphens: var(--slick-filmstrip-hyphens, auto);
        hyphens: var(--slick-filmstrip-hyphens, auto);
      }
      
      @media (hover: hover) {
        a:hover {
          color: var(--slick-discovery-highlight-color, #2196f3);
        }
      }
    </style>
    <a href="${e}" @click="${this.onNav}">
      <div id="card" class="horizontal layout ${i?"pinned":""}">
        <div id="textCell" class="flex">
          <div class="horizontal layout">
            <soso-icon id="pin" icon="pin" title="Pinned"></soso-icon>
            ${s?Lt`
              <div class="sectionTitle">${s}</div>
            `:""}
          </div>
          <div id="pageTitle">${t}</div>
        </div>
      </div>
    </a>
    `}onNav(e){e.stopPropagation(),pi(this,"nav",this.page)}};Xi([oi({type:Object}),Ji("design:type",Object)],ts.prototype,"site",void 0),Xi([oi({type:Object}),Ji("design:type",Object)],ts.prototype,"page",void 0),Xi([oi({type:Boolean}),Ji("design:type",Object)],ts.prototype,"pinningEnabled",void 0),Xi([oi({type:Boolean}),Ji("design:type",Object)],ts.prototype,"showStoryIndicators",void 0),Xi([oi(),Ji("design:type",String)],ts.prototype,"containment",void 0),ts=Xi([ii("text-strip-item")],ts);var is=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},ss=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const os=new Map;let ns=class extends ei{constructor(){super(...arguments),this.pinningEnabled=!0,this.showStoryIndicators=!1,this.containment="cover",this.templateRendered=!1}static get styles(){return hi}render(){if(!(this.site&&this.page&&this.template))return Lt``;let e=os.get(this.page.id);return e||(e=new URL(this.page.viewerUrl||this.page.url,this.site.homePageUrl).toString(),os.set(this.page.id,e)),Lt`
    <style>
      :host {
        display: block;
        height: 100%;
        position: relative;
        box-sizing: border-box;
        clear: both;
        text-align: left;
      }
      a, a:visited, a:hover {
        color: inherit;
        text-decoration: none;
        display: block;
        height: 100%;
      }
    </style>
    <a id="mainAnchor" href="${e}" @click="${this.onNav}"></a>
    `}onNav(e){e.stopPropagation(),pi(this,"nav",this.page)}updated(){if(this.site&&this.page&&this.template&&this.mainAnchor){if(!this.templateRendered){const e=this.template.content.cloneNode(!0);this.mainAnchor.appendChild(e)}this.templateRendered=!0;const e=this.pinningEnabled&&(this.page.pinned||!1),t=this.showStoryIndicators&&"web-story"===this.page.type,i=Ze.thumbnailUrl(this.page)||"",s=this.page.titleText||this.page.titleHtml||"",o=this.page.descriptionHtml||"",n=this.mainAnchor.children;for(let i=0;i<n.length;i++){const s=n[i];e?s.classList.add("pinned"):s.classList.remove("pinned"),t?s.classList.add("webstory"):s.classList.remove("webstory")}this.mainAnchor.querySelectorAll("[data-title]").forEach((e=>e.textContent=s));this.mainAnchor.querySelectorAll("[data-description]").forEach((e=>e.textContent=o));this.mainAnchor.querySelectorAll("[data-image]").forEach((e=>e.setAttribute("src",i)));this.mainAnchor.querySelectorAll("[data-bg-image]").forEach((e=>e.style.backgroundImage=`url("${i}")`))}}};is([oi({type:Object}),ss("design:type",Object)],ns.prototype,"site",void 0),is([oi({type:Object}),ss("design:type",Object)],ns.prototype,"page",void 0),is([oi({type:Boolean}),ss("design:type",Object)],ns.prototype,"pinningEnabled",void 0),is([oi({type:Boolean}),ss("design:type",Object)],ns.prototype,"showStoryIndicators",void 0),is([oi({type:Object}),ss("design:type",HTMLTemplateElement)],ns.prototype,"template",void 0),is([oi(),ss("design:type",String)],ns.prototype,"containment",void 0),is([ai("#mainAnchor"),ss("design:type",HTMLAnchorElement)],ns.prototype,"mainAnchor",void 0),ns=is([ii("custom-strip-item")],ns);var rs=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},as=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let ls=class extends ei{constructor(){super(...arguments),this.mode="og-card",this.searchEnabled=!1,this.thumbnailSize={width:96,height:64},this.containment="cover",this.dir="ltr",this.leftScroll=!1,this.rightScroll=!0,this.forceCompact=!1,this.topLevelWidget=!1,this.widget="filmstrip",this.cellheight=-1,this.cellwidth=-1,this.cellgap=-1,this.pages=[],this.pinningEnabled=!0,this.nodeMap=new WeakMap,this.showStoryIndicators=!1}static get styles(){return hi}connectedCallback(){this.dir="rtl"===document.documentElement.dir?"rtl":"ltr",super.connectedCallback()}render(){return this.resolveSizes(),Lt`
    <style>
      :host {
        display: block;
      }
      #container {
        position: relative;
        box-sizing: border-box;
        display: block;
      }
      #overlay {
        position: absolute;
        top: 0;
        right: 0;
        left: 0;
        bottom: 0;
        pointer-events: none;
        padding: 0 12px;
      }
      soso-icon-button {
        background: var(--slick-strip-icon-bg, rgba(255,255,255,0.8));
        border-radius: 50%;
        --soso-icon-button-padding: 4px;
        cursor: pointer;
        transition: opacity 0.3s ease;
        opacity: 0;
        color: var(--slick-icon-color, var(--slick-discovery-highlight-color, #000));
        transition: transform 0.28s ease;
      }
      soso-icon-button.showing {
        opacity: 1;
        pointer-events: auto;
      }

      @media (max-width: 600px) {
        #overlay {
          padding: 0 4px;
        }
      }

      @media(hover: hover) {
        #overlay {
          opacity: 0;
          transition: opacity 0.18s ease;
        }
        #container:hover #overlay {
          opacity: 1;
        }
        soso-icon-button:hover {
          background: var(--slick-strip-icon-bg, rgba(255,255,255,1));
          transform: scale(1.1);
        }
      }
    </style>
    <div id="container">
      <horiz-slider-view 
        id="scroller"
        .cellheight="${this.cellheight}"
        .cellwidth="${this.cellwidth+this.cellgap}"
        @scrolled="${this.onStripScroll}"
        @nav="${this.onNav}">
      </horiz-slider-view>
      <div id="overlay" class="horizontal layout center">
        <soso-icon-button label="Scroll left" .icon="${"rtl"===this.dir?"chevron-right":"chevron-left"}" class="${this.leftScroll?"showing":""}" @click="${this.prevPage}"></soso-icon-button>
        <span class="flex"></span>
        <soso-icon-button label="Scroll right" .icon="${"rtl"===this.dir?"chevron-left":"chevron-right"}" class="${this.rightScroll?"showing":""}" @click="${this.nextPage}"></soso-icon-button>
        ${this.searchEnabled?Lt`
          <soso-icon-button style="margin-left: 6px;" label="Search" icon="search" class="showing" @click="${this.onSearch}"></soso-icon-button>
        `:""}
      </div>
    </div>

    `}getSizeProperty(e){const t=(window.getComputedStyle(this).getPropertyValue(e)||"").trim();if(t){const e=t.match(/\d+/g);if(e&&e[0]){const t=+e[0];if(!Number.isNaN(t))return t}}}resolveSizes(){const e=this.forceCompact||window.innerWidth<800;switch(this.cellgap<=0&&(this.cellgap=this.getSizeProperty("--slick-filmstrip-cell-gap")||(e?5:8)),this.mode){case"og-card":case"custom":this.cellheight<=0&&(this.cellheight=this.getSizeProperty("--slick-filmstrip-cell-height")||(e?60:72)),this.cellwidth<=0&&(this.cellwidth=this.getSizeProperty("--slick-filmstrip-cell-width")||(e?155:195)),e?this.style.setProperty("--slick-filmstrip-image-width-internal","54.53px"):this.style.removeProperty("--slick-filmstrip-image-width-internal");break;case"thumbnails":this.cellheight<=0&&(this.cellheight=this.getSizeProperty("--slick-filmstrip-cell-height")||this.thumbnailSize.height),this.cellwidth<=0&&(this.cellwidth=this.getSizeProperty("--slick-filmstrip-cell-width")||this.thumbnailSize.width);break;case"text":this.cellheight<=0&&(this.cellheight=this.getSizeProperty("--slick-filmstrip-cell-height")||(e?60:72)),this.cellwidth<=0&&(this.cellwidth=this.getSizeProperty("--slick-filmstrip-cell-width")||(e?155:195)),e&&this.style.setProperty("--slick-filmstrip-section-padding","2px 0")}}firstUpdated(){Ze.currentSession?this.refresh():e.subscribe("session-established",(()=>{this.site||this.refresh()}))}async refresh(){var e;this.pinningEnabled=Ze.shouldPinFilmstripOnMobile()||window.innerWidth>600,this.site=(await Ze.getSiteInfo()).site,this.pages=await Ze.getStripPages(this.pinningEnabled),this.showStoryIndicators=(null===(e=Ze.currentSession)||void 0===e?void 0:e.settings.showStoryIndicators)||!1,await this.updateComplete,this.scroller&&(this.scroller.delegate=this),this.attachIntersectionObserver()}attachIntersectionObserver(){if(this.topLevelWidget&&!this.intersectionObserver)if("IntersectionObserver"in window){const e=e=>{var t;if(this.topLevelWidget){const i=e[0];i&&i.isIntersecting&&i.intersectionRatio>.5&&(Ze.widgetAction(this.widget,"impression",0),null===(t=this.intersectionObserver)||void 0===t||t.unobserve(this))}},t={threshold:[0,1]};this.intersectionObserver=new IntersectionObserver(e,t),this.intersectionObserver.observe(this)}else this.intersectionObserver={},Ze.widgetAction(this.widget,"impression",0)}onStripScroll(e){this.pendingScroll||setTimeout((()=>{if(this.pendingScroll){const e=Math.abs(this.pendingScroll.scrollLeft);this.leftScroll=e>0,this.rightScroll=this.pendingScroll.range[1]<this.pages.length-1,this.pendingScroll=void 0}}),300),this.pendingScroll=e.detail}nextPage(){this.scroller.nextScrollPage()}prevPage(){this.scroller.prevScrollPage()}onSearch(){Ze.widgetAction(this.widget,"open-search",0),document.dispatchEvent(ui("slick-show-search"))}onNav(e){const t=e.detail;Ze.widgetAction(this.widget,"nav",0,t.viewerUrl||t.url),"filmstrip-toolbar"===this.widget||"sticky-toolbar"===this.widget?Ze.reportGAEvent("filmstrip-toolbar-click","Slickstream filmstrip recommendation clicked"):Ze.reportGAEvent("filmstrip-click","Slickstream filmstrip toolbar recommendation clicked")}get length(){return this.pages.length}createElement(){const e=document.createElement("div");e.style.marginLeft=`${this.cellgap}px`,e.style.width=`${this.cellwidth}px`,e.style.height=`${this.cellheight}px`;let t=null;switch(this.mode){case"og-card":t=document.createElement("film-strip-item");break;case"thumbnails":t=document.createElement("thumbnail-strip-item"),t.thumbnailSize=this.thumbnailSize;break;case"text":t=document.createElement("text-strip-item");break;case"custom":if(t=document.createElement("custom-strip-item"),this.parentElement){const e=this.parentElement.querySelector("template");e&&(t.template=e)}}if(t){const i=t;if(!i.thumbnailSize){const e=this.getSizeProperty("--slick-filmstrip-image-width")||64;i.thumbnailSize={height:this.cellheight,width:e}}this.nodeMap.set(e,t),e.appendChild(t)}return e}updateElement(e,t){const i=this.nodeMap.get(e);if(i){const e=this.pages[t];i.site=this.site,i.page=e,i.containment=this.containment,i.pinningEnabled=this.pinningEnabled,i.showStoryIndicators=this.showStoryIndicators}}};rs([oi(),as("design:type",String)],ls.prototype,"mode",void 0),rs([oi({type:Boolean}),as("design:type",Object)],ls.prototype,"searchEnabled",void 0),rs([oi({type:Object}),as("design:type",Object)],ls.prototype,"thumbnailSize",void 0),rs([oi(),as("design:type",String)],ls.prototype,"containment",void 0),rs([oi({reflect:!0}),as("design:type",String)],ls.prototype,"dir",void 0),rs([ni(),as("design:type",Object)],ls.prototype,"leftScroll",void 0),rs([ni(),as("design:type",Object)],ls.prototype,"rightScroll",void 0),rs([ai("#scroller"),as("design:type",$i)],ls.prototype,"scroller",void 0),ls=rs([ii("slick-film-strip")],ls);var cs=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},hs=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const ds="filmstrip-toolbar",ps={width:96,height:64};let us=class extends ei{constructor(){super(...arguments),this.showing=!1,this.attached=!1,this.pageStripShowing=!1,this.linkedPanelShowing=!0,this.prevScrollValue=0,this.isScrollingUp=!1,this.impressionFired=!1,this.showOnDiscoveryClose=!1,this.scrollListener=this.handleScroll.bind(this),this.animatingScroll=!1,this.linkedPanelPollTimer=0}render(){return this.config?(this.showing?this.removeAttribute("tabindex"):this.setAttribute("tabindex","-1"),Lt`
    <style>
      #bar {
        position: fixed;
        top: 0;
        right: 0;
        left: 0;
        z-index: var(--slick-toolbar-zindex, 100);
        padding: var(--slick-toolbar-padding);
        background: var(--slick-toolbar-background, white);
        box-shadow: var(--slick-toolbar-shadow, 0px 5px 6px -3px rgba(0, 0, 0, 0.4));
        transform: var(--slick-film-strip-toolbar-initial-transform,  translate3d(0,-125px,0));
        transition: transform 0.5s ease;
      }
      #bar.showing {
        transform: var(--slick-film-strip-toolbar-showing-transform,  none);
      }
      slick-film-strip {
        box-sizing: border-box;
      }
    </style>
    <div id="bar" class="${this.showing?"showing":""}">
      <slick-film-strip
        .widget="${ds}"
        .forceCompact="${!0}"
        .mode="${this.config.mode||"og-card"}"
        .containment="${this.config.imageContainment||"cover"}"
        .searchEnabled="${this.config.includeSearch}"
        .thumbnailSize="${this.config.thumbnailSize||ps}">
      </slick-film-strip>
    </div>
    `):Lt``}firstUpdated(){document.addEventListener("scroll",this.scrollListener,{passive:!0});const t=()=>{this.showOnDiscoveryClose=this.showing,this.showing&&(this.stopLinkedPanelTimer(),this.showing=!1)},i=()=>{this.showOnDiscoveryClose&&(this.showOnDiscoveryClose=!1,this.handleScroll())};e.subscribe("disocvery-open",t),e.subscribe("disocvery-close",i),e.subscribe("scrolling-page-end",(()=>this.animatingScroll=!1)),e.subscribe("scrolling-page-start",(()=>this.animatingScroll=!0)),document.addEventListener("story-fullscreen-open",t),document.addEventListener("story-fullscreen-close",i);const s=te((()=>{this.showing&&this.adjustPositionBasedOnLinkedSelector()}),250,!1,this);window.addEventListener("resize",s)}updated(e){if(e.has("showing")){const e=document.body||document.querySelector("body");e&&(this.showing?e.classList.add("slick-filmstrip-toolbar-showing"):e.classList.remove("slick-filmstrip-toolbar-showing"))}e.has("config")&&this.config&&this.attach()}attach(){this.attached||(this.initializeFilmstripSelector(),this.findLinkedPanel()),this.attached=!0}async initializeFilmstripSelector(){var e;const t=null===(e=this.config)||void 0===e?void 0:e.filmstripSelector;if(t){let e=null;try{e=await gi(t,5e3)}catch(t){e=null}if(e){new IntersectionObserver((e=>{const t=e[0];if(t)if(t.isIntersecting)this.pageStripShowing=!0,this.handleScroll();else{const e=t.boundingClientRect||t.target.getBoundingClientRect();this.pageStripShowing=e.top>0,this.handleScroll()}}),{threshold:0}).observe(e)}else this.pageStripShowing=!1}else this.pageStripShowing=!1}async findLinkedPanel(){var e;const t=null===(e=this.config)||void 0===e?void 0:e.linkedSelectors;if(this.linkedPanel=void 0,t&&t.length){let e=await Promise.all(t.map((e=>fi(e))));if(e=e.filter((e=>!!e)),0===e.length)return void setTimeout((()=>{this.findLinkedPanel()}),3e3);if(1===e.length)this.linkedPanel=e[0]||void 0;else{let t=Number.MAX_SAFE_INTEGER,i=null;for(const s of e)if(s){const e=s.getBoundingClientRect(),o=(e.top||e.y||0)+e.height;o<t&&(t=o,i=s)}this.linkedPanel=i||void 0}if(this.linkedPanel&&!this.linkedPanel.__slickIntersectionAttached){new IntersectionObserver((e=>{const t=e[0];t&&(t.isIntersecting?this.linkedPanelShowing=!0:(this.linkedPanelShowing=!1,this.showing&&this.adjustPositionBasedOnLinkedSelector()))}),{threshold:1}).observe(this.linkedPanel),this.linkedPanel.__slickIntersectionAttached=!0}this.handleScroll()}}get scrollValue(){return void 0!==window.pageYOffset?window.pageYOffset:document.documentElement&&document.documentElement.scrollTop||document.body.scrollTop}handleScroll(){if(!this.config||this.showOnDiscoveryClose)return;let e=!1;if(!this.animatingScroll){const t=30,i=this.scrollValue,s=i-(this.prevScrollValue||0);s<0&&this.isScrollingUp||s>0&&!this.isScrollingUp?this.prevScrollValue=i:Math.abs(s)>t&&(this.prevScrollValue=i,this.isScrollingUp=s<0),!this.pageStripShowing&&i>60&&("scroll-up"===this.config.direction?this.isScrollingUp&&(e=!0):e=!0);const o=window.innerWidth<=600;if(this.showing!==e){switch((o?this.config.linkedBehaviorWhenVisibleMobile:this.config.linkedBehaviorWhenVisible)||"stick-to"){case"hide":this.style.removeProperty("--slick-film-strip-toolbar-showing-transform"),this.linkedPanel&&(this.linkedPanel.style.visibility=e?"hidden":"visible");break;case"stick-to":e&&this.adjustPositionBasedOnLinkedSelector()}e&&this.fireImpression()}}this.showing=e,this.showing?this.startLinkedPanelTimer():this.stopLinkedPanelTimer()}fireImpression(){this.impressionFired||(Ze.widgetAction(ds,"impression",0),this.impressionFired=!0)}adjustPositionBasedOnLinkedSelector(){let e=0;if(this.linkedPanelShowing&&this.linkedPanel){if("hidden"!==(window.getComputedStyle(this.linkedPanel).visibility||"").toLowerCase()){e=this.linkedPanel.getBoundingClientRect().bottom}}e?this.style.setProperty("--slick-film-strip-toolbar-showing-transform",`translate3d(0,${e}px,0)`):this.style.removeProperty("--slick-film-strip-toolbar-showing-transform")}stopLinkedPanelTimer(){this.linkedPanelPollTimer&&(window.clearInterval(this.linkedPanelPollTimer),this.linkedPanelPollTimer=0)}startLinkedPanelTimer(){this.linkedPanelPollTimer||(this.linkedPanelPollTimer=window.setInterval((()=>{this.showing&&this.linkedPanelShowing&&this.linkedPanel?this.adjustPositionBasedOnLinkedSelector():this.stopLinkedPanelTimer()}),1e3))}};cs([oi({type:Object}),hs("design:type",Object)],us.prototype,"config",void 0),cs([ni(),hs("design:type",Object)],us.prototype,"showing",void 0),us=cs([ii("slick-sticky-toolbar")],us);const{I:gs}=Zt,fs=()=>document.createComment(""),vs=(e,t,i)=>{var s;const o=e._$AA.parentNode,n=void 0===t?e._$AB:t._$AA;if(void 0===i){const t=o.insertBefore(fs(),n),s=o.insertBefore(fs(),n);i=new gs(t,s,e,e.options)}else{const t=i._$AB.nextSibling,r=i._$AM,a=r!==e;if(a){let t;null===(s=i._$AQ)||void 0===s||s.call(i,e),i._$AM=e,void 0!==i._$AP&&(t=e._$AU)!==r._$AU&&i._$AP(t)}if(t!==n||a){let e=i._$AA;for(;e!==t;){const t=e.nextSibling;o.insertBefore(e,n),e=t}}}return i},ms=(e,t,i=e)=>(e._$AI(t,i),e),ys={},bs=e=>{var t;null===(t=e._$AP)||void 0===t||t.call(e,!1,!0);let i=e._$AA;const s=e._$AB.nextSibling;for(;i!==s;){const e=i.nextSibling;i.remove(),i=e}},ws=(e,t,i)=>{const s=new Map;for(let o=t;o<=i;o++)s.set(e[o],o);return s},xs=ji(class extends Li{constructor(e){if(super(e),e.type!==Ei)throw Error("repeat() can only be used in text expressions")}dt(e,t,i){let s;void 0===i?i=t:void 0!==t&&(s=t);const o=[],n=[];let r=0;for(const t of e)o[r]=s?s(t,r):r,n[r]=i(t,r),r++;return{values:n,keys:o}}render(e,t,i){return this.dt(e,t,i).values}update(e,[t,i,s]){var o;const n=(e=>e._$AH)(e),{values:r,keys:a}=this.dt(t,i,s);if(!Array.isArray(n))return this.ht=a,r;const l=null!==(o=this.ht)&&void 0!==o?o:this.ht=[],c=[];let h,d,p=0,u=n.length-1,g=0,f=r.length-1;for(;p<=u&&g<=f;)if(null===n[p])p++;else if(null===n[u])u--;else if(l[p]===a[g])c[g]=ms(n[p],r[g]),p++,g++;else if(l[u]===a[f])c[f]=ms(n[u],r[f]),u--,f--;else if(l[p]===a[f])c[f]=ms(n[p],r[f]),vs(e,c[f+1],n[p]),p++,f--;else if(l[u]===a[g])c[g]=ms(n[u],r[g]),vs(e,n[p],n[u]),u--,g++;else if(void 0===h&&(h=ws(a,g,f),d=ws(l,p,u)),h.has(l[p]))if(h.has(l[u])){const t=d.get(a[g]),i=void 0!==t?n[t]:null;if(null===i){const t=vs(e,n[p]);ms(t,r[g]),c[g]=t}else c[g]=ms(i,r[g]),vs(e,n[p],i),n[t]=null;g++}else bs(n[u]),u--;else bs(n[p]),p++;for(;g<=f;){const t=vs(e,c[f+1]);ms(t,r[g]),c[g++]=t}for(;p<=u;){const e=n[p++];null!==e&&bs(e)}return this.ht=a,((e,t=ys)=>{e._$AH=t})(e,c),zt}}),ks=it`
.layout.horizontal,
.layout.vertical {
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
}
.layout.horizontal {
  -ms-flex-direction: row;
  -webkit-flex-direction: row;
  flex-direction: row;
}
.layout.vertical {
  -ms-flex-direction: column;
  -webkit-flex-direction: column;
  flex-direction: column;
}
.layout.center {
  -ms-flex-align: center;
  -webkit-align-items: center;
  align-items: center;
}
.layout.wrap {
  -ms-flex-wrap: wrap;
  -webkit-flex-wrap: wrap;
  flex-wrap: wrap;
}
.flex {
  -ms-flex: 1 1 0.000000001px;
  -webkit-flex: 1;
  flex: 1;
  -webkit-flex-basis: 0.000000001px;
  flex-basis: 0.000000001px;
}
`;var Ss=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},_s=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Cs=class extends ei{constructor(){super(...arguments),this.open=!1}static get styles(){return[ks,it`
      #container {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        pointer-events: none;
        overflow: hidden;
        box-sizing: border-box;
        z-index: var(--soso-dialog-z-index, var(--slick-discovery-zindex, var(--slick-toolbar-zindex, 900002)));
      }
      #contentCell {
        padding: var(--soso-dialog-content-padding, 5px);
      }
      #contentPanel {
        opacity: 0;
        transform: scale(0.8);
        transition: opacity 0.3s ease, transform 0.5s ease;
      }
      #glass {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: var(--soso-dialog-glass-color, rgba(0,0,0,0.36));
        opacity: 0;
        transition: opacity 0.3s ease;
      }
      #main {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        overflow: hidden;
        overflow-y: auto;
        -webkit-overflow-scrolling: touch;
      }

      #container.showing {
        pointer-events: auto;
      }
      #container.showing #glass {
        opacity: 1;
      }
      #container.showing #contentPanel {
        opacity: 1;
        transform: scale(1);
      }
      `]}render(){return Lt`
    <div id="container" class="${this.open?"showing":""}">
      <div id="glass"></div>
      <div id="main" class="vertical layout">
        <div class="flex"></div>
        <div id="contentCell">
          <div id="contentPanel">
            <slot></slot>
          </div>
        </div>
        <div class="flex"></div>
      </div>
    </div>
    `}};Ss([oi(),_s("design:type",Object)],Cs.prototype,"open",void 0),Cs=Ss([Oi("soso-dialog-container")],Cs);const $s=new class{constructor(){this.originalOverflows=["",""]}show(e){e?(this.view&&this.view.parentElement&&(this.view.parentElement.removeChild(this.view),this.view=void 0),this.dlg||(this.dlg=document.createElement("soso-dialog-container"),document.body.appendChild(this.dlg)),this.dlg.appendChild(e),this.view=e,setTimeout((()=>{this.dlg.open=!0}),150),this.originalOverflows=[document.body.style.overflow||"",document.documentElement.style.overflow||""],document.body.style.overflow="hidden",document.documentElement.style.overflow="hidden"):this.hide()}hide(){this.dlg&&(this.dlg.open=!1,setTimeout((()=>{this.dlg&&!this.dlg.open&&(document.body.style.overflow=this.originalOverflows[0]||"",document.documentElement.style.overflow=this.originalOverflows[1]||"")}),500))}};var Ps=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Is=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};class Ts extends ei{constructor(){super(...arguments),this.keyListener=this.handleKeyDown.bind(this),this.showing=!1,this.dir="ltr"}static get styles(){return[hi,it`
      :host([dir="rtl"])  {
        --soso-dialog-title-align: right;
      }
      `]}connectedCallback(){this.dir="rtl"===document.documentElement.dir?"rtl":"ltr",super.connectedCallback()}async show(){this.showing=!0,await this.beforeShow(),this.showing&&($s.show(this),this.addKeyListeners(),await X(300),this.showing&&this.afterShow())}hide(){this.showing=!1,this.removeKeyListeners(),$s.hide()}async beforeShow(){}afterShow(){}addKeyListeners(){this.removeKeyListeners(),document.addEventListener("keydown",this.keyListener)}removeKeyListeners(){document.removeEventListener("keydown",this.keyListener)}handleKeyDown(e){switch(e.keyCode){case 13:this.onEnterKey();break;case 27:this.onEscKey()}}onEnterKey(){}onEscKey(){this.hide()}}function Os(e,t,i,s=!0,o=!0){if(t){const n={bubbles:"boolean"!=typeof s||s,composed:"boolean"!=typeof o||o};i&&(n.detail=i);const r=window.SlickCustomEvent||CustomEvent;e.dispatchEvent(new r(t,n))}}Ps([oi({reflect:!0}),Is("design:type",String)],Ts.prototype,"dir",void 0);var Rs=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Es=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const js="soso-checkbox";Ai.define({filled:"M19 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.11 0 2-.9 2-2V5c0-1.1-.89-2-2-2zm-9 14l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z",unfilled:"M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"},js);let Ls=class extends ei{constructor(){super(...arguments),this.checked=!1}static get styles(){return it`
    :host {
      display: inline-block;
    }
    button {
      background: none;
      cursor: pointer;
      outline: none;
      border: none;
      border-radius: 50%;
      overflow: hidden;
      padding: 10px;
      color: inherit;
      user-select: none;
      position: relative;
      vertical-align: middle;
    }
    soso-icon {
      width: 24px;
      height: 24px;
    }
    button::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: var(--soso-highlight-color, #018786);
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    button:focus::before {
      opacity: 0.12;
    }
    button:active::before {
      opacity: 0.22;
    }
    button soso-icon {
      transition: transform 0.3s ease, color 0.3s ease;
    }
    button:active soso-icon {
      transform: scale(1.05);
    }
    button.checked soso-icon {
      color: var(--soso-highlight-color, #018786);
    }
    span {
      display: inline;
      vertical-align: middle;
      user-select: none;
    }

    @media (hover: hover) {
      button:hover::before {
        opacity: 0.06;
      }
      button:focus::before {
        opacity: 0.12;
      }
      button:active::before {
        opacity: 0.22;
      }
    }
    `}render(){return Lt`
    <label>
      <button role="checkbox" class="${this.checked?"checked":"unchecked"}" @click="${this.toggle}">
        <soso-icon .iconkey="${js}" .icon="${this.checked?"filled":"unfilled"}"></soso-icon>
      </button>
      <span>
        <slot></slot>
      </span>
    </label>
    `}toggle(){this.checked=!this.checked,Os(this,"change",{checked:this.checked})}focus(){if(this.shadowRoot){const e=this.shadowRoot.querySelector("button");e&&e.focus()}}};Rs([oi({type:Boolean}),Es("design:type",Object)],Ls.prototype,"checked",void 0),Ls=Rs([Oi("soso-checkbox")],Ls);var zs=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Ms=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const As=window;class Ds extends ei{constructor(){super(...arguments),this.dir="ltr"}static get styles(){return it`
    * {box-sizing: border-box;}
    [hidden] {display: none !important;}
    .horizontal {display: flex; flex-direction: row;}
    .vertical {display: flex; flex-direction: column;}
    .center {align-items: center;}
    .center-center {justify-content: center; align-items: center;}
    .spaced {justify-content: space-between;}
    .flex {flex: 1;}
    .wrap {flex-wrap: wrap;}
    `}connectedCallback(){this.dir="rtl"===document.documentElement.dir?"rtl":"ltr",super.connectedCallback()}fire(e,t){this.dispatchEvent(new(As.SlickCustomEvent||CustomEvent)(e,{composed:!0,bubbles:!0,detail:t}))}}zs([oi({reflect:!0}),Ms("design:type",String)],Ds.prototype,"dir",void 0);const Hs="box-shadow .28s cubic-bezier(.4,0,.2,1), opacity 15ms linear 30ms, transform .27s cubic-bezier(0,0,.2,1) 0ms",Fs='"SF Pro Display", -apple-system, BlinkMacSystemFont, "San Francisco", "Helvetica Neue", Helvetica, Ubuntu, Roboto, Noto, "Segoe UI", Arial, sans-serif';var Bs=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Us=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Ns=class extends Ds{constructor(){super(...arguments),this.label="",this.type="text",this.disabled=!1,this.autocomplete="",this.hasText=!1}render(){return Lt`
    <style>
      :host {
        display: block;
      }
      #container {
        position: relative;
      }
      input {
        font-family: inherit;
        -moz-osx-font-smoothing: grayscale;
        -webkit-font-smoothing: antialiased;
        font-size: 1em;
        line-height: 1.75em;
        font-weight: 400;
        letter-spacing: .009375em;
        text-decoration: inherit;
        text-transform: inherit;
        box-sizing: border-box;
        width: 100%;
        height: 100%;
        border: none;
        border-radius: 0;
        background: none;
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        outline: none;
        color: var(--soso-input-color, rgba(0,0,0,.87));
        display: block;
        background-color: transparent;
        border-bottom: 2px solid #e5e5e5;
        padding: 12px 4px;
      }
      input:focus {
        border-color: var(--soso-highlight-color, #6200ee);
      }
      label {
        font-size: 0.8em;
        color: var(--soso-highlight-color, #6200ee);
        padding: 0 4px 4px;
        line-height: 1;
        display: block;
        transform: translateY(2.25em);
        opacity: 0;
        transition: ${Hs};
        pointer-events: none;
      }
      #container.notched label {
        transform: none;
        opacity: 1;
      }
    </style>

    <div id="container" class="vertical ${this.hasText?"notched":""}">
      <label>${this.label}</label>
      <input 
        type="${this.type}" 
        ?disabled="${this.disabled}" 
        autocomplete="${this.autocomplete}" 
        placeholder="${this.label}" @input="${this.onInput}">
    </div>
    `}focus(){this.input&&this.input.focus()}firstUpdated(){this.pendingValue&&(this.input.value=this.pendingValue,this.pendingValue=void 0,this.onInput())}onInput(e){e&&e.stopPropagation();const t=this.input.value;this.hasText=!!t,this.fire("input")}get value(){return this.input?this.input.value:void 0!==this.pendingValue?this.pendingValue:""}set value(e){this.input?(this.input.value=e,this.onInput()):this.pendingValue=e}};Bs([oi(),Us("design:type",Object)],Ns.prototype,"label",void 0),Bs([oi(),Us("design:type",Object)],Ns.prototype,"type",void 0),Bs([oi({type:Boolean}),Us("design:type",Object)],Ns.prototype,"disabled",void 0),Bs([oi({type:String}),Us("design:type",Object)],Ns.prototype,"autocomplete",void 0),Bs([ni(),Us("design:type",Object)],Ns.prototype,"hasText",void 0),Bs([ai("input"),Us("design:type",HTMLInputElement)],Ns.prototype,"input",void 0),Ns=Bs([ii("slick-text-input")],Ns);var Vs=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},qs=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Ws=class extends ei{constructor(){super(...arguments),this.label=""}static get styles(){return it`
    :host {
      display: block;
      max-width: 500px;
      margin: 0 auto;
      box-sizing: border-box;
      background: white;
      border-radius: 3px;
      overflow: hidden;
      box-shadow: 0 11px 15px -7px rgba(0,0,0,.2), 0 24px 38px 3px rgba(0,0,0,.14), 0 9px 46px 8px rgba(0,0,0,.12);
    }
    #toolbar {
      padding: 16px;
      text-transform: capitalize;
      text-align: var(--soso-dialog-title-align, left);
      background: var(--soso-dialog-title-bg, var(--slick-discovery-highlight-color, #018786));
      color: var(--soso-dialog-title-color, white);
      border-bottom: var(--soso-dialog-title-border, none);
      letter-spacing: 0.8px;
      font-size: 1.15em;
      display: var(--soso-dialog-title-display, block);
    }
    #content {
      padding: var(--soso-dialog-content-padding, 16px);
    }
    #footer {
      padding: 16px;
      text-align: var(--soso-dialog-footer-align, right);
      background: var(--soso-dialog-footer-bg, none);
      border-top: var(--soso-dialog-footer-border, none);
    }
    #footer ::slotted(*) {
      margin-left: 8px;
    }
    `}render(){return Lt`
    <div id="toolbar">${this.label}</div>
    <div id="content">
      <slot name="main"></slot>
    </div>
    <div id="footer">
      <slot name="footer"></slot>
    </div>
    `}};Vs([oi(),qs("design:type",Object)],Ws.prototype,"label",void 0),Ws=Vs([Oi("soso-dialog-view")],Ws);var Gs=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Ks=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Ys=class extends ei{constructor(){super(...arguments),this.outlined=!1,this.solid=!1,this.disabled=!1}static get styles(){return it`
    :host {
      display: inline-block;
      font-size: 14px;
      text-transform: uppercase;
    }
    button {
      cursor: pointer;
      outline: none;
      border-radius: var(--soso-button-radius, 4px);
      overflow: hidden;
      color: inherit;
      user-select: none;
      position: relative;
      font-family: inherit;
      text-align: center;
      font-size: inherit;
      letter-spacing: 1.25px;
      padding: var(--soso-button-padding, 1px 8px);
      min-height: 36px;
      text-transform: inherit;
      width: 100%;
      box-sizing: border-box;
    }
    button.flat {
      background: none;
      border: none;
    }
    button.outlined {
      background: none;
      border: 2px solid;
      padding: 1px 10px;
    }
    button.solid {
      background: currentColor;
      border: none;
      padding: 1px 10px;
      transition: box-shadow 0.3s ease;
      min-height: 40px;
    }

    button::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: currentColor;
      opacity: 0;
      pointer-events: none;
    }
    button:focus::before {
      opacity: 0.1;
    }
    button.solid::before {
      display: none;
    }
    button.solid:focus {
      box-shadow: 0 6px 10px 0 rgba(0, 0, 0, 0.14), 0 1px 18px 0 rgba(0, 0, 0, 0.12), 0 3px 5px -1px rgba(0, 0, 0, 0.4);
    }
    
    button.solid span {
      color: var(--soso-button-text-color, white);
    }
    button span {
      display: inline-block;
      transition: transform 0.2s ease;
    }
    button:active span {
      transform: scale(1.02);
    }

    button:disabled {
      opacity: 0.8;
      color: var(--soso-disabled-color, #808080);
      cursor: initial;
      pointer-events: none;
    }
    button.solid:disabled::before {
      opacity: 0.2;
    }

    @media (hover: hover) {
      button:hover::before {
        opacity: 0.05;
      }
      button.solid:hover {
        box-shadow: 0 3px 4px 0 rgba(0, 0, 0, 0.14), 0 1px 8px 0 rgba(0, 0, 0, 0.12), 0 3px 3px -2px rgba(0, 0, 0, 0.4);
      }
      button:focus::before {
        opacity: 0.1;
      }
      button.solid:focus {
        box-shadow: 0 6px 10px 0 rgba(0, 0, 0, 0.14), 0 1px 18px 0 rgba(0, 0, 0, 0.12), 0 3px 5px -1px rgba(0, 0, 0, 0.4);
      }
    }
    `}render(){const e=this.solid?"solid":this.outlined?"outlined":"flat";return Lt`
    <button class="${e}" ?disabled="${this.disabled}">
      <span>
        <slot></slot>
      </span>
    </button>`}updated(e){e.has("disabled")&&(this.style.pointerEvents=this.disabled?"none":"")}focus(){if(this.shadowRoot){const e=this.shadowRoot.querySelector("button");e&&e.focus()}}};Gs([oi({type:Boolean}),Ks("design:type",Object)],Ys.prototype,"outlined",void 0),Gs([oi({type:Boolean}),Ks("design:type",Object)],Ys.prototype,"solid",void 0),Gs([oi({type:Boolean}),Ks("design:type",Object)],Ys.prototype,"disabled",void 0),Ys=Gs([Oi("soso-button")],Ys);var Zs=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Qs=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Xs=class extends ei{constructor(){super(...arguments),this.default="home",this.pages=[],this.pageMap=new Map}set selectedForced(e){this.selected=e,this.requestUpdate()}static get styles(){return it`
    :host {
      display: contents;
    }

    .hidden {
      display: none !important;
    }
  
    ::slotted(.hidden) {
      display: none !important;
    }

    :host ::slotted(.hidden) {
      display: none !important;
    }
    `}render(){return Lt`
    <slot id="slot" @slotchange="${this.mapPages}"></slot>
    `}mapPages(){if(this.pages=[],this.pageMap.clear(),this.slotElement){const e=this.slotElement.assignedNodes();if(e&&e.length)for(let t=0;t<e.length;t++){const i=e[t];if(i.nodeType===Node.ELEMENT_NODE){const e=i;this.pages.push(e);const t=e.getAttribute("name")||"";t&&t.trim().split(" ").forEach((t=>{t&&this.pageMap.set(t,e)}))}}}this.updated()}firstUpdated(){this.mapPages()}updated(){const e=this.getElement(),t=e===this.current;if(this.current&&!t&&this.current.onDeactivate)try{this.current.onDeactivate()}catch(e){console.error(e)}for(let t=0;t<this.pages.length;t++){const i=this.pages[t];i===e?i.classList.remove("hidden"):i.classList.add("hidden")}if(this.current=e||void 0,this.current&&this.current.onActivate)try{this.current.onActivate()}catch(e){console.error(e)}this.current&&Os(this,"node-select",{node:this.current},!1)}getElement(){let e;return this.selected&&(e=this.pageMap.get(this.selected)),!e&&this.default&&(e=this.pageMap.get(this.default)),e||null}};Zs([oi({type:String}),Qs("design:type",String)],Xs.prototype,"selected",void 0),Zs([oi({type:String}),Qs("design:type",String)],Xs.prototype,"default",void 0),Zs([ai("slot"),Qs("design:type",HTMLElement)],Xs.prototype,"slotElement",void 0),Xs=Zs([Oi("soso-selector")],Xs);var Js=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},eo=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let to=class extends Ts{constructor(){super(...arguments),this.exclusive=!1,this.sso=!1,this._state="default",this.disabled=!0,this.buttonLabel="",this.message=""}render(){var e;const t=!(null===(e=this.membershipSettings)||void 0===e?void 0:e.emailContactIsNotDefault);let i=this.membershipSettings&&this.membershipSettings.emailUsageMessage;return i||(i=this.membershipSettings&&this.membershipSettings.ignoreMediavineApis?Ze.phrase("notify-about-content"):function(){var e;return!!(null===(e=window.$mediavine)||void 0===e?void 0:e.web)}()?Ze.phrase("notify-about-content-and-personalize"):Ze.phrase("notify-about-content")),Lt`
    <style>
      :host {
        --soso-highlight-color: var(--slick-discovery-highlight-color);
        font-size: 15px;
      }
      soso-button {
        color: var(--slick-discovery-highlight-color);
      }

      slick-text-input {
        margin-top: 20px;
      }

      soso-checkbox {
        margin-top: 10px;
      }

      #gotoForgetPassword {
        color: var(--slick-discovery-highlight-color);
        background: none;
        border: none;
        outline: none;
        cursor: pointer;
        font-size: 14px;
        padding: 8px;
        letter-spacing: 1px;
      }

      #form.default #chkEmail,
      #form.default #txtName,
      #form.default #txtPassword,
      #form.default #gotoForgetPassword {
        display: none !important;
      }
      #form.default.sso #txtEmail {
        display: none !important;
      }

      #form.signin #chkEmail,
      #form.signin #txtEmail,
      #form.signin #txtName {
        display: none !important;
      }

      #form.signup #txtEmail {
        display: none !important;
      }

      #form.forgot #chkEmail,
      #form.forgot #txtName,
      #form.forgot #txtPassword,
      #form.forgot #gotoForgetPassword {
        display: none !important;
      }

      #form.code-sent #chkEmail,
      #form.code-sent #txtEmail,
      #form.code-sent #txtName,
      #form.code-sent #txtPassword,
      #form.code-sent #gotoForgetPassword {
        display: none !important;
      }
      
    </style>
    <soso-dialog-view label="${Ze.phrase("sign-in")}">
      <div slot="main" id="form" class="${this._state} ${this.sso?"sso":""}" @input="${this.onInput}">
        <div clas="message">${this.message}</div>
        <slick-text-input id="txtEmail" label="${Ze.phrase("your-email")}"></slick-text-input>
        <slick-text-input id="txtName" label="${Ze.phrase("your-name")}"></slick-text-input>
        <slick-text-input id="txtPassword" label="${Ze.phrase("password")}" type="password"></slick-text-input>
        <soso-checkbox .checked="${t}" id="chkEmail">${i}</soso-checkbox>
        <div style="padding: 8px 0 0;">
          <button id="gotoForgetPassword" @click="${()=>this.setState("forgot")}">${Ze.phrase("forgot-password")}</button>
        </div>
      </div>

      ${"code-sent"!==this._state?Lt`<soso-button id="cancelButton" slot="footer" @click="${this.hideAndLog}">${Ze.phrase("cancel")}</soso-button>`:null}
      <soso-button slot="footer" .disabled="${this.disabled&&!this.sso}" @click="${this.submit}">${this.buttonLabel}</soso-button>
    </soso-dialog-view>
    `}hideAndLog(){this.hide(),this.pageToHeart&&Ze.widgetAction("heartbeat","cancel-membership-dialog",this.pageToHeart)}firstUpdated(){this.resetState()}async beforeShow(){this.resetState()}resetState(){this.setState("default"),this.clearFields()}clearFields(){this.txtEmail&&(this.txtEmail.value=this.defaultEmail||"",this.txtPassword.value="",this.txtName.value="",this.onInput())}getDefaultSignupMessage(){var e;if(this.exclusive)return Ze.phrase("exclusive-content-dialog-text");return"mandatory-membership"===(null===(e=Ze.currentSession)||void 0===e?void 0:e.settings.membership.behavior)?Ze.phrase("default-mandatory-favorites-cta"):Ze.phrase("default-optional-favorites-cta")}setState(e){switch(this._state=e,this.onInput(),e){case"default":this.buttonLabel=`${Ze.phrase("sign-in")} / ${Ze.phrase("sign-up")}`,this.message=this.membershipSettings&&this.membershipSettings.memberSignupMessage||this.getDefaultSignupMessage();break;case"signin":this.buttonLabel=Ze.phrase("sign-in"),this.message=Ze.phrase("favorites-sign-in-cta");break;case"signup":this.buttonLabel=Ze.phrase("sign-up"),this.message=Ze.phrase("favorites-sign-up-cta");break;case"forgot":this.buttonLabel=Ze.phrase("submit"),this.message=Ze.phrase("favorites-reset-password-cta");break;case"code-sent":this.buttonLabel="OK",this.disabled=!1,this.message=Ze.phrase("check-email-for-reset-password")}this.focus()}focus(){if(this.txtEmail&&this.txtEmail.input)switch(this._state){case"default":case"forgot":setTimeout((()=>this.txtEmail.input.focus()),200);break;case"signin":setTimeout((()=>this.txtPassword.input.focus()),200);break;case"signup":setTimeout((()=>this.txtName.input.focus()),200)}}onInput(){if(this.txtEmail){const e=this.txtEmail.value.trim(),t=e&&ie(e),i=this.txtPassword.value.trim();let s=!0;switch(this._state){case"signup":case"signin":s=!i;break;case"forgot":case"default":s=!t;break;case"code-sent":s=!1}this.disabled=s}}onEnterKey(){this.submit()}submit(){switch(this._state){case"default":this.sso?pi(this,"sso"):this.checkEmail();break;case"signin":this.signin();break;case"signup":this.signup();break;case"forgot":this.requestPasswordReset();break;case"code-sent":this.hide()}}areInputsValid(){return this.onInput(),!this.disabled}async checkEmail(){if(this.areInputsValid())try{const e=this.txtEmail.value.trim(),t=await Ze.checkMembership(e);t.isExistingMember&&t.hasPassword?this.setState("signin"):this.setState("signup")}catch(e){console.error(e),window.alert(e.message||e)}}async signin(){if(this.areInputsValid())try{const e=this.txtEmail.value.trim(),t=this.txtPassword.value.trim();await Ze.memberSignin(e,t),this.fireRefreshState()}catch(e){console.error(e),window.alert(e.message||e)}}async signup(){if(this.areInputsValid()&&this.areInputsValid())try{const e=this.txtEmail.value.trim(),t=this.txtPassword.value.trim(),i=this.txtName.value.trim(),s=this.chkEmail.checked;await Ze.memberSignup(e,t,s,i),this.fireRefreshState()}catch(e){console.error(e),window.alert(e.message||e)}}async requestPasswordReset(){if(this.areInputsValid()&&this.areInputsValid())try{const e=this.txtEmail.value.trim();await Ze.requestMemberPasswordReset(e),this.txtPassword.value="",this.setState("code-sent")}catch(e){console.error(e),window.alert(e.message||e)}}async fireRefreshState(){this.hide(),this.pageToHeart&&(await Ze.addHearts(1,this.pageToHeart),this.pageToHeart=void 0),pi(this,"update")}};Js([oi({type:Object}),eo("design:type",Object)],to.prototype,"membershipSettings",void 0),Js([oi({type:Number}),eo("design:type",Number)],to.prototype,"pageToHeart",void 0),Js([oi(),eo("design:type",String)],to.prototype,"defaultEmail",void 0),Js([oi({type:Boolean}),eo("design:type",Object)],to.prototype,"exclusive",void 0),Js([oi({type:Boolean}),eo("design:type",Object)],to.prototype,"sso",void 0),Js([ni(),eo("design:type",String)],to.prototype,"_state",void 0),Js([ni(),eo("design:type",Object)],to.prototype,"disabled",void 0),Js([ni(),eo("design:type",Object)],to.prototype,"buttonLabel",void 0),Js([ni(),eo("design:type",Object)],to.prototype,"message",void 0),Js([ai("#txtEmail"),eo("design:type",Ns)],to.prototype,"txtEmail",void 0),Js([ai("#txtPassword"),eo("design:type",Ns)],to.prototype,"txtPassword",void 0),Js([ai("#txtName"),eo("design:type",Ns)],to.prototype,"txtName",void 0),Js([ai("#chkEmail"),eo("design:type",Ls)],to.prototype,"chkEmail",void 0),to=Js([ii("slick-membership-dialog")],to);var io=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},so=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let oo=class extends Ds{constructor(){super(...arguments),this.showing=!1,this.autohide=!0,this.closeListener=()=>this.showing=!1}render(){return Lt`
    <style>
      :host {
        display: block;
        position: absolute;
        left: 0;
        bottom: 100%;
      }
      #container {
        margin-bottom: 6px;
        border-radius: 3px;
        background: var(--slick-popup-actions-background, white);
        color: var(--slick-discovery-highlight-color, #2196f3);
        text-align: center;
        border: var(--slick-popup-actions-border, none);
        box-shadow: var(--slick-popup-actions-shadow, 0 2px 1px -1px rgba(0,0,0,.2), 0 1px 1px 0 rgba(0,0,0,.14), 0 1px 3px 0 rgba(0,0,0,.12));
        transform: var(--slick-popup-actions-initial-transform, translate3d(0, 50%, 0));
        opacity: 0;
        pointer-events: none;
        transition: transform .2s cubic-bezier(0,0,.2,1), opacity 0.28s linear;
      }
      #container.showing {
        opacity: 1;
        pointer-events: auto;
        transform: none;
      }
      ::slotted(button) {
        background: none;
        border: none;
        outline: none;
        cursor: pointer;
        color: inherit;
        font-size: 12px;
        font-family: sans-serif;
        letter-spacing: 0.5px;
        padding: 12px;
        border-bottom: 1px solid #eaeaea;
        user-select: none;
        width: 161px;
        line-height: 1.5;
      }
      ::slotted(button:last-child) {
        border-bottom: none;
      }
    </style>
    <div id="container" class="vertical ${this.showing?"showing":""}">
      <slot></slot>
    </div>
    `}updated(e){e.has("showing")&&(this.autohide&&this.showing?document.addEventListener("click",this.closeListener):document.removeEventListener("click",this.closeListener)),this.style.pointerEvents=this.showing?"auto":"none"}};io([oi({type:Boolean}),so("design:type",Object)],oo.prototype,"showing",void 0),io([oi({type:Boolean}),so("design:type",Object)],oo.prototype,"autohide",void 0),oo=io([ii("slick-popup-actions")],oo);var no=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},ro=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let ao=class extends Ds{constructor(){super(...arguments),this.label="",this.icon="",this.activeIcon="",this.active=!1}render(){return Lt`
    <style>
      :host {
        display: inline-block; 
      }
      #iconPanel {
        position: relative;
      }
      soso-icon {
        transition: opacity 100ms linear 30ms, transform .27s cubic-bezier(0,0,.2,1) 0ms;
        width: var(--fab-icon-size, 24px);
        height: var(--fab-icon-size, 24px);
      }
      button {
        background-color: var(--fab-background, none);
        background-size: cover;
        background-origin: border-box;
        background-position: 50% 50%;
        cursor: pointer;
        outline: none;
        border: none;
        overflow: hidden;
        padding: var(--fab-padding, 10px);
        border-radius: 50%;
        color: inherit;
        user-select: none;
        position: relative;
        transition: ${Hs};
      }
      button::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: var(--fab-before-bg, currentColor);
        opacity: 0;
        transition: ${Hs};
      }
      button:focus::before {
        opacity: 0.1;
      }
      #icon {
        opacity: 1;
      }
      #activeIcon {
        position: absolute;
        top: 0;
        left: 0;
        opacity: 0;
        transform: rotateZ(-90deg);
      }
      img {
        display: block;
        border-radius: 50%;
        height: 48px;
        width: 48px;
      }
      button.hasImage {
        padding: 0;
      }
      button[active] #activeIcon {
        opacity: 1;
        transform: none;
      }
      button[active] #icon {
        opacity: 0;
        transform: rotateZ(90deg);
      }

      @media (hover: hover) {
        button:hover::before {
          opacity: 0.05;
        }
        button:focus::before {
          opacity: 0.1;
        }
      }
    </style>
    <button 
      ?active="${this.active}"
      aria-label="${this.label||this.icon||""}" 
      class="horizontal center ${this.image?"hasImage":""}">

      ${this.image?Lt`
        <img src="${this.image}" alt="${this.label}">
        `:Lt`
        <div id="iconPanel">
          <soso-icon id="icon" .icon="${this.icon}" .customSvg="${this.customSvg}"></soso-icon>
          <soso-icon id="activeIcon" .icon="${this.activeIcon}" .customSvg="${this.customSvgActive}"></soso-icon>
        </div>
        `}
    </button>
    `}};no([oi(),ro("design:type",Object)],ao.prototype,"label",void 0),no([oi(),ro("design:type",Object)],ao.prototype,"icon",void 0),no([oi(),ro("design:type",Object)],ao.prototype,"activeIcon",void 0),no([oi(),ro("design:type",String)],ao.prototype,"customSvg",void 0),no([oi(),ro("design:type",String)],ao.prototype,"customSvgActive",void 0),no([oi(),ro("design:type",String)],ao.prototype,"image",void 0),no([oi({type:Boolean}),ro("design:type",Object)],ao.prototype,"active",void 0),ao=no([ii("slick-toggle-button")],ao);var lo=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},co=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let ho=class extends Ds{constructor(){super(...arguments),this.minFavVisibleCount=0,this.isFavorite=!1,this.favIcon="heart",this.totalFavorites=0,this.rightAlignPopup=!1,this.savedPopupShowing=!1}render(){const e=!Ze.isMemberSignedIn();return Lt`
    <style>
      :host {
        display: block;
        position: relative;
      }
      #favCount {
        color: var(--slick-discovery-highlight-color, #2196f3);
        font-size: 13px;
        font-family: sans-serif;
        line-height: 1;
        transform: translateX(-5px);
        pointer-events: none;
        white-space: nowrap;
      }
      #savedLabel {
        font-size: 13px;
        font-family: sans-serif;
        line-height: 1;
        padding: 6px;
        pointer-events: none;
        white-space: nowrap;
      }

      slick-popup-actions.rightAlignedPopup {
        right: 0;
        left: auto;
      }
    </style>
    <style rtl>
      :host([dir="rtl"]) #favCount {
        transform: translateX(5px);
      }
      :host([dir="rtl"]) slick-popup-actions {
        right: 0;
        left: auto;
      }
      :host([dir="rtl"]) slick-popup-actions.rightAlignedPopup {
        right: auto;
        left: 0;
      }
    </style>
    <div class="horizontal center">
      <slick-toggle-button
        .active="${this.isFavorite||!1}" 
        .icon="${this.favIcon}-outline"
        .activeIcon="${this.favIcon}"
        .customSvg="${this.customSvg}"
        .customSvgActive="${this.customSvgActive}"
        label="${this.isFavorite?"Favorite":"Save to favorites"}"
        @click="${this.toggleFav}">
      </slick-toggle-button>
      <div id="favCount">${this.countString(this.totalFavorites)}</div>
      <span class="flex"></span>
    </div>
    <slick-popup-actions
      class="${this.rightAlignPopup?"rightAlignedPopup":""}"
      .autohide="${!1}"
      .showing="${this.savedPopupShowing}"
      style="--slick-popup-actions-shadow: none; --slick-popup-actions-border: 1px solid #f0f0f0;">
      <div id="savedLabel">${Ze.phrase("favorite-added")}</div>
    </slick-popup-actions>
    <slick-popup-actions id="popupMenu" class="${this.rightAlignPopup?"rightAlignedPopup":""}">
      <button @click="${this.removeFavorite}">${Ze.phrase("remove-favorite")}</button>
      <button @click="${this.viewFavorites}">${this.getMyFavsLabel()}</button>
      ${e?Lt`<button @click="${this.signin}">${Ze.phrase("prompt-to-sign-in-short")}</button>`:""}
    </slick-popup-actions>
    `}getMyFavsLabel(){var e,t;let i=null===(t=null===(e=Ze.currentSession)||void 0===e?void 0:e.settings.discovery)||void 0===t?void 0:t.myFavoritesText;return i||(i=Ze.phrase("my-favorite-pages")),i}countString(e){return e<=0||e<=this.minFavVisibleCount?"":e>=1e6?`${(e/1e6).toFixed(1)}M`:e>=1e4?`${(e/1e3).toFixed(1)}k`:e.toLocaleString()}async toggleFav(e){var t;e.stopPropagation(),e.preventDefault();if(!(null===(t=Ze.currentSession)||void 0===t?void 0:t.settings.membership.disableHeartPopup))if(this.isFavorite)this.savedPopupShowing=!1,this.popActions&&(this.popActions.showing||await this.requestUpdate(),this.popActions.showing=!this.popActions.showing);else{let e=!0;Ze.shouldSigninToFav()&&!Ze.isMemberSignedIn()&&(e=!1),e&&(this.savedPopupShowing=!0,setTimeout((()=>{this.savedPopupShowing=!1}),2500)),pi(this,"toggle-favorite")}else pi(this,"toggle-favorite")}removeFavorite(){this.popActions.showing=!1,this.isFavorite&&pi(this,"toggle-favorite")}viewFavorites(){this.popActions.showing=!1,pi(document.documentElement,"slick-show-discovery",{page:"favorites"})}signin(){this.popActions.showing=!1,pi(this,"signin-and-fav")}};lo([oi({type:Number}),co("design:type",Object)],ho.prototype,"minFavVisibleCount",void 0),lo([oi({type:Boolean}),co("design:type",Object)],ho.prototype,"isFavorite",void 0),lo([oi(),co("design:type",Object)],ho.prototype,"favIcon",void 0),lo([oi(),co("design:type",String)],ho.prototype,"customSvg",void 0),lo([oi(),co("design:type",String)],ho.prototype,"customSvgActive",void 0),lo([oi({type:Number}),co("design:type",Object)],ho.prototype,"totalFavorites",void 0),lo([oi({type:Boolean}),co("design:type",Object)],ho.prototype,"rightAlignPopup",void 0),lo([ni(),co("design:type",Object)],ho.prototype,"savedPopupShowing",void 0),lo([ai("#popupMenu"),co("design:type",oo)],ho.prototype,"popActions",void 0),ho=lo([ii("slick-heart-button")],ho);var po=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},uo=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let go=class extends Ds{constructor(){super(...arguments),this.favs=!0,this.minFavVisibleCount=0,this.showStoryIndicators=!1}render(){var e,t,i,s,o;if(!this.data)return Lt``;const n=Ze.thumbnailUrl(this.data,void 0,128)||(null===(t=null===(e=this.data)||void 0===e?void 0:e.image)||void 0===t?void 0:t.url)||"",r=n?`background-image: url("${n}");`:"#f0f0f0",a=ci,l=(null===(i=this.favSettings)||void 0===i?void 0:i.iconType)||"heart",c=this.data.pinned||!1,h=this.data.viewerUrl||this.data.url,d=this.showStoryIndicators&&"web-story"===this.data.type;return Lt`
    <style>
      :host {
        display: block;
        width: var(--slick-discovery-cell-width, 262px);
        margin: 16px 0;
        box-sizing: border-box;
      }
      .hidden {
        display: none !important;
      }
      #card {
        background: var(--slick-grid-page-item-bg, white);
        font-size: 13px;
        padding: 0 12px;
        position: relative;
      }
      #imageContainer {
        border-radius: var(--slick-search-image-radius, 5px);
        overflow: hidden;
        width: 100%;
      }
      #imagePanel {
        height: var(--slick-discovery-cell-height, 128px);
        width: 100%;
        background-color: #f0f0f0;
        background-size: cover;
        background-origin: border-box;
        background-repeat: no-repeat;
        background-position: 50% 50%;
        border: none;
        text-decoration: none;
        color: inherit;
        position: relative;
        outline: none;
        box-sizing: border-box;
        margin: 0;
        transition: transform 0.3s ease;
        display: block;
        overflow: hidden;
      }
      #segmentIcon {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 48px;
        height: auto;
        display: block;
        margin-left: -24px;
        margin-top: -24px;
        pointer-events: none;
      }
      #segmentIcon.hidden {
        display: none !important;
      }
      a#name {
        text-decoration: none;
        font-size: var(--slick-search-results-name-size, 14px);
        color: inherit;
        outline: none;
        margin: 8px 0 0;
        display: block;
        word-break: break-word;
      }
      slick-heart-button {
        background: var(--slick-grid-page-item-bg, rgba(255,255,255,1));
        border-radius: 20px 0 0 0;
        margin-top: -30px;
        cursor: initial;
        color: var(--slick-discovery-highlight-color, #2196f3);
      }
      #floatedCell {
        float: right;
      }

      #pinnedLabel {
        color: #808080;
        font-size: 12px;
        letter-spacing: 0.5px;
        padding: 12px 0;
        display: none;
      }
      #pinnedLabel soso-icon {
        margin-right: 8px;
        width: 18px;
        height: 18px;
      }

      #card.pinned::before {
        content: '';
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        background: var(--slick-discovery-highlight-color, #2196f3);
        opacity: 0.1;
      }
      #card.pinned #pinnedLabel {
        display: flex;
      }
      #card.pinned slick-heart-button::before {
        content: '';
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        background: var(--slick-discovery-highlight-color, #2196f3);
        opacity: 0.1;
      }

      a#name:focus {
        color: var(--slick-discovery-highlight-color, #2196f3);
      }
      #imagePanel:focus {
        transform: scale(1.05);
      }
      .webstory #imagePanel:focus {
        transform: none;
      }
      #storyLabel {
        background: rgba(0,0,0,0.3);
        color: white;
        padding: 8px;
        position: absolute;
        top: 0;
        left: 0;
        border-radius: 0 0 5px 0;
        pointer-events: none;
        display: none;
      }
      .webstory #storyLabel {
        display: flex;
      }
      #storyLabel label {
        font-family: sans-serif;
        font-size: 11px;
        text-transform: uppercase;
        font-weight: 500;
        letter-spacing: 0.5px;
        padding-left: 6px;
        margin-left: -76px;
        opacity: 0;
        transition: opacity 0.18s ease, margin 0.18s ease;
      }
      #storyLabel soso-icon {
        width: 20px;
        height: 20px;
      }

      @media (max-width: 600px) {
        :host {
          width: 50%;
        }
      }

      @media(hover:hover) {
        a#name:hover {
          color: var(--slick-discovery-highlight-color, #2196f3);
        }
        #imagePanel:hover{
          transform: scale(1.05);
        }
        .webstory #imagePanel:hover{
          transform: none;
        }
        .webstory #imagePanel:hover #storyLabel label{
          margin-left: 0;
          opacity: 1;
        }
      }
    </style>
    <style rtl>
      :host([dir="rtl"]) #floatedCell {
        float: left;
      }
      :host([dir="rtl"]) slick-heart-button {
        border-radius: 0 20px 0 0;
      }
      :host([dir="rtl"]) #storyLabel label {
        padding-right: 6px;
        padding-left: 0;
      }
    </style>
    <div id="card" class="vertical ${d?"webstory":""} ${c?"pinned":""}">
      <div id="imageContainer">
        <a id="imagePanel" aria-label="${this.data.titleText||""}" href="${h}" style="${r}" @click="${this.onLinkClick}">
          <img id="segmentIcon" class="${"hidden"}" src="${a}">
          <div id="storyLabel" class="horizontal center" title="Web Story">
            <soso-icon icon="carousel"></soso-icon>
            <label>Web Story</label>
          </div>
        </a>
      </div>
      <div style="position: relative;">
        <a id="name" href="${h}" @click="${this.onLinkClick}">
          <div id="floatedCell" @click="${e=>{e.stopPropagation(),e.preventDefault()}}">
            <slick-heart-button 
              class="${this.favs?"":" hidden"}"
              .minFavVisibleCount="${this.minFavVisibleCount}"
              .isFavorite="${this.data.isFavorite||!1}"
              .favIcon="${l}"
              .customSvg="${"custom"===l?null===(s=this.favSettings)||void 0===s?void 0:s.customSvgOutline:void 0}"
              .customSvgActive="${"custom"===l?null===(o=this.favSettings)||void 0===o?void 0:o.customSvgFilled:void 0}"
              .totalFavorites="${this.data.totalFavorites}"
              .rightAlignPopup="${!0}"
              @toggle-favorite="${this.toggleFav}">
            </slick-heart-button>
          </div>
          <span>${this.data.titleText||this.data.titleHtml||""}</span>
        </a>
        <div id="pinnedLabel" class="horizontal center">
          <soso-icon icon="pin"></soso-icon>
          <span>Pinned post</span>
        </div>
      </div>
    </div>
    `}onLinkClick(e){const t=e.currentTarget;t&&t.href&&(e.stopPropagation(),this.fire("nav",{href:t.href}))}toggleFav(){if(this.data){if(this.data.isFavorite)Ze.removeFavorite(this.data.id),this.data.totalFavorites--;else{if(Ze.shouldSigninToFav())return void this.fire("signin-and-fav",{pageId:this.data.id});Ze.addHearts(1,this.data.id),this.data.totalFavorites++}this.data.isFavorite=!this.data.isFavorite,this.requestUpdate()}}};po([oi({type:Object}),uo("design:type",Object)],go.prototype,"data",void 0),po([oi({type:Boolean}),uo("design:type",Object)],go.prototype,"favs",void 0),po([oi({type:Object}),uo("design:type",Object)],go.prototype,"favSettings",void 0),po([oi({type:Number}),uo("design:type",Object)],go.prototype,"minFavVisibleCount",void 0),po([oi({type:Boolean}),uo("design:type",Object)],go.prototype,"showStoryIndicators",void 0),go=po([ii("search-view-page-item")],go);var fo=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},vo=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let mo=class extends ei{constructor(){super(...arguments),this.favs=!0,this.imageContainmentStyle="cover",this.minFavVisibleCount=0,this.showStoryIndicators=!1}static get styles(){return hi}render(){var e,t,i,s;if(!this.data)return Lt``;const o=Ze.thumbnailUrl(this.data,void 0,128)||(null===(t=null===(e=this.data)||void 0===e?void 0:e.image)||void 0===t?void 0:t.url)||"",n=("contain"===this.imageContainmentStyle?"background-size: contain; background-position: var(--slick-search-list-item-image-position, 50% 0%); background-color: transparent; ":"")+(o?`background-image: url("${o}");`:"background-color:#f0f0f0"),r=ci,a=(null===(i=this.favSettings)||void 0===i?void 0:i.iconType)||"heart",l=this.data.pinned||!1,c=this.data.viewerUrl||this.data.url,h=this.showStoryIndicators&&"web-story"===this.data.type;return Lt`
    <style>
      :host {
        display: block;
        margin: 16px 0;
      }
      .hidden {
        display: none !important;
      }
      #card {
        background: white;
        position: relative;
      }
      #imagePanel {
        width: var(--slick-search-list-item-width, 128px);
        min-height: 64px;
        height: var(--slick-search-list-item-height);
        background-color: #f0f0f0;
        background-size: cover;
        background-origin: border-box;
        background-repeat: no-repeat;
        background-position: var(--slick-search-list-item-image-position, 50% 50%);
        border: none;
        text-decoration: none;
        color: inherit;
        position: relative;
        outline: none;
        box-sizing: border-box;
        margin: 0;
        border-radius: var(--slick-search-image-radius, 5px);
        transition: transform 0.3s ease;
      }
      #segmentIcon {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 48px;
        height: auto;
        display: block;
        margin-left: -24px;
        margin-top: -24px;
        pointer-events: none;
      }
      #segmentIcon.hidden {
        display: none !important;
      }
      a#name {
        text-decoration: none;
        font-size: 16px;
        color: inherit;
        outline: none;
        display: inline-block;
      }
      slick-heart-button {
        margin: 8px 0 0 -10px;
        color: var(--slick-discovery-highlight-color, #2196f3);
      }
      .description {
        opacity: 0.85;
        font-size: 14px;
        margin-top: 8px;
      }
      .description span.highlight {
        background: var(--slick-discovery-text-highlight-color, #FFF59D);
      }
      .timestamp {
        font-size: 12px;
        margin-top: 8px;
        color: #808080;
        letter-spacing: 0.5px;
      }

      #contentPanel {
        position: relative;
        padding: 12px 16px 0;
      }
      #pinnedLabel {
        color: #808080;
        font-size: 13px;
        letter-spacing: 0.5px;
        display: none;
        transform: translateX(5px);
      }
      #pinnedLabel soso-icon {
        margin-right: 8px;
        width: 20px;
        height: 20px;
      }

      #contentPanel.pinned {
        padding: 5px 16px 0;
      }
      #contentPanel.pinned #pinnedLabel {
        display: flex;
      }

      #card.pinned::before {
        content: '';
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        background: var(--slick-discovery-highlight-color, #2196f3);
        opacity: 0.1;
      }

      #imagePanel:focus {
        transform: scale(1.05);
      }
      a#name:focus {
        color: var(--slick-discovery-highlight-color, #2196f3);
      }
      .webstory #imagePanel:focus {
        transform: none;
      }
      #storyLabel {
        background: rgba(0,0,0,0.3);
        color: white;
        padding: 8px;
        position: absolute;
        top: 0;
        left: 0;
        border-radius: 0 0 5px 0;
        pointer-events: none;
        display: none;
      }
      .webstory #storyLabel {
        display: flex;
      }
      #storyLabel label {
        font-family: sans-serif;
        font-size: 11px;
        text-transform: uppercase;
        font-weight: 500;
        letter-spacing: 0.5px;
        padding-left: 6px;
        margin-left: -76px;
        opacity: 0;
        transition: opacity 0.18s ease, margin 0.18s ease;
      }
      #storyLabel soso-icon {
        width: 20px;
        height: 20px;
      }

      @media(hover:hover) {
        a#name:hover {
          color: var(--slick-discovery-highlight-color, #2196f3);
        }
        #imagePanel:hover{
          transform: scale(1.05);
        }
        .webstory #imagePanel:hover{
          transform: none;
        }
        .webstory #imagePanel:hover #storyLabel label{
          margin-left: 0;
          opacity: 1;
        }
      }
    </style>
    <div id="card" class="horizontal layout ${h?"webstory":""} ${l?"pinned":""}">
      <a id="imagePanel" aria-label="${this.data.titleText||""}" href="${c}" style="${n}" @click="${this.onLinkClick}">
        <img id="segmentIcon" class="${"hidden"}" src="${r}">
        <div id="storyLabel" class="horizontal layout center" title="Web Story">
          <soso-icon icon="carousel"></soso-icon>
          <label>Web Story</label>
        </div>
      </a>
      <div id="contentPanel" class="flex ${l?"pinned":""}">
        <div id="pinnedLabel" class="horizontal layout center">
          <span class="flex"></span>
          <soso-icon icon="pin"></soso-icon>
          <span>Pinned post</span>
        </div>

        <a id="name" href="${c}" @click="${this.onLinkClick}">
          <span>${this.data.titleText||this.data.titleHtml}</span>
        </a>

        <div class="${this.data.published?"timestamp":"hidden"}">${new Date(this.data.published).toLocaleDateString()}</div>

        <div class="description">
          ${(null===(s=this.data.recipe)||void 0===s?void 0:s.ingredientListHtml)||this.data.descriptionHtml||""}
        </div>

        <slick-heart-button 
          class="${this.favs?"":" hidden"}"
          .minFavVisibleCount="${this.minFavVisibleCount}"
          .isFavorite="${this.data.isFavorite||!1}"
          .favIcon="${a}"
          .totalFavorites="${this.data.totalFavorites}"
          @toggle-favorite="${this.toggleFav}">
        </slick-heart-button>
      </div>
    </div>
    `}onLinkClick(e){const t=e.currentTarget;t&&t.href&&(e.stopPropagation(),pi(this,"nav",{href:t.href}))}toggleFav(){if(this.data){if(this.data.isFavorite)Ze.removeFavorite(this.data.id),this.data.totalFavorites--;else{if(Ze.shouldSigninToFav())return void pi(this,"signin-and-fav",{pageId:this.data.id});Ze.addHearts(1,this.data.id),this.data.totalFavorites++}this.data.isFavorite=!this.data.isFavorite,this.requestUpdate()}}};fo([oi({type:Object}),vo("design:type",Object)],mo.prototype,"data",void 0),fo([oi({type:Boolean}),vo("design:type",Object)],mo.prototype,"favs",void 0),fo([oi({type:Object}),vo("design:type",Object)],mo.prototype,"favSettings",void 0),fo([oi(),vo("design:type",String)],mo.prototype,"imageContainmentStyle",void 0),fo([oi({type:Number}),vo("design:type",Object)],mo.prototype,"minFavVisibleCount",void 0),fo([oi({type:Boolean}),vo("design:type",Object)],mo.prototype,"showStoryIndicators",void 0),mo=fo([ii("search-view-page-list-item")],mo);var yo=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},bo=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let wo=class extends ei{constructor(){super(...arguments),this.imageContainmentStyle="cover"}static get styles(){return hi}render(){if(!this.data)return Lt``;const e=this.data.imageUrl||(this.data.imagePageId?Ze.thumbnailByPageId(this.data.imagePageId,void 0,128):""),t=e?`background-image: url("${e}");`:`background-color: ${this.data.color||"#f0f0f0"}`;let i=!1,s=ci;const o=this.data.iconUrlDarkBg||this.data.iconUrlLightBg;return!e&&o&&(s=o,i=!0),Lt`
    <style>
      :host {
        display: block;
        width: var(--slick-discovery-cell-width, 262px);
        margin: 12px 0;
      }
      .hidden {
        display: none !important;
      }
      #card {
        background: white;
        font-size: 13px;
        padding: 0 12px;;
        position: relative;
      }
      #imagePanel {
        min-height: var(--slick-category-card-height, 60px);
        background-color: #f0f0f0;
        background-size: cover;
        background-origin: border-box;
        background-repeat: no-repeat;
        background-position: 50% 50%;
        border: none;
        text-decoration: none;
        color: inherit;
        position: relative;
        outline: none;
        width: 100%;
        box-sizing: border-box;
        margin: 0;
        border-radius: var(--slick-search-image-radius, 5px);
        overflow: hidden;
      }
      #segmentIcon {
        height: 24px;
        width: auto;
        max-width: 24px;
        display: block;
        margin-right: 12px;
      }
      #segmentIcon.hidden {
        display: none !important;
      }
      #overlay {
        color: white;
        background: rgba(0,0,0,0.4);
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        text-align: center;
        font-size: 13px;
        letter-spacing: 0.5px;
        text-transform: uppercase;
        text-shadow: 0 0 1px rgba(0,0,0,0.6);
        box-sizing: border-box;
        padding: 6px 12px;
        cursor: pointer;
      }
      #overlay.noimage {
        background: none;
      }
      .underlay {
        position: absolute;
        box-sizing: border-box;
        background: rgba(0,0,0,0.1);
        left: 16px;
        top: 4px;
        right: 8px;
        bottom: -4px;
        border-radius: 5px;
      }
      .underlay:nth-child(2) {
        bottom: -8px;
        left: 20px;
        right: 4px;
        top: 8px;
      }
      #name {
        text-overflow: ellipsis;
        overflow: hidden;
        line-height: var(--slick-category-card-line-height, 1.4);
        max-height: var(--slick-category-card-max-text-height, 2.65em);
      }

      #imagePanel:focus {
        transform: scale(1.05);
      }

      @media(hover:hover) {
        #imagePanel {
          transition: transform 0.3s ease;
        }
        #imagePanel:hover {
          transform: scale(1.02);
        }
      }
    </style>
    <div id="card" class="vertical layout">
      <div class="underlay"></div>
      <div class="underlay"></div>
      <button id="imagePanel" style="${t}" @click="${this.onCardClick}">
        <div id="overlay" class="horizontal layout center ${e?"":"noimage"}">
          <img id="segmentIcon" class="${i?"":"hidden"}" src="${s}">
          <div id="name" class="flex">${this.data.name}</div>
        </div>
      </button>
    </div>
    `}onCardClick(){pi(this,"select-card",this.data)}};yo([oi({type:Object}),bo("design:type",Object)],wo.prototype,"data",void 0),yo([oi(),bo("design:type",String)],wo.prototype,"imageContainmentStyle",void 0),wo=yo([ii("search-view-category-item")],wo);var xo=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},ko=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let So=class extends ei{constructor(){super(...arguments),this.favs=!0,this.minFavVisibleCount=0,this.showStoryIndicators=!1}static get styles(){return hi}render(){var e,t,i;if(!this.data)return Lt``;const s=this.data.viewerUrl||this.data.url,o=(null===(t=null===(e=this.data)||void 0===e?void 0:e.image)||void 0===t?void 0:t.url)||Ze.thumbnailUrl(this.data,void 0,128)||"",n=(null===(i=this.favSettings)||void 0===i?void 0:i.iconType)||"heart";return Lt`
    <style>
      * {
        box-sizing: border-box;
      }
      :host {
        display: block;
        padding: 20px 12px;
        border-bottom: 1px solid #e5e5e5;
      }
      #metaPanel {
        flex: 0 0 25%;
        max-width: 25%;
      }
      slick-heart-button {
        margin: 8px 0 0 -10px;
        color: var(--slick-discovery-highlight-color, #2196f3);
      }
      time {
        font-size: var(--slick-article-date-size, 13px);
        display: block;
        letter-spacing: 1px;
        margin-bottom: 6px;
        color: #808080;
      }
      #inlineMetaPanel time {
        margin: 0;
      }
      .sectionTitle {
        font-size: var(--slick-article-section-title-size, 13px);
        text-transform: uppercase;
        letter-spacing: 1px;
      }
      a.titleLink {
        text-decoration: none;
        font-size: var(--slick-article-title-size, 20px);
        color: inherit;
        outline: none;
        display: inline-block;
        border: none;
      }
      #description {
        margin-top: 8px;
        font-size: var(--slick-article-description-size, 14px);
      }
      #byline {
        margin: 8px 0 0;
        font-size: var(--slick-article-author-size, 14px);
        color: #808080;
        font-style: italic;
      }
      #inlineMetaPanel {
        display: none;
        margin-bottom: 12px;
      }
      #imagePanel {
        margin-left: 16px;
      }
      a.imageLink {
        text-decoration: none;
        outline: none;
        border: none;
        display: block;
        transition: transform 0.28s ease;
        position: relative;
      }
      a.imageLink img {
        border-radius: var(--slick-search-image-radius, 5px);
        display: block;
        max-width: 128px;
        max-height: 190px;
        height: auto;
      }
      .overlayIcon {
        position: absolute;
        top: 50%;
        left: 50%;
        color: white;
        background: rgba(0,0,0,0.3);
        padding: 6px;
        box-sizing: initial;
        border-radius: 50%;
        transform: translate3d(-50%, -50%, 0);
        pointer-events: none;
      }
      .hidden {
        display: none !important;
      }
      #mainPanel slick-heart-button {
        display: none;
      }
      #pinnedLabel.horizontal.layout {
        color: var(--slick-discovery-highlight-color, #2196f3);
        font-size: 13px;
        letter-spacing: 0.5px;
        transform: translateX(5px);
        margin-bottom: 12px;
      }
      #pinnedLabel soso-icon {
        margin-right: 8px;
        width: 20px;
        height: 20px;
      }
    </style>
    <style>
      @media (max-width: 780px) {
        :host {
          padding: 16px 12px;
        }
        #metaPanel {
          display: none;
        }
        #inlineMetaPanel {
          display: flex;
        }
        a.imageLink img {
          max-width: 96px;
          max-height: 142px;
        }
        #mainPanel slick-heart-button {
          display: block;
        }
      }
    </style>
    <style>
      @media(hover:hover) {
        a.titleLink:hover {
          color: var(--slick-discovery-highlight-color, #2196f3);
        }
        a.imageLink:hover{
          transform: scale(1.05);
        }
      }
    </style>
    <div class="horizontal layout">
    
      <div id="metaPanel">
        ${this.data.published?Lt`
          <time datetime="${new Date(this.data.published).toISOString()}">${new Date(this.data.published).toLocaleDateString()}</time>
        `:""}
        ${this.data.sectionHtml?Lt`
          <div class="sectionTitle">${this.data.sectionHtml}</div>
        `:""}

        <slick-heart-button 
          class="${this.favs?"":" hidden"}"
          .minFavVisibleCount="${this.minFavVisibleCount}"
          .isFavorite="${this.data.isFavorite||!1}"
          .favIcon="${n}"
          .totalFavorites="${this.data.totalFavorites}"
          @toggle-favorite="${this.toggleFav}">
        </slick-heart-button>
      </div>

      <div id="mainPanel" class="flex">
        
        ${this.data.pinned?Lt`
        <div id="pinnedLabel" class="horizontal layout center">
          <soso-icon icon="pin"></soso-icon>
          <span>Pinned post</span>
        </div>
        `:""}
        
        <div id="inlineMetaPanel" class="horizontal layout">
          <div class="sectionTitle flex">${this.data.sectionHtml||""}</div>
          ${this.data.published?Lt`
            <time datetime="${new Date(this.data.published).toISOString()}">${new Date(this.data.published).toLocaleDateString()}</time>
          `:""}
        </div>
        <div class="horizontal layout">
          <div class="flex">
            <div id="titleLinkPanel">
              <a class="titleLink" @click="${this.onLinkClick}" href="${s}">${this.data.titleText||this.data.titleHtml||""}</a>
            </div>
            <p id="description">${this.data.descriptionHtml||""}</p>
            ${this.data.authorHtml?Lt`<p id="byline">By ${this.data.authorHtml}</p>`:""}

            <slick-heart-button 
              class="${this.favs?"":" hidden"}"
              .minFavVisibleCount="${this.minFavVisibleCount}"
              .isFavorite="${this.data.isFavorite||!1}"
              .favIcon="${n}"
              .totalFavorites="${this.data.totalFavorites}"
              @toggle-favorite="${this.toggleFav}">
            </slick-heart-button>
            
          </div>
          ${o?Lt`
          <div id="imagePanel">
            <a class="imageLink" 
              aria-label="${this.data.titleText||""}" 
              @click="${this.onLinkClick}" href="${s}">

              <img src="${o}">

              ${"web-story"===this.data.type?Lt`
                <soso-icon class="overlayIcon" icon="carousel"></soso-icon>
              `:""}
              ${"video"===this.data.type?Lt`
                <soso-icon class="overlayIcon" icon="play"></soso-icon>
              `:""}
            </a>
          </div>
          `:""}
        </div>
      </div>

    </div>
    `}onLinkClick(e){const t=e.currentTarget;t&&t.href&&(e.stopPropagation(),pi(this,"nav",{href:t.href}))}toggleFav(){if(this.data){if(this.data.isFavorite)Ze.removeFavorite(this.data.id),this.data.totalFavorites--;else{if(Ze.shouldSigninToFav())return void pi(this,"signin-and-fav",{pageId:this.data.id});Ze.addHearts(1,this.data.id),this.data.totalFavorites++}this.data.isFavorite=!this.data.isFavorite,this.requestUpdate()}}};xo([oi({type:Object}),ko("design:type",Object)],So.prototype,"data",void 0),xo([oi({type:Boolean}),ko("design:type",Object)],So.prototype,"favs",void 0),xo([oi({type:Object}),ko("design:type",Object)],So.prototype,"favSettings",void 0),xo([oi({type:Number}),ko("design:type",Object)],So.prototype,"minFavVisibleCount",void 0),xo([oi({type:Boolean}),ko("design:type",Object)],So.prototype,"showStoryIndicators",void 0),So=xo([ii("search-view-article-item")],So);var _o=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Co=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let $o=class extends ei{constructor(){super(...arguments),this.imageContainmentStyle="cover"}static get styles(){return hi}render(){if(!this.data)return Lt``;const e=this.data.iconUrlLightBg||this.data.iconUrlDarkBg||"";return Lt`
    <style>
      :host {
        display: block;
        width: var(--slick-discovery-cell-width, 262px);
        margin: 12px 0;
      }
      .hidden {
        display: none !important;
      }
      #card {
        background: white;
        font-size: 13px;
        padding: 0 12px;;
        position: relative;
      }
      #imagePanel {
        min-height: 60px;
        background-size: cover;
        background-origin: border-box;
        background-repeat: no-repeat;
        background-position: 50% 50%;
        border: none;
        text-decoration: none;
        color: inherit;
        position: relative;
        outline: none;
        width: 100%;
        box-sizing: border-box;
        margin: 0;
        border-radius: var(--slick-search-image-radius, 5px);
        overflow: hidden;
        background-color: #f5f5f5;
        border: 1px solid #e5e5e5;
      }
      #overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        text-align: center;
        font-size: 13px;
        text-transform: uppercase;
        letter-spacing: 0.2px;
        box-sizing: border-box;
        padding: 6px 12px;
        cursor: pointer;
        overflow: hidden;
        border-radius: var(--slick-search-image-radius, 5px);
      }
      #overlay::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        background: white;
        opacity: 0;
      }
      #name {
        position: relative;
      }
      #segmentIcon {
        height: 24px;
        width: auto;
        max-width: 24px;
        display: block;
        margin-right: 12px;
        position: relative;
      }
      #segmentIcon.hidden {
        display: none !important;
      }

      #imagePanel:focus {
        border: 1px solid var(--slick-discovery-highlight-color, #2196f3);
      }

      @media(hover:hover) {
        #overlay::before {
          transition: opacity 0.3s ease;
        }
        #overlay {
          transition: color 0.3s ease;
        }
        #overlay:hover {
          color: var(--slick-discovery-highlight-color, #2196f3);
        }
        #overlay:hover::before {
          opacity: 1;
        }
      }
    </style>
    <div id="card" class="vertical layout">
      <button id="imagePanel" @click="${this.onCardClick}">
        <div id="overlay" class="horizontal layout center">
          <img id="segmentIcon" class="${e?"":"hidden"}" src="${e}">
          <div id="name" class="flex">${this.data.name}</div>
        </div>
      </button>
    </div>
    `}onCardClick(){pi(this,"select-card",this.data)}};_o([oi({type:Object}),Co("design:type",Object)],$o.prototype,"data",void 0),_o([oi(),Co("design:type",String)],$o.prototype,"imageContainmentStyle",void 0),$o=_o([ii("search-view-top-item")],$o);var Po=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r};let Io=class extends ei{static get styles(){return hi}render(){return Lt`
    <style>
      :host {
        display: block;
        width: var(--slick-discovery-cell-width, 262px);
        margin: 12px 0;
      }
      .hidden {
        display: none !important;
      }
      #card {
        background: white;
        font-size: 13px;
        padding: 0 12px;;
        position: relative;
      }
      #imagePanel {
        min-height: 60px;
        background-size: cover;
        background-origin: border-box;
        background-repeat: no-repeat;
        background-position: 50% 50%;
        border: none;
        text-decoration: none;
        color: inherit;
        position: relative;
        outline: none;
        width: 100%;
        box-sizing: border-box;
        margin: 0;
        border-radius: var(--slick-search-image-radius, 5px);
        overflow: hidden;
      }
      #overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        text-align: center;
        font-size: 15px;
        text-transform: uppercase;
        letter-spacing: 1px;
        box-sizing: border-box;
        padding: 6px 12px;
        cursor: pointer;
        overflow: hidden;
        border-radius: var(--slick-search-image-radius, 5px);
        color: var(--slick-discovery-highlight-color, #2196f3);
      }
      #overlay::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        background: var(--slick-discovery-highlight-color, #2196f3);
        opacity: 0;
      }
      #name {
        position: relative;
      }

      @media(hover:hover) {
        #overlay::before {
          transition: opacity 0.3s ease;
        }
        #overlay:hover::before {
          opacity: 0.15;
        }
      }
    </style>
    <div id="card" class="vertical layout">
      <div id="imagePanel" @click="${this.onCardClick}">
        <div id="overlay" class="horizontal layout center">
          <div id="name" class="flex">More...</div>
        </div>
      </div>
    </div>
    `}onCardClick(){pi(this,"more")}};Io=Po([ii("search-view-more-button")],Io);var To=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Oo=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Ro=class extends Ts{constructor(){super(...arguments),this.deleteMessage=""}render(){return Lt`
    <style>
      :host {
        --soso-highlight-color: var(--slick-discovery-highlight-color);
        font-size: 15px;
      }
      soso-button {
        color: var(--slick-discovery-highlight-color);
      }
      label {
        margin: 7px 0 0 8px;
      }
    </style>
    <soso-dialog-view .label="${Ze.phrase("sign-out")}">
      <div slot="main">
        <div class="horizontal layout">
          <soso-checkbox id="chkDelete"></soso-checkbox>
          <label>${this.deleteMessage||"Delete my account and all associated information permanently.  (This cannot be undone.)"}</label>
        </div>
      </div>
      <soso-button slot="footer" @click="${this.hide}">Cancel</soso-button>
      <soso-button slot="footer" @click="${this.submit}">${Ze.phrase("sign-out")}</soso-button>
    </soso-dialog-view>
    
    `}firstUpdated(){this.resetState()}async beforeShow(){this.resetState()}resetState(){this.chkDelete&&(this.chkDelete.checked=!1)}async submit(){var e;const t=null===(e=this.chkDelete)||void 0===e?void 0:e.checked;try{await Ze.memberSignoutWithDelete(!!t),this.hide(),pi(this,"update")}catch(e){console.error(e),window.alert(e.message||e)}}};To([oi(),Oo("design:type",Object)],Ro.prototype,"deleteMessage",void 0),To([ai("#chkDelete"),Oo("design:type",Ls)],Ro.prototype,"chkDelete",void 0),Ro=To([ii("slick-delete-member-dialog")],Ro);var Eo=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},jo=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Lo=class extends ei{static get styles(){return hi}render(){var e;const t=this.user&&(this.user.name||this.user.email)||"",i=!("mandatory-membership"!==(null===(e=Ze.currentSession)||void 0===e?void 0:e.settings.membership.behavior)),s=!!this.user;return Lt`
    <style>
      :host {
        display: block;
        --soso-highlight-color: var(--slick-discovery-highlight-color, #2196f3);
      }
      .hidden {
        display: none !important;
      }
      soso-icon-button,
      soso-button {
        color: var(--soso-highlight-color);
      }
      #userPanel {
        padding: 2px 6px;
        font-size: 14px;
        color: #808080;
        background: #fafafa;
        min-height: 32px;
      }
      #userName {
        margin-right: 8px;
      }
      #mandatoryPanel {
        max-width: 500px;
        margin: 32px auto;
        padding: 016px;
        background: #fafafa;
        box-shadow: 0 3px 1px -2px rgba(0,0,0,.2), 0 2px 2px 0 rgba(0,0,0,.14), 0 1px 5px 0 rgba(0,0,0,.12);
        font-size: 15px;
      }
      #nonMandatoryPanel {
        padding: 8px;
        font-size: 14px;
        color: #808080;
        background: #fafafa;
      }
    </style>
    <div id="userPanel" class="horizontal layout center ${t?"":"hidden"}">
      <div class="flex"></div>
      <div id="userName">${t}</div>
      <soso-button class="${s?"":"hidden"}" @click="${this.signOut}">${Ze.phrase("sign-out")}</soso-button>
    </div>
    <div id="mandatoryPanel" class="${i&&!t?"":"hidden"}">
      <p>${this.membershipSettings&&this.membershipSettings.memberSignupMessage||this.getDefaultSignupMessage()}</p>
      <p style="margin-top: 32px;">
        <soso-button solid @click="${this.showDialog}">${Ze.phrase("favorites-panel-sign-in-button")}</soso-button>
      </p>
    </div>
    <div id="nonMandatoryPanel" class="${i||t?"hidden":"horizontal layout center"}">
      <div class="flex"></div>
      <span>${this.membershipSettings&&this.membershipSettings.optionaMembershipCta||Ze.phrase("favorites-panel-optional-cta")}</span>
      <soso-button style="margin-left: 8px;" @click="${this.showDialog}">${Ze.phrase("favorites-panel-sign-in-button")}</soso-button>
      <div class="flex"></div>
    </div>
    </div>
    `}getDefaultSignupMessage(){var e;return"mandatory-membership"===(null===(e=Ze.currentSession)||void 0===e?void 0:e.settings.membership.behavior)?Ze.phrase("default-mandatory-favorites-cta"):Ze.phrase("default-optional-favorites-cta")}firstUpdated(){e.subscribe("session-updated",(()=>{this.refreshState()})),e.subscribe("membership-updated",(()=>{this.refreshState()})),this.refreshState()}refreshState(){this.session=Ze.currentSession,this.session?this.user=this.session.identity:this.user=void 0}sync(){pi(this,"sync")}async signOut(){var e;this.deleteMemberDialog||(this.deleteMemberDialog=new Ro,this.deleteMemberDialog.addEventListener("update",(()=>{this.refreshState(),this.sync()}))),this.deleteMemberDialog.deleteMessage=(null===(e=this.membershipSettings)||void 0===e?void 0:e.deleteAccountMessage)||"",this.deleteMemberDialog.show()}showDialog(){const e=this.membershipSettings;(null==e?void 0:e.redirectSignInToUrl)?window.location.assign(e.redirectSignInToUrl):(this.membershioDialog||(this.membershioDialog=new to,this.membershioDialog.addEventListener("update",(()=>{this.refreshState(),this.sync()}))),this.membershioDialog.membershipSettings=this.membershipSettings,this.membershioDialog.pageToHeart=void 0,this.membershioDialog.show(),Ze.widgetAction("discovery","open-membership-dialog",0,void 0,"my-favorites"))}};Eo([oi({type:Object}),jo("design:type",Object)],Lo.prototype,"membershipSettings",void 0),Eo([ni(),jo("design:type",Object)],Lo.prototype,"session",void 0),Eo([ni(),jo("design:type",Object)],Lo.prototype,"user",void 0),Lo=Eo([ii("slick-membership-panel")],Lo);var zo=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r};let Mo=class extends ei{constructor(){super(...arguments),this.intersecting=!1,this.intersectionHandler=e=>{const t=e[0];t&&this.intersecting!==t.isIntersecting&&(this.intersecting=t.isIntersecting,pi(this,this.intersecting?"visible":"hidden"))}}render(){return Lt`
    <style>
      :host {
        display: block;
      }
    </style>
    `}firstUpdated(){if("IntersectionObserver"in window){const e={threshold:1};new IntersectionObserver(this.intersectionHandler,e).observe(this)}}get visible(){return this.intersecting}};Mo=zo([ii("slick-on-visible")],Mo);var Ao=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r};let Do=class extends ei{static get styles(){return hi}render(){return Lt`
    <style>
      :host {
        display: inline-block;
        font-size: 10px;
      }
      a {
        text-decoration: none;
        outline: none;
        color: inherit;
      }
      .name {
        letter-spacing: 1px;
        font-family: Raleway, system-ui, sans-serif;
        font-weight: 400;
        padding-left: 8px;
        line-height: 1.5;
      }
    </style>
    <a class="horizontal layout center" href="https://www.slickstream.com/discover-slickstream" target="_blank" rel="noopener">
      <div class="name">Powered by Slickstream</div>
    </a>
    `}};Do=Ao([ii("powered-by")],Do);var Ho=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Fo=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Bo=class extends ei{static get styles(){return hi}render(){if(!this.data)return Lt``;let e=!1,t=this.data.iconUrlLightBg;return this.data.selected&&(this.data.iconUrlDarkBg?t=this.data.iconUrlDarkBg:e=!0),Lt`
    <style>
    :host {
      display: inline-block;
      font-size: 13px;
      text-transform: uppercase;
      vertical-align: middle;
    }
    button {
      cursor: pointer;
      outline: none;
      overflow: hidden;
      color: inherit;
      user-select: none;
      position: relative;
      font-family: inherit;
      text-align: center;
      font-size: inherit;
      text-transform: inherit;
      width: 100%;
      box-sizing: border-box;
      background: rgba(0,0,0,0.05);
      border: 1px solid transparent;
      padding: 1px 10px;
      min-height: 40px;
      border-radius: 3em;
      letter-spacing: 0.5px;
      white-space: nowrap;
    }
    span {
      line-height: 1;
    }
    img {
      height: 24px;
      width: auto;
      display: block;
      margin: 0 8px 0 6px;
    }
    span.iconSpan {
      display: none;
    }
    soso-icon {
      padding: 5px 0 5px 5px;
      color: inherit;
      cursor: pointer;
    }

    button.selected {
      letter-spacing: 0;
      border-radius: 0;
      font-size: 13px;
      padding: 1px 6px;
      background: var(--slick-discovery-highlight-color, #2196f3);
      color: var(--slick-discovery-bgcolor, rgba(255,255,255,1));
    }
    button.selected span.iconSpan {
      display: inline-block;
    }
    
    button.selected.circular #imageContainer {
      border-radius: 50%;
      overflow: hidden;
      width: 30px;
      margin-right: 6px;
      margin-left: 0px;
    }
    button.selected.circular img {
      background: white;
      padding: 5px;
      width: 20px;
      height: 20px;
      margin: 0;
    }

    button:focus {
      border-color: var(--slick-discovery-highlight-color, #2196f3);
    }

    </style>
    <button @click="${this.onCheck}" class="${this.data.selected?"selected":""} ${e?"circular":""}">
      <div class="horizontal layout center">
        ${t?Lt`<div id="imageContainer"><img src="${t}"></div>`:Lt``}
        <span>${this.data.name}</span>
        <span class="iconSpan">
          <soso-icon icon="close" @click="${this.onUncheck}"></soso-icon>
        </span>
      </div>
    </button>`}onCheck(e){e.stopPropagation(),pi(this,"select")}onUncheck(e){e.stopPropagation(),pi(this,"unselect")}};Ho([ni(),Fo("design:type",Object)],Bo.prototype,"data",void 0),Bo=Ho([ii("search-chip")],Bo);var Uo=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},No=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Vo=class extends ei{constructor(){super(...arguments),this.data=[],this.scrollPending=!1}render(){return Lt`
    <style>
      :host {
        display: block;
        position: relative;
      }
      #scrollPanel {
        display: block;
        overflow: auto;
        box-sizing: border-box;
        width: 100%;
        -webkit-overflow-scrolling: touch;
        overflow-x: auto;
        overflow-y: hidden;
        -ms-overflow-style: none;
        scrollbar-width: none;
        white-space: nowrap;
      }
      #scrollPanel::-webkit-scrollbar {
        width: 0px;
        height: 0px;
        background: transparent;
      }
      #chevPanel{
        opacity: 0;
        transition: opacity 0.3s ease;
      }
      :host(:hover) #chevPanel {
        opacity: 1;
      }
      #chevL {
        left: 0px;
      }
      #chevR {
        right: 0px;
      }
      #chevL:hover {
        opacity: 1;
      }
      #chevR:hover {
        opacity: 1;
      }
      #chevPanel soso-icon {
        position: absolute;
        top: 0;
        height: 100%;
        background: white;
        color: var(--slick-discovery-highlight-color, #2196f3);
        opacity: 0.9;
        padding: 0 5px;
        cursor: pointer;
      }
      .hidden {
        display: none !important;
      }
      search-chip {
        margin: 0 5px;
        --soso-highlight-color: var(--slick-discovery-highlight-color, #2196f3);
      }

      @media (max-width: 600px) {
        #chevPanel {
          display: none;
        }
      }
    </style>
    <div style="position: relative;">
      <div id="scrollPanel" @scroll="${this.updateScrollPosition}">
      ${xs(this.data,(e=>e.id),(e=>Lt`<search-chip
        .data="${e}"
        @select="${()=>this.selectChip(e)}"
        @unselect="${()=>this.unselectChip(e)}"
        ></search-chip>`))}
      </div>
      <div id="chevPanel">
        <soso-icon id="chevL" icon="chevron-left" class="hidden" @click="${this.scrollPrev}"></soso-icon>
        <soso-icon id="chevR" icon="chevron-right" class="hidden" @click="${this.scrollNext}"></soso-icon>
      </div>
    </div>
    `}updated(){this.scrollPanel&&(this.scrollPanel.scrollLeft=0),this.updateScrollPosition()}selectChip(e){e.selected||pi(this,"select-card",e)}unselectChip(e){e.selected&&pi(this,"unselect-card",e)}scrollListTo(e,t){e.scrollTo?e.scrollTo({top:0,left:t,behavior:"smooth"}):e.scrollLeft=t}scrollNext(){if(this.scrollPanel){const e=this.scrollPanel.getBoundingClientRect().width;this.scrollListTo(this.scrollPanel,this.scrollPanel.scrollLeft+e-80)}}scrollPrev(){if(this.scrollPanel){const e=this.scrollPanel.getBoundingClientRect().width;this.scrollListTo(this.scrollPanel,Math.max(0,this.scrollPanel.scrollLeft-e+80))}}updateScrollPosition(){this.scrollPending||(this.scrollPending=!0,setTimeout((()=>{if(this.scrollPanel){const e=this.scrollPanel.getBoundingClientRect().width,t=this.scrollPanel.scrollLeft;t+e>=this.scrollPanel.scrollWidth?this.chevR.classList.add("hidden"):this.chevR.classList.remove("hidden"),t>0?this.chevL.classList.remove("hidden"):this.chevL.classList.add("hidden"),this.scrollPending=!1}}),300))}};Uo([ni(),No("design:type",Array)],Vo.prototype,"data",void 0),Uo([ai("#scrollPanel"),No("design:type",HTMLDivElement)],Vo.prototype,"scrollPanel",void 0),Uo([ai("#chevL"),No("design:type",Fi)],Vo.prototype,"chevL",void 0),Uo([ai("#chevR"),No("design:type",Fi)],Vo.prototype,"chevR",void 0),Vo=Uo([ii("search-chip-list")],Vo);var qo=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Wo=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const Go="discovery";let Ko=class extends ei{constructor(){super(...arguments),this.showing=!1,this.searchIcon="search",this.morePagesList=[],this.headerShowing=!0,this.onlineStatus="Connecting",this.overlayPlaceholderShowing=!1,this.dirtyText=!1,this.moreOnIdleTimer=0,this.prevScrollValue=0,this.isScrollingUp=!1,this.mobileWidth=!1,this.previousActiveElement=null,this.openListener=async e=>{const{page:t="search"}=e.detail||{};switch(this.openPanel(),this.updateSearchResults(null),t){case"search":case"":this.search("start");break;default:this.search("start",("global"===(i=t)?null:i+(s?`:${s}`:""))||void 0)}var i,s},this.keydownListener=e=>{if(this.showing){switch(e.keyCode){case 27:this.closePanel(),e.stopPropagation();break;case 13:this.blur()}e.stopPropagation()}}}static get styles(){return hi}get adSlots(){var e,t;return(null===(t=null===(e=this.settings)||void 0===e?void 0:e.adInjection)||void 0===t?void 0:t.enableAdsInSearch)||!1}get adSlotGap(){const e=window.innerWidth<600;return this.settings&&this.settings.adInjection?e?this.settings.adInjection.searchSlotIntervalMobile:this.settings.adInjection.searchSlotInterval:12}render(){var e,t,i,s,o,n,r,a,l,c,h,d,p,u,g,f,v,m,y,b,w,x,k,S,_,C,$,P,I,T,O,R;let E=(null===(t=null===(e=this.settings)||void 0===e?void 0:e.discovery)||void 0===t?void 0:t.searchBoxPlaceholderText)||Ze.phrase("search-text")||"search text";this.lastSearchInfo&&this.lastSearchInfo.ingredientMode&&(E=Ze.phrase("ingredient-search-placeholder")||"Enter comma-separated ingredients");const j=(null===(i=this.lastSearchInfo)||void 0===i?void 0:i.pages)||[],L=((null===(s=this.lastSearchInfo)||void 0===s?void 0:s.cards)||[]).filter((e=>!this.mobileWidth||"search-match"===e.reason||"other"===e.reason)),z=(null===(o=this.lastSearchInfo)||void 0===o?void 0:o.topLevelCards)||[],M=null===(r=null===(n=this.lastSearchInfo)||void 0===n?void 0:n.context)||void 0===r?void 0:r.name,A=(null===(a=this.settings)||void 0===a?void 0:a.membership.behavior)||"optional-membership",D=!("no-favorites"===A),H=(null===(c=null===(l=this.settings)||void 0===l?void 0:l.heartbeat)||void 0===c?void 0:c.minVisibleCount)||0,F=null===(h=this.settings)||void 0===h?void 0:h.heartbeatIcon,B=(null===(p=null===(d=this.settings)||void 0===d?void 0:d.discovery)||void 0===p?void 0:p.imageContainmentStyle)||"cover",U=[...z.length?z:L];(null===(g=null===(u=this.lastSearchInfo)||void 0===u?void 0:u.context)||void 0===g?void 0:g.id)&&U.unshift({id:this.lastSearchInfo.context.id,name:this.lastSearchInfo.context.name,iconUrlLightBg:this.lastSearchInfo.context.iconUrlLightBg,iconUrlDarkBg:this.lastSearchInfo.context.iconUrlDarkBg,selected:!0});let N=(null===(v=null===(f=this.settings)||void 0===f?void 0:f.discovery)||void 0===v?void 0:v.layout)||"grid";(null===(m=this.lastSearchInfo)||void 0===m?void 0:m.ingredientMode)&&(N="list");const V=Ze.currentSession,q=0===((null===(b=null===(y=this.lastSearchInfo)||void 0===y?void 0:y.context)||void 0===b?void 0:b.id)||"").indexOf("favorites"),W=(null===(x=null===(w=this.settings)||void 0===w?void 0:w.discovery)||void 0===x?void 0:x.noMatchesText)||Ze.phrase("no-matches-found")||"No matches found",G=!(!q||!V||"mandatory-membership"!==A&&"optional-membership"!==A),K="mandatory-membership"===A,Y=!!(V&&V.identity&&V.identity.email);let Z=(null===(S=null===(k=this.settings)||void 0===k?void 0:k.discovery)||void 0===S?void 0:S.noFavoritesMessage)||(K?Ze.phrase("favorites-panel-mandatory-no-favorites"):Ze.phrase("favorites-panel-optional-no-favorites"));0===j.length&&K&&!Y&&(Z="");let Q=q?Z:W;(j.length||z.length||L.length||!this.showing)&&(Q="");let X="";"Connecting"===this.onlineStatus?(X="Connecting...",Q=""):"Offline"===this.onlineStatus&&(X=(null===(C=null===(_=this.settings)||void 0===_?void 0:_.discovery)||void 0===C?void 0:C.offlineMessage)||"Offline. Reconnecting...",Q="");const J=!(!X&&!(null===(P=null===($=this.settings)||void 0===$?void 0:$.discovery)||void 0===P?void 0:P.hideAttribution)),ee="bubbles"===this.getCategoryStyle(),te=(null===(I=this.settings)||void 0===I?void 0:I.showStoryIndicators)||!1;let ie="";if(j.length&&this.lastSearchInfo)if(this.lastSearchInfo.ingredientMode)ie="Following are the matches based on ingredient search. Press Escape to clear results and Escape again to exit the search dialog.";else if(M)ie=`Following are the matches for "${M}".`;else{const e=(null===(T=this.searchInput)||void 0===T?void 0:T.value)||"";ie=e?`Following are the matches for "${e}". Press Escape to clear results and Escape again to exit the search dialog.`:"You are in the search dialog. Following are the list of related pages. Type to search for what you're looking for, or press Escape to close the search dialog."}else this.showing&&(ie=W);return Lt`
    <style>
      :host {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        z-index: var(--slick-discovery-zindex, var(--slick-toolbar-zindex, 200002));
        line-height: var(--slick-discovery-line-height, 1.4);
        display: none;
      }
      .hidden {
        display: none !important;
      }
      #glassPane {
        background: var(--slick-discovery-bgcolor, rgba(255,255,255,1));
        opacity: 0;
        transition: opacity 0.3s ease-in;
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
      }
      main {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        opacity: 0;
        transform: translate3d(0,100px,0);
        transition: opacity 0.3s ease, transform 0.3s ease;
        color: var(--slick-discovery-color, #000);
        overflow: hidden;
        overflow-y: auto;
        -webkit-overflow-scrolling: touch;
      }
      #bottomSpacer {
        height: 200px;
      }
      #topSpacer {
        height: 112px;
        padding-top: var(--slick-discovery-top-padding, 0);
      }
      #topSpacer.bubbles {
        height: 72px;
      }
      #header {
        position: relative;
        width: 100%;
        box-sizing: border-box;
        background: var(--slick-discovery-bgcolor, rgba(255,255,255,1));
        opacity: 0;
        transition: transform 0.3s ease, opacity 0.3s ease;
        padding-top: var(--slick-discovery-top-padding, 0);
        z-index: 2;
      }
      #searchBar {
        padding: 10px 8px 10px;
        position: relative;
      }
      #crumbBar {
        padding: 10px 8px 2px 60px;
        min-height: 28px;
      }
      #crumbPanel.horizontal.layout {
        display: inline-flex;
        background: var(--slick-discovery-highlight-color, #2196f3);
        color: var(--slick-discovery-highlight-inverse, white);
        padding: 0 8px;
        border-radius: 3px;
        line-height: 1;
        font-size: 13px;
        font-family: sans-serif;
        letter-spacing: 1px;
      }
      #crumbPanel soso-icon-button {
        --soso-icon-button-padding: 2px;
        color: white;
        margin-left: 8px;
      }
      soso-icon-button {
        color: var(--slick-discovery-highlight-color, #2196f3);
        --soso-icon-button-padding: 8px;
      }
      #close-button {
        border: 2px solid;
        border-radius: 50%;
        --soso-icon-button-padding: 6px;
      }
      input {
        width: 100%;
        box-sizing: border-box;
        outline: none;
        border: none;
        font-size: 16px;
        color: inherit;
        background: none;
        border-bottom: 2px solid;
        font-family: system-ui, sans-serif;
        padding: 4px 2px;
        font-weight: 300;
        letter-spacing: 0.04em;
        border-radius: 0;
        border-color: rgba(0,0,0,0.1);
        direction: var(--slick-labels-direction, ltr);
      }
      input[type="search"]::-webkit-search-decoration,
      input[type="search"]::-webkit-search-cancel-button,
      input[type="search"]::-webkit-search-results-button,
      input[type="search"]::-webkit-search-results-decoration {
        -webkit-appearance:none;
      }
      input::placeholder {
        color: inherit;
        opacity: 0.65;
        font-size: 14px;
      }
      input::-moz-placeholder {
        color: inherit;
        opacity: 0.65;
        font-size: 14px;
      }
      input:focus {
        border-color: var(--slick-discovery-highlight-color, #2196f3);
      }
      section {
        max-width: 1066px;
        box-sizing: border-box;
        margin: 0 auto;
        padding: 16px 8px 0;
      }
      .list-layout section {
        max-width: 810px;
      }
      label {
        width: 100%;
        padding: 12px;
        border-left: none;
        border-right: none;
        font-size: 14px;
        color: #808080;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        display: block;
      }
      .contextName {
        text-transform: uppercase;
        max-width: 160px;
        display: inline-block;
        overflow: hidden;
        text-overflow: ellipsis;
        margin-left: 8px;
        letter-spacing: 0.5px;
        white-space: nowrap;
      }
      #nonePanel {
        font-size: 14px;
        color: #333;
        text-align: center;
        padding-top: 40px;
      }
      powered-by {
        color: #555;
      }
      .offlineLabel {
        font-weight: 400;
        font-size: 12px;
        letter-spacing: 0.5px;
        color: var(--slick-discovery-highlight-color);
        font-family: sans-serif;
        padding: 2px 0 0 0;
      }
      #refreshButton {
        width: 1.5em;
        height: 1.5em;
        padding: 0 8px;
        cursor: pointer;
      }

      .showing #glassPane {
        opacity: 1;
      }
      .showing main {
        opacity: 1;
        transform: none;
      }
      .showing #header {
        opacity: 1;
      }

      #overlayPlaceholder {
        position: absolute;
        left: 62px;
        top: 100%;
        right: 0;
        transform: translateY(-12px);
        background: rgba(255,255,255, 0.9);
        font-size: 12px;
        padding: 0px 6px 8px 0;
        color: #808080;
        font-weight: 300;
        pointer-events: none;
        transition: opacity 0.3s ease;
        opacity: 0;
      }
      #overlayPlaceholder.visible {
        opacity: 1;
      }
      .sr-only {
        position:absolute;
        left:-10000px;
        top:auto;
        width:1px;
        height:1px;
        overflow:hidden;
      }

      main ::slotted(.slick-search-ad-slot) {
        box-sizing: border-box;
        margin: 0 auto;
        padding: 10px;
        max-width: 1066px;
      }
      main.list-layout ::slotted(.slick-search-ad-slot) {
        margin: 0 auto;
        max-width: 1066px;
      }
      search-view-article-item:last-child {
        border-bottom: none;
      }

      @media (max-width: 600px) {
        #crumbBar {
          padding: 10px 8px 4px 8px;
        }
        #searchBar {
          padding: 8px;
        }
        section {
          padding: 10px 8px 0;
        }
        label {
          padding: 2px 12px;
        }
      }
      @media (max-width: 420px) {
        .grid-container {
          justify-content: center;
        }
      }
    </style>
    <div class="${this.showing?"showing":""}">
      <div id="glassPane"></div>

      <div id="header" class="${this.headerShowing?"header-showing":""}">
        <div id="crumbBar" class="${ee?"hidden":""}">
          <div id="crumbPanel" class="${M?"horizontal layout center":"hidden"}">
            <span>${Ze.phrase("searching-in")} </span>
            <span class="contextName">${M}</span>
            <soso-icon-button id="clearContextButton" label="Clear context" icon="close" @click="${this.clearContext}"></soso-icon-button>
            <span class="flex"></span>
          </div>
        </div>
        <div id="searchBar" class="horizontal layout center">
          <soso-icon-button id="close-button"  label="Close" icon="back" @click="${this.closePanel}"></soso-icon-button>
          <div style="padding: 0 12px;" class="flex">
            <input id="searchText" 
              aria-label="Enter search text here and the search results will be automatically updated as you type"
              autocomplete="off" 
              spellcheck="false"
              placeholder="${E}"
              @blur="${()=>this.overlayPlaceholderShowing=!1}"
              @focus="${this.onFocus}"
              @input="${this.onTextInput}"
              @keydown="${this.onKeydown}"
              @keyup="${this.onKeyUp}"
              @keypress="${this.onKeyPress}">
          </div>
          <soso-icon-button  label="Clear search" .icon="${this.searchIcon}" @click="${this.onClear}"></soso-icon-button>
          <div id="overlayPlaceholder" class="${this.overlayPlaceholderShowing?"visible":""}">${E}</div>
        </div>
        <div class="horizontal layout center" style="padding: 0 60px 9px; margin-top: -12px;">
          <div class="flex horizontal layout center offlineLabel ${X?"":"hidden"}">
            <span>${X}</span>
            <soso-icon class="${"Offline"===this.onlineStatus?"":"hidden"}" icon="refresh" id="refreshButton" @click="${()=>window.location.reload()}"></soso-icon>
          </div>
          <span class="flex"></span>
          <powered-by class="${J?"hidden":""}"></powered-by>
        </div>
      </div>

      <main 
        class="${N}-layout"
        @scroll="${this.handleScroll}"
        @select-card="${this.onSelectCard}"
        @unselect-card="${this.clearContext}"
        @nav="${this.onNav}"
        @signin-and-fav="${this.signInAndFav}">

        <div id="topSpacer" class="${ee?"bubbles":""}"></div>

        <section class="${ee&&U.length?"":"hidden"}" style="padding: 0px 8px 14px; max-width: 100%;">
          <search-chip-list .data="${U}"></search-chip-list>
        </section>

        <slick-membership-panel 
          .membershipSettings="${null===(O=this.settings)||void 0===O?void 0:O.membership}" 
          class="${G?"":"hidden"}" 
          @sync="${this.refreshToFavs}">
        </slick-membership-panel>

        <section id="nonePanel" class="${Q?"":"hidden"}">${Q}</section>

        <div class="${ee?"hidden":""}">
          <section class="${z.length?"":"hidden"}">
            <div class="horizontal layout wrap">
              ${xs(z,(e=>e.id),(e=>Lt`
                <search-view-top-item .data="${e}"></search-view-top-item>
              `))}
            </div>
          </section>

          <section class="${L.length?"":"hidden"}">
            <label>${Ze.phrase("categories")}</label>
            <div class="horizontal layout wrap">
              ${xs(L,(e=>e.id),(e=>Lt`
                <search-view-category-item .data="${e}"></search-view-category-item>
              `))}
              <search-view-more-button class="${(null===(R=this.lastSearchInfo)||void 0===R?void 0:R.isMoreCards)?"":"hidden"}" @more="${this.searchMoreCards}"></search-view-more-button>
            </div>
          </section>
        </div>
        
        <p class="sr-only" aria-live="polite">${ie}</p>
        
        <section class="${j.length?"":"hidden"}">
          <label>${Ze.phrase("top-results")}</label>

          ${"list"===N?Lt`
          <div class="vertical layout">
            ${xs(j,(e=>e.id),(e=>Lt`
              <search-view-page-list-item
                .data="${e}"
                .favSettings="${F}"
                .favs="${D}"
                .showStoryIndicators="${te}"
                .minFavVisibleCount="${H}"
                .imageContainmentStyle="${B}">
              </search-view-page-list-item>
            `))}
          </div>
          `:""}

          ${"grid"===N?Lt`
          <div class="horizontal layout wrap grid-container">
            ${xs(j,(e=>e.id),(e=>Lt`
              <search-view-page-item
                .data="${e}"
                .favSettings="${F}"
                .favs="${D}"
                .showStoryIndicators="${te}"
                .minFavVisibleCount="${H}"
                .imageContainmentStyle="${B}">
              </search-view-page-item>
            `))}
          </div>
          `:""}

          ${"article"===N?Lt`
          <div>
            ${xs(j,(e=>e.id),(e=>Lt`
              <search-view-article-item
                .data="${e}"
                .favSettings="${F}"
                .favs="${D}"
                .showStoryIndicators="${te}"
                .minFavVisibleCount="${H}">
              </search-view-article-item>
            `))}
          </div>
          `:""}

        </section>

        ${this.adSlots&&j.length?Lt`<slot name="search-slot-1"></slot>`:""}

        ${this.morePagesList.map(((e,t)=>Lt`
        <section class="${e.length?"":"hidden"}" style="${0===t?"border-top: 1px solid #e5e5e5; margin-top: 24px;":""}">
          ${0===t?Lt`<label>${Ze.phrase("more-results")}</label>`:""}

          ${"list"===N?Lt`
          <div class="vertical layout">
            ${xs(e,(e=>e.id),(e=>Lt`
              <search-view-page-list-item
                .data="${e}"
                .favSettings="${F}"
                .favs="${D}"
                .showStoryIndicators="${te}"
                .minFavVisibleCount="${H}"
                .imageContainmentStyle="${B}">
              </search-view-page-list-item>
            `))}
          </div>
          `:""}

          ${"grid"===N?Lt`
          <div class="horizontal layout wrap grid-container">
            ${xs(e,(e=>e.id),(e=>Lt`
              <search-view-page-item
                .data="${e}"
                .favSettings="${F}"
                .favs="${D}"
                .showStoryIndicators="${te}"
                .minFavVisibleCount="${H}"
                .imageContainmentStyle="${B}">
              </search-view-page-item>
            `))}
          </div>
          `:""}

          ${"article"===N?Lt`
          <div>
            ${xs(e,(e=>e.id),(e=>Lt`
              <search-view-article-item
                .data="${e}"
                .favSettings="${F}"
                .favs="${D}"
                .showStoryIndicators="${te}"
                .minFavVisibleCount="${H}">
              </search-view-article-item>
            `))}
          </div>
          `:""}
          
        </section>
        ${this.adSlots?Lt`<slot name="search-slot-${t+2}"></slot>`:""}
        `))}

        <slick-on-visible @visible="${this.visibleChanged}"></slick-on-visible>

        <div id="bottomSpacer"></div>
      </main>
      
      
    </div>
    `}getCategoryStyle(){var e,t;const i=(null===(t=null===(e=this.settings)||void 0===e?void 0:e.discovery)||void 0===t?void 0:t.buttonStyle)||"auto";return"auto"===i?window.innerWidth<=600?"bubbles":"buttons":i}firstUpdated(){this.mobileWidth=window.innerWidth<600;const t=()=>{var e;if(Ze.currentSession){if(this.onlineStatus="online"===Ze.sessionConnectionState?"Online":"Offline","Online"===this.onlineStatus&&this.showing){(null===(e=this.searchInput)||void 0===e?void 0:e.value)?this.onTextInput():this.search("start")}}else this.onlineStatus="Connecting"};e.subscribe("session-offline",t),e.subscribe("session-updated",t),document.addEventListener("slick-show-search",this.openListener),document.addEventListener("slick-show-discovery",this.openListener),t(),this.setAttribute("role","dialog"),this.setAttribute("aria-label","Search panel")}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("slick-show-search",this.openListener),document.removeEventListener("slick-show-discovery",this.openListener),this.removeKeyListener()}removeKeyListener(){document.removeEventListener("keydown",this.keydownListener)}addKeyListner(){this.removeKeyListener(),document.addEventListener("keydown",this.keydownListener)}openPanel(){this.style.display="block",document.body.style.overflow="hidden",document.documentElement.style.overflow="hidden",this.previousActiveElement=document.activeElement,setTimeout((()=>{this.showing=!0;(document.body||document.querySelector("body")).classList.add("slick-discovery-showing"),Ze.widgetAction(Go,"impression",0),this.clearSearchText(!0),this.addKeyListner()}),16),e.dispatch("disocvery-open")}closePanel(){this.showing=!1;(document.body||document.querySelector("body")).classList.remove("slick-discovery-showing"),Ze.widgetAction(Go,"clear",0),this.removeKeyListener(),e.dispatch("disocvery-close"),setTimeout((()=>{this.showing||(this.style.display="",setTimeout((()=>{this.showing||(document.body.style.overflow="",document.documentElement.style.overflow="")})))}),310),this.updateSearchResults(null),this.clearSearchText(!1),this.stopMoreOnIdleTimer(),this.focusPrevActiveElement()||this.blur()}onClear(){var e;(null===(e=this.searchInput)||void 0===e?void 0:e.value)&&(this.clearSearchText(!0),this.onTextInput())}setInputValueWithoutChangeEvent(e){this.searchInput&&(this.searchInput.value=e.trim(),this.searchIcon=this.searchInput.value?"close":"search")}clearSearchText(e){this.setInputValueWithoutChangeEvent(""),this.dirtyText=!1,e&&this.focus()}focus(){if(this.searchInput){const e=this.searchInput;e.focus(),setTimeout((()=>{e.focus()}))}}focusPrevActiveElement(){return!!this.previousActiveElement&&(this.previousActiveElement.focus(),!0)}blur(){if(this.searchInput){const e=this.searchInput;e.blur(),setTimeout((()=>{e.blur()})),this.overlayPlaceholderShowing=!1}}onTextInput(){var e;const t=null===(e=this.searchInput)||void 0===e?void 0:e.value;this.searchIcon=t?"close":"search",this.searchText(),this.overlayPlaceholderShowing=!(!t||!t.trim())}onFocus(){var e;const t=null===(e=this.searchInput)||void 0===e?void 0:e.value;this.overlayPlaceholderShowing=!(!t||!t.trim())}onKeyUp(e){e.stopPropagation()}onKeyPress(e){e.stopPropagation()}onKeydown(e){if(this.showing){switch(e.keyCode){case 27:setTimeout((()=>{if(this.searchInput){if(this.searchInput.value)return void this.onClear()}this.closePanel()})),e.preventDefault();break;case 13:this.blur()}e.stopPropagation()}}refreshToFavs(){this.dirtyText=!1,this.stopMoreOnIdleTimer(),this.search("sign-in-change")}async searchText(){if("Online"===this.onlineStatus)if(this.stopMoreOnIdleTimer(),this.pendingSearchPromise)this.dirtyText=!0;else try{this.pendingSearchPromise=this.search("search-string-change"),await this.pendingSearchPromise,await this.updateComplete,this.pendingSearchPromise=void 0,this.dirtyText?(this.dirtyText=!1,this.searchText()):this.startMoreOnIdleTimer()}finally{this.dirtyText=!1,this.pendingSearchPromise=void 0}else this.pendingSearchPromise=void 0}updateSearchResults(e){this.lastSearchInfo=e||void 0,this.morePagesList=[],e&&(this.searchInput&&"string"==typeof e.searchString&&this.setInputValueWithoutChangeEvent(e.searchString),this.focus())}async search(e,t){var i,s,o;if(this.stopMoreOnIdleTimer(),"Online"!==this.onlineStatus)return;const n=(null===(i=this.searchInput)||void 0===i?void 0:i.value)||"",r=await Ze.search(n,e,t||(null===(o=null===(s=this.lastSearchInfo)||void 0===s?void 0:s.context)||void 0===o?void 0:o.id));this.updateSearchResults(r)}async searchSelectCard(e){var t,i,s;if(this.stopMoreOnIdleTimer(),"Online"!==this.onlineStatus)return;const o=(null===(t=this.searchInput)||void 0===t?void 0:t.value)||"",n=await Ze.searchSelectCard(o,e,null===(s=null===(i=this.lastSearchInfo)||void 0===i?void 0:i.context)||void 0===s?void 0:s.id);this.updateSearchResults(n)}async searchMorePages(e){if(this.stopMoreOnIdleTimer(),"Online"===this.onlineStatus&&this.lastSearchInfo&&this.lastSearchInfo.isMorePages){const t=this.lastSearchInfo,i=await Ze.searchMorePages(this.lastSearchInfo.moreContext,e);if(this.lastSearchInfo&&this.lastSearchInfo===t){if(this.lastSearchInfo.isMorePages=i.isMorePages,this.lastSearchInfo.moreContext=i.moreContext,this.adSlots&&!this.morePagesList.length){const e=Math.ceil(i.pages.length/this.adSlotGap);for(let t=0;t<e;t++){if(this.morePagesList.length>=3){this.morePagesList.push(i.pages);break}{const e=i.pages.splice(0,this.adSlotGap);e.length&&this.morePagesList.push(e)}}}else this.morePagesList.push(i.pages);this.requestUpdate()}}}async searchMoreCards(){if("Online"===this.onlineStatus&&this.lastSearchInfo&&this.lastSearchInfo.isMoreCards){const e=this.lastSearchInfo,t=await Ze.searchMoreCards(this.lastSearchInfo.moreContext);this.lastSearchInfo&&this.lastSearchInfo===e&&(this.lastSearchInfo.cards.push(...t.cards||[]),this.lastSearchInfo.isMoreCards=t.isMoreCards,t.moreContext&&(this.lastSearchInfo.moreContext=t.moreContext),this.requestUpdate())}}async clearContext(){await this.search("clear-context")}async onSelectCard(e){await this.searchSelectCard(e.detail.id)}onNav(e){var t;const i=e.detail.href;Ze.widgetAction(Go,"nav",0,i,void 0,{query:null===(t=this.lastSearchInfo)||void 0===t?void 0:t.searchString}),Ze.reportGAEvent("search-click","Slickstream search result clicked");try{const e=new URL(i);e.host===window.location.host&&e.pathname===window.location.pathname&&this.closePanel()}catch(e){}}signInAndFav(e){var t,i,s;const o=null===(t=e.detail)||void 0===t?void 0:t.pageId,n=null===(i=this.settings)||void 0===i?void 0:i.membership;(null==n?void 0:n.redirectSignInToUrl)?window.location.assign(n.redirectSignInToUrl):(this.membershipDialog||(this.membershipDialog=new to,this.membershipDialog.addEventListener("update",(()=>{this.search("sign-in-change")}))),this.membershipDialog.membershipSettings=n,this.membershipDialog.pageToHeart=o,this.membershipDialog.show(),Ze.widgetAction(Go,"open-membership-dialog",0,void 0,void 0,{query:null===(s=this.lastSearchInfo)||void 0===s?void 0:s.searchString}))}stopMoreOnIdleTimer(){this.moreOnIdleTimer&&(window.clearTimeout(this.moreOnIdleTimer),this.moreOnIdleTimer=0)}startMoreOnIdleTimer(){this.stopMoreOnIdleTimer(),this.moreOnIdleTimer=window.setTimeout((()=>{this.moreOnIdleTimer=0,this.searchMorePages("type-pause")}),1e3)}visibleChanged(){this.moreOnIdleTimer||this.searchMorePages("user-scroll")}handleScroll(){if(this.mainElement){const e=this.mainElement.scrollTop,t=30,i=e-(this.prevScrollValue||0);i<0&&this.isScrollingUp||i>0&&!this.isScrollingUp?this.prevScrollValue=e:Math.abs(i)>t&&(this.prevScrollValue=e,this.isScrollingUp=i<0);let s=!1;e>112?this.isScrollingUp&&(s=!0):s=!0,this.headerShowing=s,this.overlayPlaceholderShowing=!1}}};function Yo(e){return"ad-slot"===e.style?`ad-slot-${e.title}`:`${e.templateId}-${e.title}-${e.drillContext||""}-${(e.displayFields||[]).sort().join("-")}`}qo([oi({type:Object}),Wo("design:type",Object)],Ko.prototype,"settings",void 0),qo([ni(),Wo("design:type",Object)],Ko.prototype,"showing",void 0),qo([ni(),Wo("design:type",Object)],Ko.prototype,"searchIcon",void 0),qo([ni(),Wo("design:type",Object)],Ko.prototype,"lastSearchInfo",void 0),qo([ni(),Wo("design:type",Array)],Ko.prototype,"morePagesList",void 0),qo([ni(),Wo("design:type",Object)],Ko.prototype,"headerShowing",void 0),qo([ni(),Wo("design:type",String)],Ko.prototype,"onlineStatus",void 0),qo([ni(),Wo("design:type",Object)],Ko.prototype,"overlayPlaceholderShowing",void 0),qo([ai("#searchText"),Wo("design:type",HTMLInputElement)],Ko.prototype,"searchInput",void 0),qo([ai("main"),Wo("design:type",HTMLElement)],Ko.prototype,"mainElement",void 0),Ko=qo([ii("slick-search-view")],Ko);var Zo=Object.prototype.toString,Qo=Array.isArray||function(e){return"[object Array]"===Zo.call(e)};function Xo(e){return"function"==typeof e}function Jo(e){return e.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g,"\\$&")}function en(e,t){return null!=e&&"object"==typeof e&&t in e}var tn=RegExp.prototype.test;var sn=/\S/;function on(e){return!function(e,t){return tn.call(e,t)}(sn,e)}var nn={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;","/":"&#x2F;","`":"&#x60;","=":"&#x3D;"};var rn=/\s*/,an=/\s+/,ln=/\s*=/,cn=/\s*\}/,hn=/#|\^|\/|>|\{|&|=|!/;function dn(e){this.string=e,this.tail=e,this.pos=0}function pn(e,t){this.view=e,this.cache={".":this.view},this.parent=t}function un(){this.templateCache={_cache:{},set:function(e,t){this._cache[e]=t},get:function(e){return this._cache[e]},clear:function(){this._cache={}}}}dn.prototype.eos=function(){return""===this.tail},dn.prototype.scan=function(e){var t=this.tail.match(e);if(!t||0!==t.index)return"";var i=t[0];return this.tail=this.tail.substring(i.length),this.pos+=i.length,i},dn.prototype.scanUntil=function(e){var t,i=this.tail.search(e);switch(i){case-1:t=this.tail,this.tail="";break;case 0:t="";break;default:t=this.tail.substring(0,i),this.tail=this.tail.substring(i)}return this.pos+=t.length,t},pn.prototype.push=function(e){return new pn(e,this)},pn.prototype.lookup=function(e){var t,i,s,o=this.cache;if(o.hasOwnProperty(e))t=o[e];else{for(var n,r,a,l=this,c=!1;l;){if(e.indexOf(".")>0)for(n=l.view,r=e.split("."),a=0;null!=n&&a<r.length;)a===r.length-1&&(c=en(n,r[a])||(i=n,s=r[a],null!=i&&"object"!=typeof i&&i.hasOwnProperty&&i.hasOwnProperty(s))),n=n[r[a++]];else n=l.view[e],c=en(l.view,e);if(c){t=n;break}l=l.parent}o[e]=t}return Xo(t)&&(t=t.call(this.view)),t},un.prototype.clearCache=function(){void 0!==this.templateCache&&this.templateCache.clear()},un.prototype.parse=function(e,t){var i=this.templateCache,s=e+":"+(t||gn.tags).join(":"),o=void 0!==i,n=o?i.get(s):void 0;return null==n&&(n=function(e,t){if(!e)return[];var i,s,o,n=!1,r=[],a=[],l=[],c=!1,h=!1,d="",p=0;function u(){if(c&&!h)for(;l.length;)delete a[l.pop()];else l=[];c=!1,h=!1}function g(e){if("string"==typeof e&&(e=e.split(an,2)),!Qo(e)||2!==e.length)throw new Error("Invalid tags: "+e);i=new RegExp(Jo(e[0])+"\\s*"),s=new RegExp("\\s*"+Jo(e[1])),o=new RegExp("\\s*"+Jo("}"+e[1]))}g(t||gn.tags);for(var f,v,m,y,b,w,x=new dn(e);!x.eos();){if(f=x.pos,m=x.scanUntil(i))for(var k=0,S=m.length;k<S;++k)on(y=m.charAt(k))?(l.push(a.length),d+=y):(h=!0,n=!0,d+=" "),a.push(["text",y,f,f+1]),f+=1,"\n"===y&&(u(),d="",p=0,n=!1);if(!x.scan(i))break;if(c=!0,v=x.scan(hn)||"name",x.scan(rn),"="===v?(m=x.scanUntil(ln),x.scan(ln),x.scanUntil(s)):"{"===v?(m=x.scanUntil(o),x.scan(cn),x.scanUntil(s),v="&"):m=x.scanUntil(s),!x.scan(s))throw new Error("Unclosed tag at "+x.pos);if(b=">"==v?[v,m,f,x.pos,d,p,n]:[v,m,f,x.pos],p++,a.push(b),"#"===v||"^"===v)r.push(b);else if("/"===v){if(!(w=r.pop()))throw new Error('Unopened section "'+m+'" at '+f);if(w[1]!==m)throw new Error('Unclosed section "'+w[1]+'" at '+f)}else"name"===v||"{"===v||"&"===v?h=!0:"="===v&&g(m)}if(u(),w=r.pop())throw new Error('Unclosed section "'+w[1]+'" at '+x.pos);return function(e){for(var t,i=[],s=i,o=[],n=0,r=e.length;n<r;++n)switch((t=e[n])[0]){case"#":case"^":s.push(t),o.push(t),s=t[4]=[];break;case"/":o.pop()[5]=t[2],s=o.length>0?o[o.length-1][4]:i;break;default:s.push(t)}return i}(function(e){for(var t,i,s=[],o=0,n=e.length;o<n;++o)(t=e[o])&&("text"===t[0]&&i&&"text"===i[0]?(i[1]+=t[1],i[3]=t[3]):(s.push(t),i=t));return s}(a))}(e,t),o&&i.set(s,n)),n},un.prototype.render=function(e,t,i,s){var o=this.getConfigTags(s),n=this.parse(e,o),r=t instanceof pn?t:new pn(t,void 0);return this.renderTokens(n,r,i,e,s)},un.prototype.renderTokens=function(e,t,i,s,o){for(var n,r,a,l="",c=0,h=e.length;c<h;++c)a=void 0,"#"===(r=(n=e[c])[0])?a=this.renderSection(n,t,i,s,o):"^"===r?a=this.renderInverted(n,t,i,s,o):">"===r?a=this.renderPartial(n,t,i,o):"&"===r?a=this.unescapedValue(n,t):"name"===r?a=this.escapedValue(n,t,o):"text"===r&&(a=this.rawValue(n)),void 0!==a&&(l+=a);return l},un.prototype.renderSection=function(e,t,i,s,o){var n=this,r="",a=t.lookup(e[1]);if(a){if(Qo(a))for(var l=0,c=a.length;l<c;++l)r+=this.renderTokens(e[4],t.push(a[l]),i,s,o);else if("object"==typeof a||"string"==typeof a||"number"==typeof a)r+=this.renderTokens(e[4],t.push(a),i,s,o);else if(Xo(a)){if("string"!=typeof s)throw new Error("Cannot use higher-order sections without the original template");null!=(a=a.call(t.view,s.slice(e[3],e[5]),(function(e){return n.render(e,t,i,o)})))&&(r+=a)}else r+=this.renderTokens(e[4],t,i,s,o);return r}},un.prototype.renderInverted=function(e,t,i,s,o){var n=t.lookup(e[1]);if(!n||Qo(n)&&0===n.length)return this.renderTokens(e[4],t,i,s,o)},un.prototype.indentPartial=function(e,t,i){for(var s=t.replace(/[^ \t]/g,""),o=e.split("\n"),n=0;n<o.length;n++)o[n].length&&(n>0||!i)&&(o[n]=s+o[n]);return o.join("\n")},un.prototype.renderPartial=function(e,t,i,s){if(i){var o=this.getConfigTags(s),n=Xo(i)?i(e[1]):i[e[1]];if(null!=n){var r=e[6],a=e[5],l=e[4],c=n;0==a&&l&&(c=this.indentPartial(n,l,r));var h=this.parse(c,o);return this.renderTokens(h,t,i,c,s)}}},un.prototype.unescapedValue=function(e,t){var i=t.lookup(e[1]);if(null!=i)return i},un.prototype.escapedValue=function(e,t,i){var s=this.getConfigEscape(i)||gn.escape,o=t.lookup(e[1]);if(null!=o)return"number"==typeof o&&s===gn.escape?String(o):s(o)},un.prototype.rawValue=function(e){return e[1]},un.prototype.getConfigTags=function(e){return Qo(e)?e:e&&"object"==typeof e?e.tags:void 0},un.prototype.getConfigEscape=function(e){return e&&"object"==typeof e&&!Qo(e)?e.escape:void 0};var gn={name:"mustache.js",version:"4.1.0",tags:["{{","}}"],clearCache:void 0,escape:void 0,parse:void 0,render:void 0,Scanner:void 0,Context:void 0,Writer:void 0,set templateCache(e){fn.templateCache=e},get templateCache(){return fn.templateCache}},fn=new un;gn.clearCache=function(){return fn.clearCache()},gn.parse=function(e,t){return fn.parse(e,t)},gn.render=function(e,t,i,s){if("string"!=typeof e)throw new TypeError('Invalid template! Template should be a "string" but "'+((Qo(o=e)?"array":typeof o)+'" was given as the first argument for mustache#render(template, view, partials)'));var o;return fn.render(e,t,i,s)},gn.escape=function(e){return String(e).replace(/[&<>"'`=\/]/g,(function(e){return nn[e]}))},gn.Scanner=dn,gn.Context=pn,gn.Writer=un;var vn=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},mn=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let yn=class extends Ts{constructor(){super(...arguments),this._data=[]}render(){return Lt`
    <style>
      :host {
        --soso-highlight-color: var(--slick-discovery-highlight-color);
        font-size: 14px;
      }
      soso-button {
        color: var(--slick-discovery-highlight-color);
      }
      #messagePanel {
        font-family: sans-serif;
        line-height: 18px;
      }
      span {
        white-space: pre-wrap;
        font-family: monospace;
        overflow-wrap: break-word;
      }
    </style>
    <soso-dialog-view label="Page Info">
      <div id="messagePanel" slot="main">
        ${this._data.map((e=>Lt`
        <div style="margin-bottom: 8px;">
          <strong>${e.key}:</strong> <span>${e.value}</span>
        </div>
        `))}
      </div>
      <soso-button slot="footer" @click="${this.onCancel}">Close</soso-button>
    </soso-dialog-view>
    `}firstUpdated(){this.resetState()}async beforeShow(){this.resetState()}resetState(){if(this._data=[],this.page)for(const e in this.page){const t=this.page[e];"object"==typeof t?this._data.push({key:e,value:JSON.stringify(t,null,2)}):this._data.push({key:e,value:`${t}`})}}onCancel(){this.hide()}};vn([ni(),mn("design:type",Array)],yn.prototype,"_data",void 0),yn=vn([ii("slick-page-preview-dialog")],yn);const bn=new Map;var wn=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},xn=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let kn=class extends Ds{constructor(){super(...arguments),this.rightalign=!1,this.hidecount=!1}render(){var e,t,i,s,o;if(!this.page)return Lt``;const n=(null===(e=Ze.currentSession)||void 0===e?void 0:e.settings)||Ze.cachedSettings,r=(null===(t=null==n?void 0:n.heartbeatIcon)||void 0===t?void 0:t.iconType)||"heart",a=(null===(i=null==n?void 0:n.heartbeat)||void 0===i?void 0:i.minVisibleCount)||0;return Lt`
    <style>
      :host {
        display: block;
        position: relative;
      }
      #favCount {
        color: var(--slick-discovery-highlight-color, #2196f3);
        font-size: 13px;
        font-family: sans-serif;
        line-height: 1;
        pointer-events: none;
        white-space: nowrap;
      }
    </style>
    <div class="horizontal center">
      <slick-toggle-button
        .active="${this.page.isFavorite||!1}" 
        .icon="${r}-outline"
        .activeIcon="${r}"
        .customSvg="${"custom"===r?null===(s=null==n?void 0:n.heartbeatIcon)||void 0===s?void 0:s.customSvgOutline:void 0}"
        .customSvgActive="${"custom"===r?null===(o=null==n?void 0:n.heartbeatIcon)||void 0===o?void 0:o.customSvgFilled:void 0}"
        label="${this.page.isFavorite?"Favorite":"Add to favorites"}"
        @click="${this.onToggleClick}">
      </slick-toggle-button>
      ${this.hidecount?Lt``:Lt`<div id="favCount">${this.countString(this.page.totalFavorites,a)}</div>`}
      <span class="flex"></span>
    </div>
    `}connectedCallback(){let e=this.parentElement;for(;e;){if(e.slickPageDescriptor){this.page=e.slickPageDescriptor;break}e=e.parentElement}super.connectedCallback()}firstUpdated(){this.addEventListener("click",(e=>{e.stopPropagation(),e.preventDefault()}))}countString(e,t){return e<=0||e<=t?"":e>=1e6?`${(e/1e6).toFixed(1)}M`:e>=1e4?`${(e/1e3).toFixed(1)}k`:e.toLocaleString()}async onToggleClick(e){e.stopPropagation(),e.preventDefault(),this.toggleFav()}toggleFav(){var e;if(this.page){if(this.page.isFavorite)Ze.removeFavorite(this.page.id),this.page.totalFavorites--,Ze.toast({message:Ze.phrase("favorite-removed"),action:Ze.phrase("undo"),actionHandler:()=>{this.page&&(this.page.isFavorite||this.toggleFav())}});else{if(Ze.shouldSigninToFav())return void pi(this,"signin-and-fav",{pageId:this.page.id});const t=(null===(e=Ze.currentSession)||void 0===e?void 0:e.totalUserFavorites)||0;Ze.addHearts(1,this.page.id),this.page.totalFavorites++;Ze.isMemberSignedIn()||0===t?Ze.toast({message:Ze.phrase("favorite-added"),action:Ze.phrase("view"),actionHandler:()=>{Ze.goto(["list","my-favorites"])}}):Ze.toast({message:Ze.phrase("prompt-to-sign-in"),action:Ze.phrase("sign-in"),duration:6e3,actionHandler:()=>{pi(this,"signin-and-fav")}})}this.page.isFavorite=!this.page.isFavorite,this.requestUpdate()}}};wn([ni(),xn("design:type",Object)],kn.prototype,"page",void 0),wn([oi({type:Boolean}),xn("design:type",Object)],kn.prototype,"rightalign",void 0),wn([oi({type:Boolean}),xn("design:type",Object)],kn.prototype,"hidecount",void 0),kn=wn([ii("slick-favorite-button")],kn);var Sn=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},_n=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Cn=class extends ei{constructor(){super(...arguments),this.src="",this.imagewidth=0,this.imageheight=0,this.width=0,this.height=0,this.sized=!1,this.contained=!1,this.currentImage="",this.intersecting=!1,this._connected=!1}render(){return Lt`
    <style>
      :host {
        display: block;
        position: relative;
        background-color: #f0f0f0;
        background-size: cover;
        background-origin: border-box;
        background-repeat: no-repeat;
        background-position: 50% 50%;
        overflow: hidden;
      }
      :host([contained]) {
        background-color: initial;
        background-size: contain;
      }
    </style>
    `}firstUpdated(){"IntersectionObserver"in window?(this.reconnectObserver(),setTimeout((()=>{this._connected&&this.reconnectObserver()}),150)):(this.intersecting=!0,this.refreshImage())}connectedCallback(){super.connectedCallback(),this._connected=!0}disconnectedCallback(){super.disconnectedCallback(),this._connected=!1}reconnectObserver(){this._observer&&this._observer.unobserve(this),this._observer=new IntersectionObserver((e=>{const t=e[0];this.intersecting=t.isIntersecting,this.refreshImage()})),this._observer.observe(this)}updated(e){e.has("src")&&this.refreshImage(),this.refreshSize()}getSizeProperty(e){const t=(window.getComputedStyle(this).getPropertyValue(e)||"").trim();if(t){const e=t.match(/\d+/g);if(e&&e[0]){const t=+e[0];if(!Number.isNaN(t))return t}}}refreshSize(){if(!this.sized){let e=this.imagewidth||128,t=this.imageheight||128,i=!0;const s=e/t;if(this.width?(e=this.width,this.height?(t=this.height,i=!1):t=e/s):this.height&&(t=this.height,e=s*this.height),i){const i=this.getSizeProperty("max-width"),o=this.getSizeProperty("max-height");i&&e>i&&(e=i,t=e/s),o&&t>o&&(t=o,e=s*t)}this.style.width=`${e}px`,this.style.height=`${t}px`}}refreshImage(){this.src?this.intersecting&&this.currentImage!==this.src&&(this.currentImage=this.src,this.style.backgroundImage=`url("${this.currentImage}")`):this.style.backgroundImage=""}};Sn([oi({type:String}),_n("design:type",Object)],Cn.prototype,"src",void 0),Sn([oi({type:Number}),_n("design:type",Object)],Cn.prototype,"imagewidth",void 0),Sn([oi({type:Number}),_n("design:type",Object)],Cn.prototype,"imageheight",void 0),Sn([oi({type:Number}),_n("design:type",Object)],Cn.prototype,"width",void 0),Sn([oi({type:Number}),_n("design:type",Object)],Cn.prototype,"height",void 0),Sn([oi({type:Boolean}),_n("design:type",Object)],Cn.prototype,"sized",void 0),Sn([oi({type:Boolean,reflect:!0}),_n("design:type",Object)],Cn.prototype,"contained",void 0),Cn=Sn([ii("slick-image")],Cn);var $n=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Pn=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let In=class extends Ds{constructor(){super(...arguments),this.rows=0}render(){return Lt`
    <style>
      :host {
        display: block;
        position: relative;
      }
      #textPanel {
        line-height: var(--slick-mulitiline-line-height, 1.4);
        -webkit-line-clamp: var(--slick-mulitiline-line-count, 2);
        -webkit-box-orient: vertical;
        display: -webkit-box;
        overflow: hidden;
      }
    </style>
    <div id="textPanel">
      <slot></slot>
    </div>
    `}updated(){this.recompute()}getSizeProperty(e){const t=(window.getComputedStyle(this).getPropertyValue(e)||"").trim();if(t){const e=t.match(/\d+/g);if(e&&e[0]){const t=+e[0];if(!Number.isNaN(t))return t}}}recompute(){if(this.rows)this.style.setProperty("--slick-mulitiline-line-count",`${this.rows}`);else{const e=this.getBoundingClientRect().height;if(e){const t=this.getSizeProperty("font-size")||16,i=Math.max(1,Math.floor(e/(1.5*t)));this.style.setProperty("--slick-mulitiline-line-count",`${i}`)}}}};$n([oi({type:Number}),Pn("design:type",Object)],In.prototype,"rows",void 0),In=$n([ii("slick-multiline")],In);var Tn=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},On=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Rn=class extends ei{constructor(){super(...arguments),this.value=0}static get styles(){return it`
      :host {
        display: -ms-inline-flexbox;
        display: -webkit-inline-flex;
        display: inline-flex;
        -ms-flex-align: center;
        -webkit-align-items: center;
        align-items: center;
        -ms-flex-pack: center;
        -webkit-justify-content: center;
        justify-content: center;
        position: relative;
        vertical-align: middle;
        fill: currentColor;
        stroke: none;
        width: 24px;
        height: 24px;
        box-sizing: initial;
      }
      svg {
        pointer-events: none;
        display: block;
        width: 100%;
        height: 100%;
      }
      path#backPath {
        fill: var(--slick-meted-icon-background, #d1d1d1);
      }
    `}render(){const e=this.icon||"",t=Ai.get(e,this.iconkey);return Lt`
    <svg viewBox="0 0 24 24" preserveAspectRatio="xMidYMid meet" focusable="false">
      <clipPath id="meterClip" clipPathUnits="objectBoundingBox">
        <rect x="0" y="0" width="${this.value}" height="1"/>
      </clipPath>
      <g>
        <path id="backPath" d="${t}"></path>
        <path d="${t}" clip-path="url(#meterClip)"></path>
      </g>
    </svg>
    `}};Tn([oi({type:String}),On("design:type",String)],Rn.prototype,"icon",void 0),Tn([oi({type:String}),On("design:type",String)],Rn.prototype,"iconkey",void 0),Tn([oi({type:Number}),On("design:type",Object)],Rn.prototype,"value",void 0),Rn=Tn([ii("metered-icon")],Rn);var En=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},jn=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Ln=class extends Ds{constructor(){super(...arguments),this.rating=0,this.total=5}render(){const e=new Array(this.total).fill(0).map(((e,t)=>{const i=t+1;return i<this.rating?1:i-this.rating<1?1-(i-this.rating):0}));return Lt`
    <style>
      :host {
        display: block;
        position: relative;
      }
      metered-icon {
        color: #f1bc42;
        width: var(--slick-rating-icon-size, 24px);
        height: var(--slick-rating-icon-size, 24px);
      }
    </style>
    <div class="horizontal center">
      ${e.map((e=>Lt`
      <metered-icon icon="star" .value="${e}"></metered-icon>
      `))}
    </div>
    `}};En([oi({type:Number}),jn("design:type",Object)],Ln.prototype,"rating",void 0),En([oi({type:Number}),jn("design:type",Object)],Ln.prototype,"total",void 0),Ln=En([ii("slick-rating-bar")],Ln);var zn=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Mn=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let An=class extends ei{constructor(){super(...arguments),this.src="",this.ratio=1,this.containment="auto",this._currentImage="",this._naturalSizedImage=!1,this._intersecting=!1,this._connected=!1}render(){var e;let t=this.ratio?`padding: ${1/(2*this.ratio)*100}% 0;`:"";this._currentImage&&(t+=` background-image: url("${this._currentImage}");`);const i=this._naturalSizedImage&&"contain"===this.containment?"natural":this.containment;return Lt`
    <style>
      :host {
        display: block;
        position: relative;
        overflow: hidden;
      }
      #panel {
        display: block;
        position: relative;
        background-color: var(--slick-image-fit-background-color, white);
        background-size: cover;
        background-origin: border-box;
        background-repeat: no-repeat;
        background-position: 50% 50%;
      }
      #panel.contain {
        background-size: contain;
      }
      #panel.natural {
        background-size: auto;
      }
      #overlay {
        position: absolute;
        pointer-events: none;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        padding: 12px;
        box-sizing: border-box;
        display: grid;
        align-content: center;
        align-items: center;
        justify-content: center;
        justify-items: center;
        background: var(--slick-image-fit-overlay-background);
      }
      #overlay span {
        font-size: var(--slick-image-fit-overlay-font-size, 14px);
        font-weight: var(--slick-image-fit-overlay-font-weight, bold);
        color: var(--slick-image-fit-overlay-color, white);
        text-transform: var(--slick-image-fit-overlay-text-transform, uppercase);
        letter-spacing: var(--slick-image-fit-overlay-letter-spacing, 1px);
      }
    </style>
    <div id="panel" class="${i}" style="${t}">
      ${(null===(e=this.overlay)||void 0===e?void 0:e.trim())?Lt`
      <div id="overlay">
        <span>${this.overlay.trim()}</span>
      </div>
      `:null}
    </div>
    `}firstUpdated(){"IntersectionObserver"in window?(this.reconnectObserver(),setTimeout((()=>{this._connected&&this.reconnectObserver()}),150)):(this._intersecting=!0,this.refreshImage())}connectedCallback(){super.connectedCallback(),this._connected=!0}disconnectedCallback(){super.disconnectedCallback(),this._connected=!1}reconnectObserver(){this._observer&&this._observer.unobserve(this),this._observer=new IntersectionObserver((e=>{const t=e[0];this._intersecting=t.isIntersecting,this.refreshImage()})),this._observer.observe(this)}updated(e){e.has("src")&&this.refreshImage(),(e.has("imagewidth")||e.has("imageheight")||e.has("ratio"))&&this.refreshImageSize()}refreshImage(){this.src?this._intersecting&&this._currentImage!==this.src&&(this._currentImage=this.src):this._currentImage=""}getPanelWidth(){const e=this.getRootNode().host;return e.computeImagePanelWidth?e.computeImagePanelWidth(this._panel):this._panel.getBoundingClientRect().width}refreshImageSize(){if(this.imageheight&&this.imagewidth&&this.ratio){const e=this.getPanelWidth(),t=e/this.ratio;if(this.imageheight<t&&this.imagewidth<e)return void(this._naturalSizedImage=!0)}this._naturalSizedImage=!1}};zn([oi({type:String}),Mn("design:type",Object)],An.prototype,"src",void 0),zn([oi({type:Number}),Mn("design:type",Object)],An.prototype,"ratio",void 0),zn([oi({type:Number}),Mn("design:type",Number)],An.prototype,"imagewidth",void 0),zn([oi({type:Number}),Mn("design:type",Number)],An.prototype,"imageheight",void 0),zn([oi(),Mn("design:type",String)],An.prototype,"containment",void 0),zn([oi(),Mn("design:type",String)],An.prototype,"overlay",void 0),zn([ni(),Mn("design:type",Object)],An.prototype,"_currentImage",void 0),zn([ni(),Mn("design:type",Object)],An.prototype,"_naturalSizedImage",void 0),zn([ai("#panel"),Mn("design:type",HTMLElement)],An.prototype,"_panel",void 0),An=zn([ii("slick-image-fit")],An);var Dn=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Hn=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Fn=class extends Ds{constructor(){super(...arguments),this.prefersOriginalImage=!1,this.prefersPageTypeIndicator=!1}render(){return Lt`
    <style>
      :host  {
        display: block;
        position: relative;
        outline: none;
      }
      #slickTemplateCellContainer {
        height: 100%;
      }
      a {
        outline: none;
      }
      :host(:focus) {
        outline: var(--slick-i-template-cell-outline, none);
      }
    </style>
    <div id="slickTemplateCellContainer" 
      .slickPageDescriptor="${this.page}"  
      @click="${this.onCellClick}"></div>
    `}createRenderRoot(){return this.attachShadow({delegatesFocus:!0,mode:"open"})}updated(e){(e.has("page")||e.has("group")||e.has("prefersOriginalImage")||e.has("prefersPageTypeIndicator"))&&this.updateData(),this.renderTemplate()}updateData(){var e,t,i,s,o,n,r,a,l,c,h;if(this.page&&this.group){const d=!("no-favorites"===((null===(t=null===(e=Ze.currentSession)||void 0===e?void 0:e.settings)||void 0===t?void 0:t.membership.behavior)||(null===(i=Ze.cachedSettings)||void 0===i?void 0:i.membership.behavior)||"optional-membership")),p=this.page.image;let u,g;p&&(u=p.url||p.pageId&&Ze.thumbnailByPageId(p.pageId)||void 0,g=this.prefersOriginalImage?u:p.pageId&&Ze.thumbnailByPageId(p.pageId)||p.url);let f=this.group.displayImageAspectRatio,v=this.group.imageContainment;if(this.group.aspectRatioOverrides){const e=this.group.aspectRatioOverrides[this.page.id];"number"!=typeof e||isNaN(e)||(f=e)}if(this.group.imageContainmentOverrides){const e=this.group.imageContainmentOverrides[this.page.id];e&&(v=e)}this._data={pinned:!1,hasRating:!1,favoriteCount:this.page.totalFavorites,isFavorite:this.page.isFavorite||!1,titleHtml:"",titleText:"",url:this.page.url,viewerUrl:this.page.viewerUrl,navigationUrl:this.page.viewerUrl||this.page.url,allowFavorites:d,isVideo:"video"===this.page.type,isWebstory:"web-story"===this.page.type,showPageType:this.prefersPageTypeIndicator};for(const e of this.group.displayFields)switch(e){case"author":this._data.author=this.page.authorHtml,this.page.authorDrillContext&&(this._data.authorUrl=Ze.computeHashUrl("search",{c:this.page.authorDrillContext}));break;case"description":this._data.description=this.page.descriptionHtml||"";break;case"image":this._data.imageFull=u,this._data.imageThumbnail=g,this._data.imageWidth=null===(s=this.page.image)||void 0===s?void 0:s.width,this._data.imageHeight=null===(o=this.page.image)||void 0===o?void 0:o.height,this._data.imageAspectRatio=f||1,this._data.imageContainment=v||"auto";break;case"imageOverlayText":this._data.imageOverlayText=this.page.imageOverlayText;break;case"pinned":this._data.pinned=this.page.pinned||!1;break;case"published":this._data.published=this.page.published?new Date(this.page.published).toLocaleDateString():void 0;break;case"rating":this._data.hasRating="number"==typeof(null===(n=this.page.recipe)||void 0===n?void 0:n.reviewCount)&&"number"==typeof(null===(r=this.page.recipe)||void 0===r?void 0:r.avgRating),(null===(a=this.page.recipe)||void 0===a?void 0:a.avgRating)&&(this.page.recipe.avgRating=+(null===(l=this.page.recipe)||void 0===l?void 0:l.avgRating).toFixed(1)),this._data.recipe=this.page.recipe;break;case"readingTime":this._data.readingTime=this.timeString(this.page.readingTime);break;case"recipeIngredients":this._data.ingredientListHtml=null===(c=this.page.recipe)||void 0===c?void 0:c.ingredientListHtml;break;case"recipeTotalTime":this._data.cookingTime=this.timeString(null===(h=this.page.recipe)||void 0===h?void 0:h.totalMinutes);break;case"section":this._data.section=this.page.sectionHtml,this.page.sectionDrillContext&&(this._data.sectionUrl=Ze.computeHashUrl("search",{c:this.page.sectionDrillContext}));break;case"title":this._data.titleHtml=this.page.titleHtml||"",this._data.titleText=this.page.titleText||""}}else this._data=void 0}timeString(e){if(!e)return;let t="";if(e>=60){const i=Math.floor(e/60),s=e%60;t=1===i?"1 hr":`${i} hrs`,s&&(t+=` ${s} min`)}else t=`${e} min`;return t}renderTemplate(){this.container&&(this._data&&this.template?this.container.innerHTML=gn.render(this.template,this._data):this.container.innerHTML="")}onCellClick(e){if(e.shiftKey&&e.metaKey)return e.stopPropagation(),e.preventDefault(),this._preview||(this._preview=new yn),this._preview.page=this.page,void this._preview.show();const t=e.srcElement||e.target;if(t){let i=null,s=t;const o=["body","head","html"];for(;s&&s.tagName;){const e=s.tagName.toLowerCase();if(o.indexOf(e)>=0)break;if("a"===e){i=s;break}s=s.parentElement}i&&i.href&&(e.stopPropagation(),this.fire("nav",{href:i.href,anchor:i}))}}updatePage(e){var t;if(!this.page||this.page.id!==e.id)return void(this.page=e);const i=[];for(const t of Object.keys(e)){if("score"===t)continue;JSON.stringify(e[t])!==JSON.stringify(this.page[t])&&i.push(t)}const s=(t,i)=>{const s=this.container.querySelectorAll(t);return!s||!s.length||(s.forEach((t=>t.innerHTML=e[i]||"")),!1)};if(i.length){let o=!1;if(this.container)for(const n of i){switch(n){case"titleHtml":s("*[data-title-html]",n),this.page[n]=e[n];break;case"descriptionHtml":s("*[data-description]",n),this.page[n]=e[n];break;case"sectionHtml":s("*[data-section]",n),this.page[n]=e[n];break;case"authorHtml":s("*[data-author]",n),this.page[n]=e[n];break;case"recipe":{this.page.recipe=e.recipe;const i=(null===(t=this.page.recipe)||void 0===t?void 0:t.ingredientListHtml)||"",s=this.container.querySelectorAll("*[data-ingredients]");s&&s.length&&s.forEach((e=>e.innerHTML=i));break}default:o=!0}if(o)break}else o=!0;o&&(this.page=e)}}focus(){this._firstlink&&this._firstlink.focus()}computeImagePanelWidth(e){return this.group?function(e,t){const i=function(e){var t;return`${e.templateId}-${(null===(t=e.cellWidth)||void 0===t?void 0:t.target)||(e.drillContext||"")+(e.displayFields||[]).sort().join("-")}`}(t),s=bn.get(i);if(s)return s;const{width:o}=e.getBoundingClientRect();return bn.set(i,o),o}(e,this.group):e.getBoundingClientRect().width}};Dn([oi({type:Object}),Hn("design:type",Object)],Fn.prototype,"group",void 0),Dn([oi({type:Object}),Hn("design:type",Object)],Fn.prototype,"page",void 0),Dn([oi(),Hn("design:type",String)],Fn.prototype,"template",void 0),Dn([oi({type:Boolean}),Hn("design:type",Object)],Fn.prototype,"prefersOriginalImage",void 0),Dn([oi({type:Boolean}),Hn("design:type",Object)],Fn.prototype,"prefersPageTypeIndicator",void 0),Dn([ai("#slickTemplateCellContainer"),Hn("design:type",HTMLDivElement)],Fn.prototype,"container",void 0),Dn([ai("a"),Hn("design:type",HTMLAnchorElement)],Fn.prototype,"_firstlink",void 0),Fn=Dn([ii("slick-template-cell")],Fn);var Bn=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Un=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Nn=class extends Ds{constructor(){super(),this.cellMap=new Map,this._focusIn=!1,this.handleFocusin=()=>{this._focusIn||(this._focusIn=!0,this.addEventListener("focusout",this.handleFocusout),this.addEventListener("keydown",this.handleKeydown))},this.handleFocusout=e=>{const t=e.relatedTarget;t&&this.contains(t)||(this._focusIn=!1,this.removeEventListener("keydown",this.handleKeydown),this.removeEventListener("focusout",this.handleFocusout))},this.focusIndex=e=>{if(this.group){const t=this.group.pageIds.length;if(t){const i=e<0?t-1:e%t,s=this.group.pageIds[i],o=this.cellMap.get(s);o&&o.focus()}}},this.handleKeydown=e=>{var t,i;const s=null===(t=this.shadowRoot)||void 0===t?void 0:t.activeElement;if(!s)return;const o=null===(i=s.page)||void 0===i?void 0:i.id;if(o&&this.group){const t=this.group.pageIds.indexOf(o);if(t<0)return;switch(e.code){case"Space":case"Spacebar":e.preventDefault();break;case"ArrowUp":case"ArrowLeft":this.focusIndex(t-1),e.preventDefault();break;case"ArrowRight":case"ArrowDown":this.focusIndex(t+1),e.preventDefault();break;case"End":this.focusIndex(this.group.pageIds.length-1),e.preventDefault();break;case"Home":this.focusIndex(0),e.preventDefault();break;case"Escape":case"Backspace":this.fire("key-escape"),e.preventDefault()}}},this.addEventListener("focusin",this.handleFocusin)}render(){return this.group?Lt`
    <style>
      :host {
        display: block;
      }
      #container {
        margin: 0 auto;
      }
    </style>
    <div id="container"></div>
    `:Lt``}updated(e){(e.has("group")||e.has("descriptors"))&&this.refresh()}async refresh(){await this.refreshPages()}async refreshPages(){var e;if(this.container)if(this.group&&this.descriptors){const t=await Ze.getTheme(),i=(null===(e=null==t?void 0:t.templatesById[this.group.templateId||""])||void 0===e?void 0:e.htmlTemplate)||"",s=this.descriptors,o=this.group.pageIds.map((e=>s[e])).filter((e=>!!e)),n=new Map;for(const e of o){let t=this.cellMap.get(e.id);t?(this.cellMap.delete(e.id),t.updatePage(e)):(t=new Fn,t.template=i,t.group=this.group,t.page=e),n.set(e.id,t),this.container.append(t)}for(const e of this.cellMap.values())e.remove();this.cellMap.clear(),this.cellMap=n}else this.cellMap.clear()}focus(){this.focusIndex(0)}};Bn([oi({type:Object}),Un("design:type",Object)],Nn.prototype,"descriptors",void 0),Bn([oi({type:Object}),Un("design:type",Object)],Nn.prototype,"group",void 0),Bn([ai("#container"),Un("design:type",HTMLDivElement)],Nn.prototype,"container",void 0),Nn=Bn([ii("slick-search-list"),Un("design:paramtypes",[])],Nn);var Vn=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},qn=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Wn=class extends Ds{constructor(){super(...arguments),this._leftScroll=!1,this._rightScroll=!1,this._cellMap=new Map,this._pendingScroll=!1,this._cellWidth=175}render(){return this.group?Lt`
    <style>
      :host {
        display: block;
      }
      #outer {
        position: relative;
      }
      #scrollPanel {
        position: relative;
        -webkit-overflow-scrolling: touch;
        overflow-x: auto;
        overflow-y: hidden;
        -ms-overflow-style: none;
        scrollbar-width: none;
        scroll-behavior: smooth;
      }
      #scrollPanel::-webkit-scrollbar {
        width: 0px;
        height: 0px;
        background: transparent;
      }
      slick-template-cell {
        flex: 0 0 auto;
      }
      .spacer {
        width: 40px;
        flex: 0 0 auto;
      }
      #overlay {
        position: absolute;
        top: 0;
        right: 0;
        left: 0;
        bottom: 0;
        pointer-events: none;
      }
      soso-icon-button {
        border-radius: 50%;
        --soso-icon-button-padding: 4px;
        cursor: pointer;
        background: var(--slick-discovery-highlight-color, #000);
        color: var(--slick-search-carousel-icon-color, #fff);
        transition: transform 0.28s ease;
        margin-top: -10px;
      }
      .overlayButton {
        cursor: pointer;
        opacity: 0;
        padding: 0 6px;
        transition: opacity 0.3s ease;
      }
      .overlayButton.showing {
        opacity: 1;
        pointer-events: auto;
      }

      @media(hover: hover) {
        #overlay {
          opacity: 0;
          transition: opacity 0.18s ease;
        }
        #outer:hover #overlay {
          opacity: 1;
        }
        soso-icon-button {
          border: 2px solid;
        }
        .overlayButton:hover soso-icon-button {
          transform: scale(1.2);
        }
      }
    </style>
    <div id="outer">
      <div id="scrollPanel" @scroll="${this.onScroll}">
        <div id="container" class="horizontal"></div>
      </div>
      <div id="overlay" class="horizontal">
        <div class="overlayButton horizontal center ${this._leftScroll?"showing":""}" @click="${this.prevPage}">
          <soso-icon-button label="Scroll left" .icon="${"rtl"===this.dir?"chevron-right":"chevron-left"}"></soso-icon-button>
        </div>
        <span class="flex"></span>
        <div class="overlayButton horizontal center ${this._rightScroll?"showing":""}" @click="${this.nextPage}">
          <soso-icon-button label="Scroll right" .icon="${"rtl"===this.dir?"chevron-left":"chevron-right"}"></soso-icon-button>
        </div>
      </div>
    </div>
    `:Lt``}updated(e){(e.has("group")||e.has("descriptors"))&&this.refresh()}async refresh(){await this.refreshPages(),this.onScroll()}async refreshPages(){var e,t;if(this._container){if(this.group&&this.descriptors){this._cellWidth=(null===(e=this.group.cellWidth)||void 0===e?void 0:e.target)||175;const i=await Ze.getTheme(),s=(null===(t=null==i?void 0:i.templatesById[this.group.templateId||""])||void 0===t?void 0:t.htmlTemplate)||"",o=this.descriptors,n=this.group.pageIds.map((e=>o[e])).filter((e=>!!e)),r=new Map;for(const e of n){let t=this._cellMap.get(e.id);t?(this._cellMap.delete(e.id),t.updatePage(e)):(t=new Fn,t.template=s,t.group=this.group,t.page=e),t.style.width=`${this._cellWidth}px`,r.set(e.id,t),this._container.append(t)}for(const e of this._cellMap.values())e.remove();this._cellMap.clear(),this._cellMap=r}else this._cellMap.clear();this._cellMap.size?(this._spacer||(this._spacer=document.createElement("div"),this._spacer.classList.add("spacer")),this._container.appendChild(this._spacer)):this._spacer&&this._spacer.remove()}}onScroll(){this._pendingScroll||(this._pendingScroll=!0,setTimeout((()=>{if(this._pendingScroll&&(this._pendingScroll=!1,this._scrollPanel)){const e=Math.abs(this._scrollPanel.scrollLeft);this._leftScroll=e>0,this._rightScroll=this._cellMap.size*this._cellWidth+40-(e+this._scrollPanel.getBoundingClientRect().width)>0}}),300))}prevPage(){if(this._scrollPanel){const e=this._scrollPanel.getBoundingClientRect().width,t=Math.floor(e/this._cellWidth),i=Math.max(0,Math.floor(this._scrollPanel.scrollLeft/this._cellWidth)-t);this._scrollPanel.scrollLeft=i*this._cellWidth}}nextPage(){if(this._scrollPanel){const e=this._scrollPanel.getBoundingClientRect().width,t=Math.floor((this._scrollPanel.scrollLeft+e)/this._cellWidth);this._scrollPanel.scrollLeft=t*this._cellWidth}}};Vn([oi(),qn("design:type",Object)],Wn.prototype,"descriptors",void 0),Vn([oi({type:Object}),qn("design:type",Object)],Wn.prototype,"group",void 0),Vn([ni(),qn("design:type",Object)],Wn.prototype,"_leftScroll",void 0),Vn([ni(),qn("design:type",Object)],Wn.prototype,"_rightScroll",void 0),Vn([ai("#container"),qn("design:type",HTMLDivElement)],Wn.prototype,"_container",void 0),Vn([ai("#scrollPanel"),qn("design:type",HTMLDivElement)],Wn.prototype,"_scrollPanel",void 0),Vn([function(e){return ri({finisher:(t,i)=>{Object.assign(t.prototype[i],e)}})}({passive:!0}),qn("design:type",Function),qn("design:paramtypes",[]),qn("design:returntype",void 0)],Wn.prototype,"onScroll",null),Wn=Vn([ii("slick-search-carousel")],Wn);var Gn=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Kn=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Yn=class extends Ds{constructor(){super(...arguments),this._columns=3,this._cellMap=new Map,this.resizeListener=()=>{this.regreshGridSize()}}render(){return this.group?Lt`
    <style>
      :host {
        display: block;
      }
      #container {
        display: grid;
        grid-template-columns: repeat(var(--slick-search-grid-col-count, 3), 1fr);
      }
    </style>
    <div id="container"></div>
    `:Lt``}updated(e){(e.has("group")||e.has("descriptors"))&&this.refresh()}async refresh(){this.regreshGridSize(),await this.refreshPages()}async refreshPages(){var e;if(this.container)if(this.group&&this.descriptors){const t=await Ze.getTheme(),i=(null===(e=null==t?void 0:t.templatesById[this.group.templateId||""])||void 0===e?void 0:e.htmlTemplate)||"",s=this.descriptors,o=this.group.pageIds.map((e=>s[e])).filter((e=>!!e)),n=new Map;for(const e of o){let t=this._cellMap.get(e.id);t?(this._cellMap.delete(e.id),t.updatePage(e)):(t=new Fn,t.template=i,t.group=this.group,t.page=e),n.set(e.id,t),this.container.append(t)}for(const e of this._cellMap.values())e.remove();this._cellMap.clear(),this._cellMap=n}else this._cellMap.clear()}connectedCallback(){super.connectedCallback(),window.addEventListener("resize",this.resizeListener,{passive:!0})}disconnectedCallback(){window.removeEventListener("resize",this.resizeListener),super.disconnectedCallback()}regreshGridSize(){var e;if(this.group){let t=0;if(this.container&&(t=this.container.getBoundingClientRect().width),t<=0)setTimeout((()=>{this.regreshGridSize()}),200);else{const i=(null===(e=this.group.cellWidth)||void 0===e?void 0:e.target)||175,s=Math.max(1,Math.round(t/i));s!==this._columns&&(this._columns=s,this.style.setProperty("--slick-search-grid-col-count",`${s}`))}}}};Gn([oi(),Kn("design:type",Object)],Yn.prototype,"descriptors",void 0),Gn([oi({type:Object}),Kn("design:type",Object)],Yn.prototype,"group",void 0),Gn([ai("#container"),Kn("design:type",HTMLDivElement)],Yn.prototype,"container",void 0),Yn=Gn([ii("slick-search-grid")],Yn);var Zn=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Qn=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Xn=class extends Ds{constructor(){super(...arguments),this.favCount=0}render(){var e,t,i,s;if(!this.membership)return Lt``;const o=!("mandatory-membership"!==(null===(e=Ze.currentSession)||void 0===e?void 0:e.settings.membership.behavior)),n=this.favCount?this.membership&&this.membership.optionaMembershipCta||Ze.phrase("favorites-panel-optional-cta"):(null===(s=null===(i=null===(t=Ze.currentSession)||void 0===t?void 0:t.settings)||void 0===i?void 0:i.discovery)||void 0===s?void 0:s.noFavoritesMessage)||Ze.phrase("favorites-panel-optional-no-favorites");return Lt`
    <style>
      :host {
        display: block;
        padding: 16px 12px;
      }
      #container {
        padding: 16px;
        position: relative;
        border-radius: 8px;
        overflow: hidden;
        font-size: 14px;
      }
      #container::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.03);
      }
      soso-button {
        color: var(--slick-search-group-title-color, var(--slick-discovery-highlight-color, #000));
        white-space: nowrap;
      }
      #signOutButton {
        margin-left: 8px;
      }
      #signInButton {
        margin-left: 8px;
      }
    </style>
    <style rtl>
      :host([dir="rtl"]) #signOutButton {
        margin-right: 8px;
        margin-left: 0;
      }
      :host([dir="rtl"]) #signInButton {
        margin-right: 8px;
        margin-left: 0;
      }
    </style>
    <div id="container">
      ${this.user?Lt`
      <div class="horizontal center">
        <span class="flex"></span>
        <span>${this.user}</span>
        <soso-button 
          id="signOutButton"
          @click="${this.signOut}">
            ${Ze.phrase("sign-out")}
        </soso-button>
      </div>
      `:Lt`
        ${o?Lt`
        <div class="horizontal center">
          <span class="flex"></span>
          <div>
            <div>${this.membership&&this.membership.memberSignupMessage||this.getDefaultSignupMessage()}</div>
            <div style="margin-top: 16px; text-align: center;">
              <soso-button solid @click="${this.showDialog}">${Ze.phrase("favorites-panel-sign-in-button")}</soso-button>
            </div>
          </div>
          <span class="flex"></span>
        </div>
        `:Lt`
        <div class="horizontal center">
          <span class="flex"></span>
          <span>${n}</span>
          <soso-button id="signInButton" @click="${this.showDialog}">${Ze.phrase("favorites-panel-sign-in-button")}</soso-button>
          <span class="flex"></span>
        </div>
        `}
      `}
      
    </div>
    `}firstUpdated(){e.subscribe("session-updated",(()=>{this.refreshState()})),e.subscribe("membership-updated",(()=>{this.refreshState()})),this.refreshState()}refreshState(){const e=Ze.currentSession;if(e){this.membership=e.settings.membership;const t=e.identity;this.user=t.name||t.email||void 0,this.favCount=e.totalUserFavorites}else this.membership=void 0,this.user=void 0,this.favCount=0}async signOut(){this.fire("signout")}showDialog(){this.fire("signin-and-fav")}getDefaultSignupMessage(){var e;return"mandatory-membership"===(null===(e=this.membership)||void 0===e?void 0:e.behavior)?Ze.phrase("default-mandatory-favorites-cta"):Ze.phrase("default-optional-favorites-cta")}};Zn([ni(),Qn("design:type",Object)],Xn.prototype,"membership",void 0),Zn([ni(),Qn("design:type",String)],Xn.prototype,"user",void 0),Zn([ni(),Qn("design:type",Object)],Xn.prototype,"favCount",void 0),Xn=Zn([ii("slick-search-favorites-header")],Xn);var Jn=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},er=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let tr=class extends Ds{constructor(){super(...arguments),this.showIcon=!1,this.favIcon="heart"}render(){var e;if(!this.group||!this.descriptors)return Lt``;const t=(this.group.title||"").trim(),i=this.showIcon&&(null===(e=this.group)||void 0===e?void 0:e.isMyFavorites)&&"custom"!==this.favIcon&&this.favIcon,s=!(!this.group.moreContext&&!this.group.addShowAll);return Lt`
    <style>
      :host {
        display: block;
        padding-bottom: 24px;
      }
      #titleBar {
        padding: 12px;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        font-size: 16px;
        line-height: 30px;
        font-weight: 500;
        color: var(--slick-search-group-title-color, var(--slick-discovery-highlight-color, #000));
      }
      #drillButton {
        --soso-icon-button-padding: 0px;
        margin: 0 4px;
        position: relative;
        display: none;
      }
      #titleBar.drillable #drillButton {
        display: block;
      }
      button.bottomButton {
        background: none;
        cursor: pointer;
        outline: none;
        border: none;
        overflow: hidden;
        color: inherit;
        user-select: none;
        position: relative;
        padding: 8px;
        border-radius: 20px;
        color: var(--slick-search-group-title-color, var(--slick-discovery-highlight-color, #000));
      }
      button.bottomButton::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        opacity: 0.1;
        background: var(--slick-search-group-title-color, var(--slick-discovery-highlight-color, #000));
        transition: opacity 0.28s ease;
      }
      button.bottomButton span {
        display: block;
        white-space: nowrap;
        font-family: ${Fs};
        font-size: 14px;
        font-weight: 500;
        letter-spacing: .0892857143em;
        text-align: center;
        text-decoration: none;
        text-transform: uppercase;
        padding-left: 8px;
        padding-right: 12px;
      }
      #groupBottomPanel {
        padding: 24px 10px 32px;
        border-bottom: var(--slick-search-group-border-bottom, 1px solid #e5e5e5);
      }
      #groupBottomPanel.showall {
        padding: 16px 10px;
        border-bottom: none;
      }
      
      #titleIcon {
        margin-right: 8px;
      }
      a, a:hover, a:visited {
        text-decoration: none;
        outline: none;
        border: none;
        color: inherit;
      }
      #titleLink {
        position: relative;
      }
      #titleLink::after {
        content: var(--slick-show-all-label, 'Show all');
        position: absolute;
        left: 100%;
        top: 50%;
        transform: translate3d(-25%, -50%, 0);
        background: rgba(0,0,0,0.05);
        border-radius: 4px;
        padding: 4px 6px;
        font-size: 12px;
        line-height: 1;
        white-space: nowrap;
        text-transform: none;
        letter-spacing: initial;
        color: rgba(0,0,0,0.6);
        font-weight: 400;
        opacity: 0;
        transition: opacity 0.28s ease, transform 0.28s ease;
      }

      @media (max-width: 600px) {
        :host {
          padding-bottom: 8px;
        }
        #titleLink::after {
          opacity: 1;
          transform: translate3d(0, -50%, 0);
        }
        :host([dir="rtl"]) #titleLink::after {
          opacity: 1;
          transform: translate3d(0, -50%, 0);
        }
      }

      @media (hover: hover) {
        #drillButton {
          opacity: 0;
          transform: translate3d(-50%, 0 , 0) scale(0);
          transition: ${Hs};
        }
        :host([dir="rtl"]) #drillButton {
          transform: translate3d(50%, 0 , 0) scale(0);
        }
        :host(:hover) #drillButton {
          opacity: 1;
          transform: translate3d(0, 0 , 0) scale(1);
        }
        #drillButton:hover {
          --soso-icon-button-before-opacity: 0;
        }
        button.bottomButton:hover::before {
          opacity: 0.2;
        }
        :host([dir="rtl"]) #titleLink::after {
          transform: translate3d(25%, -50%, 0);
        }
        :host(:hover) #titleLink::after {
          opacity: 1;
          transform: translate3d(0, -50%, 0);
        }
      }
    </style>
    <style rtl>
      :host([dir="rtl"]) #titleIcon {
        margin-left: 8px;
        margin-right: 0;
      }
      :host([dir="rtl"]) button.bottomButton span {
        padding-right: 8px;
        padding-left: 12px;
      }
      :host([dir="rtl"]) #titleLink::after {
        left: initial;
        right: 100%;
      }
    </style>

    ${t?Lt`
    <div id="titleBar" class="horizontal center ${this.group.drillContext?"drillable":""}">
      ${this.drillUrl?Lt`
      <a id="titleLink" href="${this.drillUrl}" class="horizontal center" @click="${this.titleClick}">
        ${i?Lt`<soso-icon id="titleIcon" .icon="${i}"></soso-icon>`:""}
        <span>${t}</span>
        <soso-icon-button id="drillButton" .icon="${"rtl"===this.dir?"chevron-left":"chevron-right"}" label="${Ze.phrase("show-all")}"></soso-icon-button>
      </a>
      `:Lt`
      <label class="horizontal center">
        ${i?Lt`<soso-icon id="titleIcon" .icon="${i}"></soso-icon>`:""}
        <span>${t}</span>
      </label>
      `}
      
      <span class="flex"></span>
    </div>
    `:""}

    ${this.renderItems(this.group)}
    
    ${s?Lt`
    <div id="groupBottomPanel" class="${this.group.addShowAll?"showall":""}">
      
      ${this.group.moreContext?Lt`
      <button class="horizontal center bottomButton" @click="${this.fetchMore}">
        <span>${Ze.phrase("more")}</span>
        <soso-icon icon="more-horiz"></soso-icon>
      </button>
      `:null}

      ${this.group.addShowAll?Lt`
      <button class="horizontal center bottomButton" @click="${this.showAll}">
        <span>${Ze.phrase("show-all")}</span>
        <soso-icon icon="more-horiz"></soso-icon>
      </button>
      `:null}
      
    </div>`:null}
    
    `}renderItems(e){const t=this.descriptors||{};switch(e.style){case"list":return Lt`<slick-search-list id="itemCollection" .descriptors="${t}" .group="${e}"></slick-search-list>`;case"grid":return Lt`<slick-search-grid id="itemCollection" .descriptors="${t}" .group="${e}"></slick-search-grid>`;case"carousel":return Lt`<slick-search-carousel .descriptors="${t}" .group="${e}"></slick-search-carousel>`;case"favorites-heading":return Lt`<slick-search-favorites-header></slick-search-favorites-header>`}return Lt``}updated(){this.style.setProperty("--slick-show-all-label",`'${Ze.phrase("show-all")}'`)}titleClick(e){e.stopPropagation(),e.metaKey||e.shiftKey||e.ctrlKey||e.altKey||(e.preventDefault(),this.drillUrl&&this.fire("search-drill",this.group))}showAll(){this.fire("search-show-all")}async fetchMore(){this.fire("search-more",{group:this.group,groupUI:this})}refresh(){this.requestUpdate(),this.itemCollection&&this.itemCollection.refresh()}focus(){this.itemCollection&&this.itemCollection.focus&&this.itemCollection.focus()}};Jn([oi(),er("design:type",Object)],tr.prototype,"descriptors",void 0),Jn([oi({type:Object}),er("design:type",Object)],tr.prototype,"group",void 0),Jn([oi({type:Boolean}),er("design:type",Object)],tr.prototype,"showIcon",void 0),Jn([oi(),er("design:type",String)],tr.prototype,"favIcon",void 0),Jn([oi(),er("design:type",String)],tr.prototype,"drillUrl",void 0),Jn([ai("#itemCollection"),er("design:type",Object)],tr.prototype,"itemCollection",void 0),tr=Jn([ii("slick-search-group")],tr);var ir=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},sr=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let or=class extends Ds{constructor(){super(...arguments),this.icon="",this.activeIcon="",this.active=!1,this.mini=!1,this.reverse=!1,this.autoextend=!1,this._extended=!1,this.enterHandler=()=>{this.extended=!0},this.leaveHandler=()=>{this.extended=!1}}render(){return Lt`
    <style>
      :host {
        display: inline-block; 
        color: white;
      }
      #iconPanel {
        position: relative;
      }
      soso-icon {
        transition: opacity 100ms linear 30ms, transform .27s cubic-bezier(0,0,.2,1) 0ms;
      }
      button {
        background-color: var(--fab-background, #018786);
        background-size: cover;
        background-origin: border-box;
        background-position: 50% 50%;
        cursor: pointer;
        outline: none;
        border: none;
        overflow: hidden;
        padding: var(--fab-padding, 12px);
        border-radius: 50%;
        color: inherit;
        user-select: none;
        position: relative;
        box-shadow: var(--fab-shadow, 0 3px 5px -1px rgba(0,0,0,.2), 0 6px 10px 0 rgba(0,0,0,.14), 0 1px 18px 0 rgba(0,0,0,.12));
        transition: ${Hs};
      }
      button:focus {
        box-shadow: var(--fab-focus-shadow, 0 5px 5px -3px rgba(0,0,0,.2), 0 8px 10px 1px rgba(0,0,0,.14), 0 3px 14px 2px rgba(0,0,0,.12));
      }
      button::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: var(--fab-before-bg, currentColor);
        opacity: 0;
        transition: ${Hs};
      }
      button:focus::before {
        opacity: 0.18;
      }
      button:active::before {
        opacity: 0.36 !important;
      }
      button:active {
        box-shadow: 0px 7px 8px -4px rgba(0, 0, 0, 0.2), 0px 12px 17px 2px rgba(0, 0, 0, 0.14), 0px 5px 22px 4px rgba(0, 0, 0, 0.12) !important;
      }
      #icon {
        opacity: 1;
      }
      #activeIcon {
        position: absolute;
        top: 0;
        left: 0;
        opacity: 0;
        transform: rotateZ(-90deg);
      }
      label {
        display: block;
        white-space: nowrap;
        font-family: ${Fs};
        font-size: 14px;
        font-weight: 500;
        letter-spacing: .0892857143em;
        text-align: center;
        text-decoration: none;
        text-transform: uppercase;
        padding-left: 12px;
        padding-right: 8px;
        transition: ${Hs};
      }
      #labelPanel {
        position: relative;
        overflow: hidden;
        width: 0px;
        pointer-events: none;
        white-space: nowrap;
      }
      #labelPanel.extended {
        width: var(--fab-label-width, auto);
      }
      .animatable {
        transition: width .27s cubic-bezier(0,0,.2,1) 0ms;
      }
      #activeLabel {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        opacity: 0;
        transform: translateY(80%);
      }
      img {
        display: block;
        border-radius: 50%;
        height: 48px;
        width: 48px;
      }

      button.hasImage {
        padding: 0;
      }
      button.hasImage label {
        padding-right: 20px;
      }
      button[reverse].hasImage label {
        padding-right: 12px;
        padding-left: 20px;
      }

      button[mini] {
        padding: 8px;
        border-radius: 20px;
      }
      button[mini].hasImage {
        padding: 0;
      }
      button[mini] img {
        height: 40px;
        width: 40px;
      }
      
      button[reverse] {
        flex-direction: row-reverse;
      }
      button[reverse] label {
        padding-right: 12px;
        padding-left: 8px;
      }
      button[active] #activeIcon {
        opacity: 1;
        transform: none;
      }
      button[active] #icon {
        opacity: 0;
        transform: rotateZ(90deg);
      }
      button[active].haActiveLabel #activeLabel {
        opacity: 1;
        transform: none;
      }
      button[active].haActiveLabel #label {
        opacity: 0;
        transform: translateY(-80%);
      }

      @media (hover: hover) {
        button:hover::before {
          opacity: 0.08;
        }
        button:focus::before {
          opacity: 0.18;
        }
        button:hover,button:focus {
          box-shadow: var(--fab-shadow, 0 5px 5px -3px rgba(0,0,0,.2), 0 8px 10px 1px rgba(0,0,0,.14), 0 3px 14px 2px rgba(0,0,0,.12));
        }
      }
    </style>
    <style rtl>
      :host([dir="rtl"]) label {
        padding-right: 12px;
        padding-left: 8px;
      }
      :host([dir="rtl"]) button[reverse].hasImage label {
        padding-left: 12px;
        padding-right: 20px;
      }
      :host([dir="rtl"]) button[reverse] label {
        padding-left: 12px;
        padding-right: 8px;
      }
    </style>
    <button 
      ?active="${this.active}"
      ?mini="${this.mini}"
      ?reverse="${this.reverse}"
      aria-label="${this.label||this.icon||""}" 
      class="horizontal center ${this.activeLabel?"haActiveLabel":""} ${this.image?"hasImage":""}">

      ${this.image?Lt`
        <img src="${this.image}" alt="${this.label}">
        `:Lt`
        <div id="iconPanel">
          <soso-icon id="icon" .icon="${this.icon}" .customSvg="${this.customSvg}"></soso-icon>
          <soso-icon id="activeIcon" .icon="${this.activeIcon}" .customSvg="${this.customSvgActive}"></soso-icon>
        </div>
        `}
      
      <div id="labelPanel">
        <label id="label" ?hidden="${!this.label}">${this.label}</label>
        <label id="activeLabel" ?hidden="${!this.activeLabel}">${this.activeLabel}</label>
      </div>
    </button>
    `}firstUpdated(){this.updateExtended()}get extended(){return this._extended}set extended(e){e!==this._extended&&(this._extended=e,this.updateExtended())}updateExtended(){const e=this._extended;if(this.labelPanel){const t=this.labelPanel;if(e){t.classList.add("extended");const{width:i}=t.getBoundingClientRect();t.classList.remove("extended"),requestAnimationFrame((()=>{t.classList.add("animatable"),t.style.width=`${i}px`}));const s=()=>{t.style.width="",t.classList.add("extended"),t.classList.remove("animatable"),t.removeEventListener("transitionend",s)};t.addEventListener("transitionend",s),setTimeout((()=>{this._extended===e&&s()}),500)}else{const{width:i}=t.getBoundingClientRect();t.style.width=`${i}px`,t.getBoundingClientRect(),requestAnimationFrame((()=>{t.classList.add("animatable"),t.style.width="0px"}));const s=()=>{t.style.width="",t.classList.remove("extended"),t.classList.remove("animatable"),t.removeEventListener("transitionend",s)};t.addEventListener("transitionend",s),setTimeout((()=>{this._extended===e&&s()}),500)}}}updated(e){e.has("autoextend")&&this.button&&(this.button.removeEventListener("mouseenter",this.enterHandler),this.button.removeEventListener("mouseleave",this.leaveHandler),this.autoextend&&(this.button.addEventListener("mouseenter",this.enterHandler),this.button.addEventListener("mouseleave",this.leaveHandler)))}};ir([oi(),sr("design:type",Object)],or.prototype,"icon",void 0),ir([oi(),sr("design:type",Object)],or.prototype,"activeIcon",void 0),ir([oi(),sr("design:type",String)],or.prototype,"image",void 0),ir([oi(),sr("design:type",String)],or.prototype,"label",void 0),ir([oi(),sr("design:type",String)],or.prototype,"activeLabel",void 0),ir([oi(),sr("design:type",String)],or.prototype,"customSvg",void 0),ir([oi(),sr("design:type",String)],or.prototype,"customSvgActive",void 0),ir([oi({type:Boolean}),sr("design:type",Object)],or.prototype,"active",void 0),ir([oi({type:Boolean}),sr("design:type",Object)],or.prototype,"mini",void 0),ir([oi({type:Boolean}),sr("design:type",Object)],or.prototype,"reverse",void 0),ir([oi({type:Boolean}),sr("design:type",Object)],or.prototype,"autoextend",void 0),ir([ai("#labelPanel"),sr("design:type",HTMLDivElement)],or.prototype,"labelPanel",void 0),ir([ai("button"),sr("design:type",HTMLButtonElement)],or.prototype,"button",void 0),or=ir([ii("slick-fab")],or);var nr=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},rr=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let ar=class extends Ds{constructor(){super(...arguments),this.favCount=0,this.favicon="heart"}render(){return Lt`
    <style>
      :host {
        display: block;
      }
      #userBar {
        padding: 8px;
        color: white;
        font-size: 14px;
      }
      label,
      soso-button {
        pointer-events: auto;
      }
      #signinButton {
        margin-left: 8px;
      }
      #userLabel {
        padding: 4px 8px;
        letter-spacing: 0.5px;
        cursor: pointer;
        border-radius: 3px;
      }
      #countButton {
        line-height: 20px;
        font-size: 18px;
        background: rgba(0,0,0,0.05);
        border-radius: 8px;
      }
      #countButton soso-icon {
        width: 20px;
        height: 20px;
        margin-left: 6px;
      }
      slick-popup-actions {
        right: 0;
        left: auto;
        bottom: auto;
        top: calc(100% + 6px);
        --slick-popup-actions-shadow: none;
        --slick-popup-actions-background: rgba(255,255,255,0.2);
        --slick-discovery-highlight-color: white;
        --slick-popup-actions-initial-transform: translate3d(50%, -50%, 0) scale(0);
      }
      slick-popup-actions button {
        text-transform: uppercase;
        letter-spacing: 1.5px;
      }

      @media (max-width: 600px) {
        #messageLabel {
          display: none;
        }
      }

      @media(hover: hover) {
        #userLabel:hover {
          background: rgba(255,255,255,0.1);
        }
      }
    </style>
    <style rtl>
      :host([dir="rtl"]) #countButton soso-icon {
        margin-right: 6px;
        margin-left: 0;
      }
      :host([dir="rtl"]) slick-popup-actions {
        right: auto;
        left: 0;
      }
    </style>
    <div id="userBar" class="horizontal center">
      <soso-button id="countButton" @click="${this.gotoFavs}">
        <div class="horizontal center">
          <span>${this.favCount}</span>
          <soso-icon .icon="${this.favicon}"></soso-icon>
        </div>
      </soso-button>
      <span class="flex"></span>
      ${this.user?Lt`
        <div style="position: relative;">
          <label id="userLabel" @click="${this.onUserClick}">${this.user}</label>
          <slick-popup-actions id="popupMenu">
            <button @click="${this.signout}">${Ze.phrase("sign-out")}</button>
          </slick-popup-actions>
        </div>
        `:Lt`
        ${this.favCount?Lt`<label id="messageLabel">${Ze.phrase("favorites-panel-optional-cta")}.</label>`:""}
        <soso-button id="signinButton" @click="${this.onSignIn}">${Ze.phrase("sign-in")}</soso-button>
        `}
    </div>
    `}firstUpdated(){e.subscribe("session-updated",(()=>{this.refreshState()})),e.subscribe("membership-updated",(()=>{this.refreshState()})),this.refreshState()}refreshState(){const e=Ze.currentSession;if(e){const t=e.identity;this.user=t.name||t.email||void 0,this.favicon=e.settings.heartbeatIcon.iconType||"heart",this.favCount=e.totalUserFavorites}else this.user=void 0,this.favCount=0}onSignIn(e){e.stopPropagation(),this.fire("signin-and-fav")}signout(e){e.stopPropagation(),this.fire("signout")}gotoFavs(e){e.stopPropagation(),Ze.goto(["list","my-favorites"])}onUserClick(e){e.stopPropagation(),this.popActions&&(this.popActions.showing=!this.popActions.showing)}};nr([ni(),rr("design:type",String)],ar.prototype,"user",void 0),nr([ni(),rr("design:type",Object)],ar.prototype,"favCount",void 0),nr([ni(),rr("design:type",String)],ar.prototype,"favicon",void 0),nr([ai("#popupMenu"),rr("design:type",oo)],ar.prototype,"popActions",void 0),ar=nr([ii("search-user-bar")],ar);var lr=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},cr=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const hr="c",dr="discovery",pr="slick-search-panel-showing";let ur=class extends Ds{constructor(){super(...arguments),this.disableCachedResults=!1,this._open=!1,this._stickyHeader=!1,this._solidBg=!1,this._query="",this._searchInputIcon="search",this._showOffline=!1,this._favIcon="heart",this._offline=!1,this._offlineUpdateTimer=0,this._hashQuery="",this._oflows=["",""],this._dirtyText=!1,this._urlHashUpdateTimer=0,this._moreOnIdleTimer=0,this._searchEpoch=0,this._mainWidth=0,this._listMode=!1,this._preventCachedScrolling=!1,this._lastOpenTime=0,this._mobile=window.innerWidth<=600,this.handleHashChange=async e=>{const{path:t,params:i,segments:s}=e;if("slick-favorites"===t)setTimeout((()=>{Ze.goto(["list","my-favorites"])}));else if("slick-search"===t)setTimeout((()=>{Ze.goto("search")}));else if(0===t.indexOf("slick-search-")){let e=t.substring("slick-search-".length);"favorites"===e&&(e="my-favorites"),setTimeout((()=>{Ze.goto(["list",e])}))}else if("list"===t){const e=s[1];e?(this._listMode=!0,this._drillContext=void 0,this._arrangement="context-without-search",this._groupType=e,this.searchFromHashChange("",this._groupType)):this.hide()}else if("search"===t){const e=(i.q||"").trim(),t=(i[hr]||"").trim();this._arrangement=(i.a||"").trim()||void 0,this._hashQuery=e,this._query=e,this._drillContext=t||void 0,this._groupType=void 0,this._listMode=!1,this.searchFromHashChange(e,void 0)}else this.hide()},this.openListener=e=>{this._preventCachedScrolling=!0;const{page:t="search",key:i}=e.detail||{};switch(t){case"search":case"":if(i&&i.trim()&&1===i.length){Ze.gotoWithParams("search",{q:i});break}Ze.goto("search");break;case"favorites":Ze.goto(["list","my-favorites"]);break;default:Ze.goto(["list",t])}}}render(){var e,t,i,s,o,n,r,a,l,c,h,d,p,u,g,f,v,m,y;const b=(null===(e=this._results)||void 0===e?void 0:e.groups)||[];let w="";"context-with-search"===(null===(t=this._results)||void 0===t?void 0:t.arrangement)&&(w=this._results.contextTitle||"");const x=this._mobile=window.innerWidth<=600,k=!!(null===(s=null===(i=this.settings)||void 0===i?void 0:i.discovery)||void 0===s?void 0:s.hideAttribution),S=!!(null===(n=null===(o=this.settings)||void 0===o?void 0:o.discovery)||void 0===n?void 0:n.useFavoritesIcon),_=S&&(null===(r=this._results)||void 0===r?void 0:r.contextIsMyFavorites)&&"custom"!==this._favIcon&&this._favIcon,C=(null===(l=null===(a=this.settings)||void 0===a?void 0:a.discovery)||void 0===l?void 0:l.noMatchesText)||Ze.phrase("no-matches-found")||"No matches found",$=!(!this._results||0!==b.length);let P="";this._listMode?P=(null===(c=this._results)||void 0===c?void 0:c.contextTitle)||"":(P=`${w}${this._query?":":""} ${this._query}`.trim(),0===P.indexOf(":")&&(P=P.substring(1).trim()));const I=(null===(d=null===(h=this.settings)||void 0===h?void 0:h.discovery)||void 0===d?void 0:d.searchBoxPlaceholderText)||Ze.phrase("search-text")||"search text",T=null===(u=null===(p=this.settings)||void 0===p?void 0:p.discovery)||void 0===u?void 0:u.closeSearchPanelText,O="no-favorites"===(null===(g=this.settings)||void 0===g?void 0:g.membership.behavior)||"no-membership"===(null===(f=this.settings)||void 0===f?void 0:f.membership.behavior),R=!!(null===(m=null===(v=this.settings)||void 0===v?void 0:v.discovery)||void 0===m?void 0:m.disableGlassPanel);let E=1;return b.forEach((e=>{"ad-slot"===e.style&&(e.title=""+E++)})),Lt`
    <style>
      :host {
        line-height: 1.5;
      }
      #shell {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        overflow: hidden;
        pointer-events: none;
        font-family: var(--slick-search-font-family, ${Fs});
        font-weight: var(--slick-search-font-weight, normal);
        z-index: var(--slick-search-panel-zindex, var(--slick-discovery-zindex, var(--slick-toolbar-zindex, 200002)));
      }
      #glass {
        -webkit-backdrop-filter: var(--slick-search-glass-filter, blur(10px));
        backdrop-filter: var(--slick-search-glass-filter, blur(10px));
        opacity: 0;
        transition: opacity 15ms linear 30ms;
        height: var(--slick-search-glass-height, 25vh);
        min-height: 116px;
      }
      #shell.no-glass #glass {
        -webkit-backdrop-filter: none;
        backdrop-filter: none;
      }
      #panel {
        position: relative;
        background: var(--slick-search-panel-background, white);
        box-shadow: 0 3px 5px -1px rgba(0,0,0,.2), 0 6px 10px 0 rgba(0,0,0,.14), 0 1px 18px 0 rgba(0,0,0,.12);
        min-height: 75vh;
        transform: translateY(100vh);
        opacity: 0;
        transition: opacity .28s cubic-bezier(.4,0,.2,1), transform .27s cubic-bezier(0,0,.2,1) 0ms;
      }
      #shell.no-glass #panel {
        box-shadow: none;
      }
      #shell.no-glass #stickySection {
        padding: 6px 0px 40px 0px !important;
        position: relative;
        top: 45px;
      }
      #stickySection {
        padding: 6px;
        --soso-button-icon-size: 32px;
        color: white;
        transform: translateY(100vh);
        opacity: 0;
        transition: opacity .28s cubic-bezier(.4,0,.2,1), transform .27s cubic-bezier(0,0,.2,1) 0ms;
        pointer-events: none;
      }
      #stickySection soso-icon-button {
        pointer-events: auto;
      }
      #stickySection soso-button {
        pointer-events: auto;
      }
      #stickySection.stuck {
        position: fixed;
        top: -68px;
        left: 0;
        right: 0;
        z-index: 100;
        background: rgba(255,255,255,0.95);
        color: var(--slick-discovery-highlight-color, #555);
        box-shadow: 0 1px 3px -1px rgba(0,0,0,0.4);
        --soso-button-icon-size: 28px;
        --soso-icon-button-padding: 8px;
        pointer-events: auto;
        margin-top: 0;
      }
      #stickySearchLabelPanel {
        display: none;
      }
      #stickySection.stuck #stickySearchLabelPanel {
        display: flex;
      }
      #stickySection.stuck #poweredBy {
        display: none;
      }
      #shell.no-glass #stickySection {
        background: rgba(255,255,255,1);
        color: var(--slick-discovery-highlight-color, #555);
        --soso-button-icon-size: 28px;
        --soso-icon-button-padding: 8px;
      }
      #stickySearchLabel {
        color: #555;
        font-size: 13px;
        white-space: nowrap;
        box-sizing: border-box;
        overflow: hidden;
        text-overflow: ellipsis;
        position: relative;
        max-width: 220px;
        cursor: pointer;
      }
      #searchSection {
        max-width: var(--slick-discovery-content-max-width, 1200px);
        margin: 0 auto;
        padding: 16px 12px;
      }
      #searchSection soso-icon {
        color: var(--slick-discovery-highlight-color, #555);
      }
      #searchPanel {
        background: var(--slick-search-card-background, none);
        box-shadow: var(--slick-search-input-shadow, inset 2px 2px 4px rgba(0,0,0,0.1), inset -2px -2px 4px #f9f9f9);
        border: var(--slick-search-input-border, none);
        border-radius: var(--slick-search-input-border-radius, 24px);
        padding: 0 16px 0 0;
        position: relative;
      }
      #searchInput {
        border: none;
        width: 100%;
        background: none;
        display: block;
        line-height: 40px;
        font-size: 14px;
        padding: 0 16px;
        outline: none;
        font-family: ${Fs};
        color: #555;
      }
      #searchInputIcon {
        cursor: pointer;
      }
      main {
        max-width: var(--slick-discovery-content-max-width, 1200px);
        margin: 0 auto;
        padding-bottom: 200px;
        min-height: 100vh;
      }
      .chip {
        position: relative;
        font-size: 12px;
        padding: 0 0 0 8px;
        border-radius: 20px;
        margin: 0 0 0 5px;
        line-height: 1;
        color: #000;
        overflow: hidden;
      }
      .chip::before {
        content: '';
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        background: var(--slick-discovery-highlight-color, #2196f3);
        opacity: 0.1;
      }
      .chipLabelIcon {
        margin: 0 4px 0 0;
      }
      .chip soso-icon {
        width: 1.5em;
        height: 1.5em;
      }
      .chipClose {
        padding: 6px 6px 6px 8px;
        cursor: pointer;
      }
      .chipLabel {
        max-width: 140px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      #listPanel {
        position: relative;
        padding: 0 140px;
        min-height: 40px;
      }
      slick-fab {
        --fab-background: var(--slick-discovery-highlight-color, #2196f3);
      }
      #listPanel slick-fab {
        position: absolute;
        left: 0;
        top: 0;
      }
      #listTitle {
        letter-spacing: 1px;
        font-size: 20px;
        font-weight: 400;
        color: var(--slick-search-group-title-color, var(--slick-discovery-highlight-color, #000));
        text-align: center;
      }
      #listTitle soso-icon {
        margin-right: 8px;
      }
      #stickySectionRightPanel {
        text-align: right;
        padding-right: 12px;
        color: #eee;
      }
      #shell.no-glass #stickySectionRightPanel {
        color: #aaa;
      }
      #offlineLabel {
        display: none;
        position: relative;
      }
      #stickySection.stuck #stickySectionRightPanel {
        color: #aaa;
      }
      #stickySectionRightPanel.offline #offlineLabel {
        display: inline-block;
      }
      #stickySectionRightPanel.offline span {
        transform: translate3d(0,0,0);
      }
      #stickySectionRightPanel.offline #offlineIcon {
        animation: rotation 3s infinite linear;
      }
      #stickySectionRightPanel.offline #poweredBy {
        display: none;
      }
      search-user-bar {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        transform: translate3d(0,-150%,0);
        opacity: 0;
        transition: opacity .28s cubic-bezier(.4,0,.2,1), transform .27s cubic-bezier(0,0,.2,1) 0ms;
        pointer-events: none;
      }
      #noresults {
        padding: 32px 16px;
        text-align: center;
        font-size: 14px;
        color: #808080;
        letter-spacing: 0.5px;
      }
      #poweredBy {
        position: relative;
        display: inline-block;
        text-decoration: none;
        color: inherit;
        outline: none;
        border: none;
        font-size: 11px;
        letter-spacing: 0.5px;
        pointer-events: auto;
        margin-top: 16px;
      }
      #poweredByMobile {
        display: none;
      }
      main ::slotted(.slick-search-ad-slot) {
        box-sizing: border-box;
        padding: 12px;
      }
      @keyframes rotation {
        from {
          transform: rotate(0deg);
        }
        to {
          transform: rotate(359deg);
        }
      }

      @supports not ((-webkit-backdrop-filter: none) or (backdrop-filter: none)) {
        #glass {
          background: rgba(0,0,0,0.7);
        }
      }
    </style>
    <style mobile>
      @media (max-width: 600px) {
        #searchInput {
          font-size: 16px;
        }
        #searchSection {
          padding: 8px 6px;
        }
        .chipLabel {
          max-width: 96px;
        }
        #listPanel {
          padding: 0 48px;
        }
        #listTitle {
          font-size: 18px;
        }
        #stickySearchLabel {
          max-width: 115px;
        }
        #poweredByDesktop {
          display: none;
        }
        #poweredByMobile {
          display: initial;
        }
        #poweredBy {
          margin-top: 4px;
        }
        #glass {
          height: 116px;
        }
        #shell.no-glass #glass {
          min-height: initial;
          height: 64px;
        }
        search-user-bar {
          position: absolute;
        }
      }
    </style>
    <style open-shell>
      #shell[open] {
        pointer-events: auto;
        overflow-y: auto;
        -webkit-overflow-scrolling: touch;
        background: var(--slick-search-glass-background, rgba(0,0,0,0.4));
      }
      #shell[open].solid {
        background: var(--slick-search-panel-background, white);
      }
      #shell[open] #glass{
        opacity: 1;
      }
      #shell[open].no-glass #glass {
        min-height: initial;
        height: 56px;
        background-color: var(--slick-discovery-highlight-color, #2196f3);
      }
      #shell[open] #stickySection {
        margin-top: -64px;
      }
      #shell.no-glass[open] #stickySection {
        margin-top: -56px;
      }
      #shell[open] #stickySection,
      #shell[open] #panel {
        transform: none;
        opacity: 1;
      }
      #shell[open] #stickySection.stuck {
        transform: translateY(68px);
        margin-top: 0;
      }
      #shell[open] search-user-bar {
        opacity: 1;
        transform: translate3d(0,0,0);
        transition: transform .27s cubic-bezier(0,0,.2,1) 350ms;
      }
    </style>
    <style rtl>
      :host([dir="rtl"]) #stickySectionRightPanel {
        text-align: left;
        padding-right: 0;
        padding-left: 12px;
      }
      :host([dir="rtl"]) #searchPanel {
        padding: 0 0 0 16px;
      }
      :host([dir="rtl"]) .chip {
        padding: 0 8px 0 0;
        margin: 0 5px 0 0;
      }
      :host([dir="rtl"]) #listTitle soso-icon {
        margin-right: 0;
        margin-left: 8px;
      }
      :host([dir="rtl"]) .chipLabelIcon {
        margin: 0 0 0 4px;
      }
      :host([dir="rtl"]) #listPanel slick-fab {
        left: initial;
        right: 0;
      }
    </style>

    <div id="shell" 
      ?open="${this._open}" 
      class="${this._solidBg?"solid":""} ${R?"no-glass":""}"
      @signin-and-fav="${this.signInAndFav}"
      @signout="${this.signOut}">
      
      <div id="glass" @click="${this.close}"></div>

      <search-user-bar ?hidden="${O}"></search-user-bar>
      <section id="stickySection" class="horizontal center ${this._stickyHeader?"stuck":""}">
        <div class="flex">
          <div id="stickySearchLabelPanel" class="horizontal center">
            <soso-icon-button .icon="${this._listMode?"more-vert":"search"}" @click="${this.scrollToSearchAndSelect}"></soso-icon-button>
            <div class="flex">
              <div id="stickySearchLabel" @click="${this.scrollToSearchAndSelect}">${P}</div>
            </div>
          </div>
        </div>
        
        ${T?Lt`
          <soso-button @click="${this.close}">
            <div class="horizontal center" style="line-height: 24px;">
              <span>${T}</span>
              <soso-icon style="margin-left: 6px;" icon="more"></soso-icon>
            </div>
          </soso-button>
        `:Lt`
          <soso-icon-button icon="more" label="Close Search" @click="${this.close}"></soso-icon-button>
        `}
        
        <div id="stickySectionRightPanel" class="flex ${this._showOffline?"offline":""}">
          ${k?"":Lt`
          <a id="poweredBy" class="horizontal center" href="https://www.slickstream.com/discover-slickstream" target="_blank" rel="noopener" aria-label="Powered by Slickstream">
            <span id="poweredByDesktop">Powered by Slickstream</span>
            <span id="poweredByMobile">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 205.86 176.1" style="display: block; width: 24px; height: 24px; ">
                <g fill="currentColor">
                  <path d="M123.75,80.25l44.89-14.08c12.6-4,26.19-17.13,23.05-27.14L108.53,65.1Z"></path>
                  <path d="M150.15,106.52c11.61-4.93,22.84-16.79,20-26l-35,11Z"></path>
                  <path d="M82.11,95.85,37.23,109.93c-12.6,3.95-26.2,17.13-23.06,27.14L97.33,111Z"></path>
                  <path d="M55.71,69.58c-11.61,4.93-22.84,16.79-20,26l35-11Z"></path>
                  <path d="M140.75,112.21,85.68,57.44l96.66-30.3C194.94,23.19,208.55,10,205.41,0L70.47,42.3,55.18,47.1a3.3,3.3,0,0,0-1.35,5.48L65.11,63.89l55.07,54.77L23.52,149C10.92,152.91-2.68,166.08.46,176.1l134.93-42.3,15.29-4.8a3.3,3.3,0,0,0,1.35-5.48Z"></path>
                </g>
              </svg>
            </span>
          </a>
          `}
          
          <div id="offlineLabel" class="horizontal center">
            <span>
              ${Ze.phrase("offline")}
            </span>
            <soso-icon id="offlineIcon" icon="refresh"></soso-icon>
          </div>
        </div>
      </section>

      <div id="panel">
        <section id="searchSection">

          <div class="horizontal center" ?hidden="${this._listMode}">
            ${w?Lt`<slick-fab mini icon="search" label="${Ze.phrase("search")}" @click="${this.resetSearch}" style="margin-right: 8px;"></slick-fab>`:null}
            
            <div id="searchPanel" class="flex horizontal center">
              ${w?Lt`
              <div class="chip horizontal center">
                ${_?Lt`<soso-icon class="chipLabelIcon" .icon="${_}"></soso-icon>`:""}
                <div class="chipLabel">${w}</div>
                <div class="chipClose" @click="${this.clearDrillContext}">
                  <soso-icon icon="close"></soso-icon>
                </div>
              </div>
              `:""}
              <div class="flex">
                <input id="searchInput" 
                  aria-label="Enter search text here and the search results will be automatically updated as you type" 
                  autocomplete="off" 
                  spellcheck="false" 
                  placeholder="${I}"
                  @focus="${this.onSearchInputFocus}"
                  @click="${this.onSearchInputClick}"
                  @input="${this.onTextInput}"
                  @keydown="${this.onTextKeyDown}">
              </div>
              <soso-icon id="searchInputIcon" .icon="${this._searchInputIcon}" @click="${this.clearSearchText}"></soso-icon>
            </div>
          </div>
          
          <div id="listPanel" class="horizontal center" ?hidden="${!this._listMode}">
            <div id="listTitle" class="flex horizontal center">
              <span class="flex"></span>
              ${_?Lt`<soso-icon .icon="${_}"></soso-icon>`:""}
              <span>${(null===(y=this._results)||void 0===y?void 0:y.contextTitle)||""}</span>
              <span class="flex"></span>
            </div>
            <slick-fab mini .extended="${!x}" icon="search" label="${Ze.phrase("search")}" @click="${this.exitListToSearch}"></slick-fab>
          </div>
        </section>

        <main 
          @nav="${this.onNav}"
          @search-more="${this.onSearchMore}"
          @search-drill="${this.onSearchDrill}">

          ${xs(b,(e=>Yo(e)),(e=>{var t;return"ad-slot"===e.style?Lt`<slot name="${`search-slot-${e.title}`}"></slot>`:Lt`
        <slick-search-group 
          .descriptors="${(null===(t=this._results)||void 0===t?void 0:t.itemDescriptors)||{}}" 
          .group="${e}"
          .drillUrl="${this.createUrlHashForGroupDrill(e)}"
          .showIcon="${S}"
          .favIcon="${this._favIcon}">
        </slick-search-group>
        `}))}

          ${$?Lt`<div id="noresults">${C}</div>`:""}
          
        </main>
      </div>
    </div>
    `}firstUpdated(){if(document.addEventListener("slick-show-search",this.openListener),document.addEventListener("slick-show-discovery",this.openListener),this.shell&&this.shell.addEventListener("scroll",(()=>this.handleScroll()),{passive:!0}),window.addEventListener("resize",(()=>this.onWindowResize()),{passive:!0}),e.subscribe("route",this.handleHashChange),0===window.location.hash.indexOf("#search")){const e=Se.getHashRoute();this.handleHashChange(e)}const t=()=>{this._offline="online"!==Ze.sessionConnectionState,this._offlineUpdateTimer&&(window.clearTimeout(this._offlineUpdateTimer),this._offlineUpdateTimer=0),this._offline?this._offlineUpdateTimer=window.setTimeout((()=>{this._showOffline=this._offline}),5e3):this._showOffline=this._offline};e.subscribe("session-offline",t),e.subscribe("session-updated",t),e.subscribe("membership-updated",(async()=>{const e=await B();await e.deleteLastSearch()})),t(),this.onWindowResize()}updated(e){var t;if(e.has("settings")&&this.settings){this._favIcon=this.settings.heartbeatIcon.iconType;const e=null===(t=this.settings.discovery)||void 0===t?void 0:t.maxWidth;e?this.style.setProperty("--slick-discovery-content-max-width",`${e}px`):this.style.removeProperty("--slick-discovery-content-max-width"),this.onWindowResize()}}onWindowResize(){if(this.mainPanel){const e=this.mainPanel.getBoundingClientRect().width;e!==this._mainWidth&&(this._mainWidth=e)}}getPanelWidth(){return this._mainWidth||this.onWindowResize(),this._mainWidth||window.innerWidth}currentUrlPath(){return`${window.location.origin}${window.location.pathname}`}async searchFromHashChange(e,t){this.clearTimers();const i=this._open;this.show(),this.setInputValue(e||"");const s=()=>{this._open&&!this._listMode&&setTimeout((()=>{this._open&&this.setFocus()}),300)},o=this._preventCachedScrolling;this._preventCachedScrolling=!1;const n=!i&&!this.disableCachedResults;if(n){const i=await B(),n=await i.getLastSearch(this.currentUrlPath());if(n){if(t?n.group===t:n.q===e&&n.context===this._drillContext&&!n.group){this.updateResults(n.response),await this.updateComplete;return(n.scrollOffset||0)&&!o?setTimeout((()=>{this.shell&&(this.shell.scrollTop=n.scrollOffset||0)}),100):s(),void O("search-panel","info",`Using cached results, q="${e}"`,this._results)}}}setTimeout((()=>{s(),this.fullSearch("start",!0,t)}),n?0:300)}close(){Date.now()-this._lastOpenTime<500||(this.clearTimers(),this._open&&(this._query&&this.updateUrlHash(!1),Ze.goto("")))}async show(){this._open||(document.dispatchEvent(new Event("slick-search-panel-show")),this._oflows=[document.body.style.overflow||"",document.documentElement.style.overflow||""],document.body.style.overflow="hidden",document.documentElement.style.overflow="hidden",document.body.classList.add(pr),document.documentElement.classList.add(pr),this._open=!0,this._lastOpenTime=Date.now(),await this.updateComplete,function(){if("boolean"==typeof mi)return mi;let e=!1;try{const t=document.createElement("div");t.addEventListener("focus",(e=>{e.preventDefault(),e.stopPropagation()})),t.focus(Object.defineProperty({},"preventScroll",{get:()=>{e=!(navigator&&void 0!==navigator.userAgent&&navigator.userAgent&&navigator.userAgent.match(/Edge\/1[7-8]/))}}))}catch(e){}return mi=e,e}()&&this.setFocus(),yi())}_focus(){this.searchInput&&this.searchInput.focus({preventScroll:!0})}setFocus(){this.searchInput&&!this._mobile&&this.searchInput.focus({preventScroll:!0})}hide(){this._open&&(document.dispatchEvent(new Event("slick-search-panel-hide")),this.clearTimers(),this._open=!1,setTimeout((()=>{this._open||(this._results=void 0,this._query="",document.body.classList.remove(pr),document.documentElement.classList.remove(pr),document.body.style.overflow=this._oflows[0]||"",document.documentElement.style.overflow=this._oflows[1]||"",this.shell&&(this.shell.scrollTop=0))}),300),e.dispatch("search-panel-closed"))}handleScroll(){var e;const t=(null===(e=this.searchSection)||void 0===e?void 0:e.getBoundingClientRect().top)||0,i=t<-56;i!==this._stickyHeader&&(this._stickyHeader=i);const s=t<=0;s!==this._solidBg&&(this._solidBg=s)}scrollToSearchAndSelect(){this.scrollToSearch(!0)}scrollToSearch(e){this.searchSection&&(this.searchSection.scrollIntoView(!0),this.searchInput&&(this.setFocus(),e&&!this._mobile&&this.searchInput.select()))}clearTimers(){this._urlHashUpdateTimer&&(window.clearTimeout(this._urlHashUpdateTimer),this._urlHashUpdateTimer=0),this.stopMoreOnIdleTimer()}async fastSearch(){return this.clearTimers(),this._search(!1,"type")}async fullSearch(e,t,i){this.stopMoreOnIdleTimer(),this._search(!0,e,i,t)}async _search(e,t,i,s){var o;this._searchEpoch++;const n=this._searchEpoch;if(this._query=((null===(o=this.searchInput)||void 0===o?void 0:o.value)||"").trim(),!e&&!this._query)return!1;this._query.length>100&&(this._query=this._query.substring(0,100),this.searchInput&&(this.searchInput.value=this._query));const r=e?await Ze.fullSearch(dr,this._query,this.getPanelWidth(),window.innerHeight,t,this._drillContext,i,this._arrangement):await Ze.fastSearch(dr,this._query,this.getPanelWidth(),window.innerHeight,this._drillContext);return n===this._searchEpoch&&(this.updateResults(r),e&&O("search-panel","info","Full search results",r),s&&this.saveSearchResults(),e&&this.searchSection&&this.searchSection.getBoundingClientRect().top<0&&this.scrollToSearch(!1),!0)}onSearchMore(e){const{group:t,groupUI:i}=e.detail;t&&i&&this.fetchMoreInGroup(t,i)}async fetchMoreInGroup(e,t){if(e.moreContext){this._searchEpoch++;const i=this._searchEpoch,s=await Ze.fetchMoreSearchResults(e.moreContext,this.getPanelWidth(),window.innerHeight);if(this._results&&i===this._searchEpoch){for(const e of Object.keys(s.itemDescriptors))this._results.itemDescriptors[+e]=s.itemDescriptors[+e];e.pageIds.push(...s.pageIds),e.moreContext=s.moreContext,s.imageContainmentOverrides&&(e.imageContainmentOverrides?Object.assign(e.imageContainmentOverrides,s.imageContainmentOverrides):e.imageContainmentOverrides=s.imageContainmentOverrides),s.aspectRatioOverrides&&(e.aspectRatioOverrides?Object.assign(e.aspectRatioOverrides,s.aspectRatioOverrides):e.aspectRatioOverrides=s.aspectRatioOverrides),t.refresh(),this.saveSearchResults()}}}updateResults(e){var t;if(this._results=e,this._arrangement=e.arrangement,this._listMode="context-without-search"===e.arrangement,"string"==typeof e.updatedSearchString&&this.searchInput){const i=e.updatedSearchString.trim();i!==((null===(t=this.searchInput)||void 0===t?void 0:t.value)||"")&&(this.setInputValue(e.updatedSearchString.trim()),this._query=i||"",this.updateUrlHash(!1,!0))}}stopMoreOnIdleTimer(){this._moreOnIdleTimer&&(window.clearTimeout(this._moreOnIdleTimer),this._moreOnIdleTimer=0)}startMoreOnIdleTimer(){this.stopMoreOnIdleTimer(),this._moreOnIdleTimer=window.setTimeout((()=>{this._moreOnIdleTimer=0,this.fullSearch("type",!1)}),1e3)}clearSearchText(){this.searchInput&&(this.clearTimers(),this.setInputValue(""),this.fullSearch("clear-search",!1),this.setFocus(),this.updateUrlHash(!1))}onTextKeyDown(e){var t;e.stopPropagation();const i=(null===(t=this.searchInput)||void 0===t?void 0:t.value)||"";switch(e.key){case"Esc":case"Escape":e.stopPropagation(),e.preventDefault(),i?setTimeout((()=>{this.clearSearchText()})):this.close();break;case"Enter":case"Return":case"Backspace":case"Clear":case"Delete":case"Paste":case"Undo":case"Redo":case"Cut":case" ":case"ArrowLeft":case"ArrowRight":case"ArrowUp":case"ArrowDown":case"END":case"HOME":break;default:{if(e.shiftKey||e.metaKey||e.ctrlKey||e.altKey)break;const t=i.split(" ");t[t.length-1].length>=32&&e.preventDefault();break}}}async onTextInput(){this.searchText(),this.updateInputIcon()}setInputValue(e){this.searchInput&&(this.searchInput.value=e,this.updateInputIcon())}onSearchInputFocus(){this._mobile&&window.setTimeout((()=>{this.onSearchInputClick()}),300)}onSearchInputClick(){this._mobile&&this.shell&&(this.shell.scrollTop=58)}updateInputIcon(){var e;const t=(null===(e=this.searchInput)||void 0===e?void 0:e.value)||"";this._searchInputIcon=t?"close":"search"}async searchText(){if(this.clearTimers(),this._pendingTextSearch)this._dirtyText=!0;else try{this._pendingTextSearch=this.fastSearch(),await this._pendingTextSearch,this._pendingTextSearch=void 0,this._dirtyText?(this._dirtyText=!1,this.searchText()):(this.clearTimers(),this._urlHashUpdateTimer=window.setTimeout((()=>{this.updateUrlHash(!1)}),1500),this.startMoreOnIdleTimer())}finally{this._dirtyText=!1,this._pendingTextSearch=void 0}}createUrlHashForGroupDrill(e){if(e.drillContext){const t=this._query?{q:this._query}:{};return t[hr]=e.drillContext,Ze.computeHashUrl("search",t)}}updateUrlHash(e,t=!1){if(e||this._hashQuery!==this._query){const i=t||this._query&&!this._hashQuery||this._hashQuery&&this._query&&(0===this._query.indexOf(this._hashQuery)||0===this._hashQuery.indexOf(this._query));let s=this._query?{q:this._query}:void 0;this._drillContext&&(s=s||{},s[hr]=this._drillContext,this._arrangement&&(s.a=this._arrangement)),i&&!e?Ze.replaceHash("search",s):Ze.pushHash("search",s),this._hashQuery=this._query}}onNav(e){this.clearTimers(),this.updateUrlHash(!1);const{anchor:t,href:i}=e.detail;if(i){Ze.widgetAction(dr,"nav",0,i,void 0,{query:this._query}),Ze.reportGAEvent("search-click","Slickstream search result clicked");try{const e=new URL(i);e.host===window.location.host&&e.pathname===window.location.pathname&&this.hide()}catch(e){}}const s=t&&t.getAttribute("href");s&&0===s.indexOf("#")||this.saveSearchResults()}async saveSearchResults(){var e;if(this._results&&!this.disableCachedResults){const t=null===(e=this.shell)||void 0===e?void 0:e.scrollTop,i=JSON.parse(JSON.stringify(this._results)),s=this._query,o=this._drillContext,n=this._groupType,r=await B();O("search-panel","info","Caching search results",{q:s,c:o,g:n}),await r.setLastSearch(this.currentUrlPath(),i,s,o,n,t)}}async onSearchDrill(e){const t=e.detail;t&&t.drillContext&&await this.updateDrillContext("select-group",t.drillContext)}async clearDrillContext(){await this.updateDrillContext("clear-group"),setTimeout((()=>{this.searchInput&&this._open&&this.setFocus()}),500)}resetSearch(){this.setInputValue(""),this._query="",this._hashQuery="",this._drillContext=void 0,this._arrangement=void 0,this.fullSearch("clear-search",!1),Ze.pushHash("search",{})}exitListToSearch(){var e;const t=this._query||this._hashQuery||"",i={};t&&(i.q=t),this.setInputValue(this._query||this._hashQuery||""),(null===(e=this._results)||void 0===e?void 0:e.drillContext)?(this._drillContext=this._results.drillContext,this._arrangement="context-with-search",i[hr]=this._results.drillContext,i.a="context-with-search"):(this._drillContext=void 0,this._arrangement=void 0),this.fullSearch("clear-group",!1),Ze.pushHash("search",i)}async updateDrillContext(e,t){this._drillContext!==t&&(await this.saveSearchResults(),this._drillContext=t,this._arrangement=void 0,this.updateUrlHash(!0),this.fullSearch(e,!1))}signInAndFav(e){var t;const i=null===(t=e.detail)||void 0===t?void 0:t.pageId;Ze.membershipService.memberSignin(i)}signOut(){const e=Ze.currentSession;e&&(this.deleteMemberDialog||(this.deleteMemberDialog=new Ro,this.deleteMemberDialog.addEventListener("update",(()=>{Ze.goto(["list","my-favorites"])}))),this.deleteMemberDialog.deleteMessage=e.settings.membership.deleteAccountMessage||"",this.deleteMemberDialog.show())}};lr([oi({type:Object}),cr("design:type",Object)],ur.prototype,"settings",void 0),lr([oi({type:Boolean}),cr("design:type",Object)],ur.prototype,"disableCachedResults",void 0),lr([ni(),cr("design:type",Object)],ur.prototype,"_open",void 0),lr([ni(),cr("design:type",Object)],ur.prototype,"_stickyHeader",void 0),lr([ni(),cr("design:type",Object)],ur.prototype,"_solidBg",void 0),lr([ni(),cr("design:type",Object)],ur.prototype,"_results",void 0),lr([ni(),cr("design:type",Object)],ur.prototype,"_query",void 0),lr([ni(),cr("design:type",Object)],ur.prototype,"_searchInputIcon",void 0),lr([ni(),cr("design:type",Object)],ur.prototype,"_showOffline",void 0),lr([ni(),cr("design:type",String)],ur.prototype,"_favIcon",void 0),lr([ai("#shell"),cr("design:type",HTMLElement)],ur.prototype,"shell",void 0),lr([ai("#searchSection"),cr("design:type",HTMLElement)],ur.prototype,"searchSection",void 0),lr([ai("#searchInput"),cr("design:type",HTMLInputElement)],ur.prototype,"searchInput",void 0),lr([ai("main"),cr("design:type",HTMLElement)],ur.prototype,"mainPanel",void 0),ur=lr([ii("slick-search-panel")],ur);class gr{constructor(e){this.lastSearchTimestamp=0,this.hookedElements=new Set,this.handler=e=>this.openSearch(e),this.keeyHandler=e=>this.handleKeyDown(e),this.config=e}async detach(){for(const e of this.hookedElements)e.removeEventListener("click",this.handler,!0),e.removeEventListener("mousedown",this.handler),e.removeEventListener("touchend",this.handler),e.removeEventListener("keydown",this.keeyHandler);this.hookedElements.clear()}async attach(){this.detach();const e=(this.config.selectors||[]).map((e=>this.processSelector(e)));return Promise.all(e)}async processSelector(e){if(e){let t=null;try{t=await vi(e,5e3)}catch(e){}t&&t.length&&t.forEach((e=>{e.addEventListener("click",this.handler,!0),e.addEventListener("mousedown",this.handler),e.addEventListener("touchend",this.handler),e.addEventListener("keydown",this.keeyHandler),this.hookedElements.add(e)}))}}handleKeyDown(e){const t=e.keyCode;(13===t||32===t||t>=48&&t<=57||t>=65&&t<=90)&&this.openSearch(e,e.key)}openSearch(e,t){((e.currentTarget||e.target).href||"").indexOf("#slick-search-")>=0||(e.preventDefault(),e.stopPropagation(),setTimeout((()=>{const e=Date.now();e-this.lastSearchTimestamp>1e3&&(Ze.widgetAction("search-hook","open-search",0),document.dispatchEvent(ui("slick-show-search",{key:t}))),this.lastSearchTimestamp=e,Ze.reportGAEvent("search-hook","Site button hooked by Slickstream")}),100))}}var fr=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},vr=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const mr="inline-search";let yr=class extends Ds{constructor(){super(...arguments),this._searchInputIcon="search",this._mobile=!1,this._searchEpoch=0,this._moreOnIdleTimer=0,this._dirtyText=!1,this._containerWidth=0,this._activated=!1}render(){var e,t,i,s,o,n;if(!this.config||!this.settings)return Lt``;const r=(null===(e=this._results)||void 0===e?void 0:e.groups)||[],a=this.config.searchPlaceholderText||(null===(i=null===(t=this.settings)||void 0===t?void 0:t.discovery)||void 0===i?void 0:i.searchBoxPlaceholderText)||Ze.phrase("search-text")||"search text",l=this.config.maxWidth?`max-width: ${this.config.maxWidth}px`:"",c=!(!this._results||0!==r.length||!((null===(s=this.searchInput)||void 0===s?void 0:s.value)||"").trim()),h=this.settings.heartbeatIcon.iconType,d=(null===(n=null===(o=this.settings)||void 0===o?void 0:o.discovery)||void 0===n?void 0:n.noMatchesText)||Ze.phrase("no-matches-found")||"No matches found",p=this.config.hideSearchBox||!1,u=this.config.hideShowMoreButton||!1,g=0===r.length&&!c;return Lt`
    <style>
      :host {
        display: block;
      }
      #container {
        margin: 0 auto;
      }
      #searchPanel {
        border-radius: var(--slick-inline-search-border-radius, 24px);
        padding: 0 16px 0 0;
        position: relative;
        border: var(--slick-inline-search-border, 1px solid #e5e5e5);
        background: var(--slick-inline-search-input-background, #ffffff);
      }
      #searchInput {
        border: none;
        width: 100%;
        background: none;
        display: block;
        line-height: var(--slick-inline-search-input-height, 40px);
        font-size: var(--slick-inline-search-input-font-size, 14px);
        padding: var(--slick-inline-search-input-padding, 0 16px);
        outline: none;
        font-family: var(--slick-inline-search-input-font, ${Fs});
        font-weight: var(--slick-inline-search-input-font-weight, inherit);
        color: var(--slick-inline-search-input-color, #555);
      }
      #searchInput::placeholder {
        color: var(--slick-inline-search-placeholder-color, #808080);
      }
      #searchInputIcon {
        cursor: pointer;
      }
      #searchPanel soso-icon {
        color: var(--slick-inline-search-input-icon-color, var(--slick-discovery-highlight-color, #555));
      }
      main {
        display: block;
        padding: 16px 0;
      }
      #noresults {
        padding: 32px 16px;
        text-align: center;
        font-size: 14px;
        color: var(--slick-inline-search-noresults-color, #808080);
        letter-spacing: 0.5px;
      }
      soso-button {
        color: var(--slick-inline-search-pop-button-color, var(--slick-discovery-highlight-color, #2196f3));
        margin-left: 4px;
      }
      #showAllLabel {
        margin-left: 4px;
      }
      #showAllLabel.mobile {
        margin: 0;
        padding: 0;
        height: 0;
        width: 0;
        overflow: hidden;
      }
    </style>
    <style mobile>
      @media (max-width: 600px) {
        #searchInput {
          font-size: var(--slick-inline-search-input-font-size, 16px);
        }
        soso-button soso-icon {
          margin-right: 0;
        }
      }
    </style>
    <style rtl>
      :host([dir="rtl"]) #searchPanel {
        padding: 0 0 0 16px;
      }
    </style>
    <div id="container" style="${l}">
      <div><slot></slot></div>
      <div id="searchSection" class="horizontal center" ?hidden="${p}">
        <div id="searchPanel" class="flex horizontal center">
          <div class="flex">
            <input id="searchInput" 
              aria-label="Enter search text here and the search results will be automatically updated as you type" 
              autocomplete="off" 
              spellcheck="false" 
              placeholder="${a}"
              @input="${this.onTextInput}"
              @keydown="${this.onTextKeyDown}">
          </div>
          <soso-icon id="searchInputIcon" .icon="${this._searchInputIcon}" @click="${this.clearSearchText}"></soso-icon>
        </div>
        <soso-button ?hidden="${u}" @click="${this.popSearchPanel}" title="${Ze.phrase("show-all")}">
          <div class="horizontal center">
            <soso-icon icon="open-panel"></soso-icon>
            <span id="showAllLabel" class="${this._mobile?"mobile":""}">${Ze.phrase("show-all")}</span>
          </div>
        </soso-button>
      </div>

      <main 
        ?hidden="${g}"
        @nav="${this.onNav}"
        @search-more="${this.onSearchMore}"
        @search-drill="${this.onSearchDrill}"
        @search-show-all="${this.popSearchPanel}">

        ${xs(r,(e=>Yo(e)),(e=>{var t;return"ad-slot"===e.style?Lt`<slot name="${`search-slot-${e.title}`}"></slot>`:Lt`
      <slick-search-group 
        .descriptors="${(null===(t=this._results)||void 0===t?void 0:t.itemDescriptors)||{}}" 
        .group="${e}"
        .favIcon="${h}">
      </slick-search-group>
      `}))}

        ${c?Lt`<div id="noresults">${d}</div>`:""}
        
      </main>
    </div>
    `}firstUpdated(){window.addEventListener("resize",(()=>this.onWindowResize()),{passive:!0}),this.onWindowResize()}updated(e){(e.has("settings")||e.has("config"))&&(this.onWindowResize(),this.refresh())}async refresh(){const t=async()=>{await this._refresh(),this.attachIntersectionObserver()};Ze.currentSession?await t():e.subscribe("session-established",(()=>{t()}))}async _refresh(){this.config&&this.settings&&(this._activated||this.config.doNotDelayInitialSearch)&&(this.setInputValue(""),this._search(!0,"start"))}async fastSearch(){return this.stopMoreOnIdleTimer(),this._search(!1,"type")}async fullSearch(e){this.stopMoreOnIdleTimer(),this._search(!0,e)}async _search(e,t){var i,s,o;this._searchEpoch++;const n=this._searchEpoch;let r=((null===(i=this.searchInput)||void 0===i?void 0:i.value)||"").trim();if(r.length>100&&(r=r.substring(0,100),this.setInputValue(r)),!e&&!r)return!1;const a=e?await Ze.fullSearch(mr,r,this.getPanelWidth(),window.innerHeight,t,void 0,void 0,void 0,null===(s=this.config)||void 0===s?void 0:s.id):await Ze.fastSearch(mr,r,this.getPanelWidth(),window.innerHeight,void 0,void 0,null===(o=this.config)||void 0===o?void 0:o.id);return n===this._searchEpoch&&(await this.updateResults(a),e&&O("inline-search","info","Inline search full results",a),!0)}onWindowResize(){if(this._container){const e=this._container.getBoundingClientRect().width;e!==this._containerWidth&&(this._containerWidth=e),this._mobile=e<=600}}getPanelWidth(){return this._containerWidth||this.onWindowResize(),this._containerWidth||window.innerWidth}async updateResults(e){const t=await Ze.getTheme();for(const i of e.groups)if(i.template){const e=i.template.id;i.templateId=e,t&&(t.templatesById[e]||(t.templatesById[e]={htmlTemplate:i.template.htmlTemplate}))}this._results=e,this._hiddenQueryString=e.updatedSearchString||void 0}setInputValue(e){this.searchInput&&(this.searchInput.value=e,this.updateInputIcon())}updateInputIcon(){var e;const t=(null===(e=this.searchInput)||void 0===e?void 0:e.value)||"";this._searchInputIcon=t?"close":"search"}attachIntersectionObserver(){if(!this._intersectionObserver)if("IntersectionObserver"in window){const e=e=>{var t;const i=e[0];i&&i.isIntersecting&&i.intersectionRatio>.5&&(Ze.widgetAction(mr,"impression",0),null===(t=this._intersectionObserver)||void 0===t||t.unobserve(this),this._activated=!0,this.refresh())},t={threshold:[0,1]};this._intersectionObserver=new IntersectionObserver(e,t),this._intersectionObserver.observe(this)}else this._intersectionObserver={},Ze.widgetAction(mr,"impression",0)}clearSearchText(){this.searchInput&&(this.stopMoreOnIdleTimer(),this.setInputValue(""),this.fullSearch("clear-search"),this.setFocus())}setFocus(){this.searchInput&&this.searchInput.focus({preventScroll:!0})}onTextKeyDown(e){var t;e.stopPropagation();const i=(null===(t=this.searchInput)||void 0===t?void 0:t.value)||"";switch(e.key){case"Esc":case"Escape":e.stopPropagation(),e.preventDefault(),i&&setTimeout((()=>{this.clearSearchText()}))}}async onTextInput(){this.searchText(),this.updateInputIcon()}async searchText(){if(this.stopMoreOnIdleTimer(),this._pendingTextSearch)this._dirtyText=!0;else try{this._pendingTextSearch=this.fastSearch(),await this._pendingTextSearch,this._pendingTextSearch=void 0,this._dirtyText?(this._dirtyText=!1,this.searchText()):this.startMoreOnIdleTimer()}finally{this._dirtyText=!1,this._pendingTextSearch=void 0}}stopMoreOnIdleTimer(){this._moreOnIdleTimer&&(window.clearTimeout(this._moreOnIdleTimer),this._moreOnIdleTimer=0)}startMoreOnIdleTimer(){this.stopMoreOnIdleTimer(),this._moreOnIdleTimer=window.setTimeout((()=>{this._moreOnIdleTimer=0,this.fullSearch("type")}),1e3)}async onSearchDrill(e){var t;const i=e.detail;if(i&&i.drillContext){const e={c:i.drillContext},s=((null===(t=this.searchInput)||void 0===t?void 0:t.value)||"").trim();s&&(e.q=s),Ze.gotoWithParams("search",e)}}onSearchMore(e){const{group:t,groupUI:i}=e.detail;t&&i&&this.fetchMoreInGroup(t,i)}async fetchMoreInGroup(e,t){if(e.moreContext){this._searchEpoch++;const i=this._searchEpoch,s=await Ze.fetchMoreSearchResults(e.moreContext,this.getPanelWidth(),window.innerHeight);if(this._results&&i===this._searchEpoch){for(const e of Object.keys(s.itemDescriptors))this._results.itemDescriptors[+e]=s.itemDescriptors[+e];e.pageIds.push(...s.pageIds),e.moreContext=s.moreContext,s.imageContainmentOverrides&&(e.imageContainmentOverrides?Object.assign(e.imageContainmentOverrides,s.imageContainmentOverrides):e.imageContainmentOverrides=s.imageContainmentOverrides),s.aspectRatioOverrides&&(e.aspectRatioOverrides?Object.assign(e.aspectRatioOverrides,s.aspectRatioOverrides):e.aspectRatioOverrides=s.aspectRatioOverrides),t.refresh()}}}onNav(e){var t;this.stopMoreOnIdleTimer();const{anchor:i,href:s}=e.detail;if(s){Ze.widgetAction(mr,"nav",0,s,void 0,{query:(null===(t=this.searchInput)||void 0===t?void 0:t.value)||""}),Ze.reportGAEvent("search-click","Slickstream search result clicked");try{const e=new URL(s);if(e.host===window.location.host&&e.pathname===window.location.pathname)return}catch(e){}const e=i&&i.getAttribute("href");if(e&&0===e.indexOf("#"))return}}createSearchParams(){var e,t;const i={},s=((null===(e=this.searchInput)||void 0===e?void 0:e.value)||this._hiddenQueryString||"").trim();s&&(i.q=s);const o=null===(t=this._results)||void 0===t?void 0:t.drillContext;return o&&(i.c=o),i}popSearchPanel(){Ze.gotoWithParams("search",this.createSearchParams())}};fr([oi({type:Object}),vr("design:type",Object)],yr.prototype,"settings",void 0),fr([oi({type:Object}),vr("design:type",Object)],yr.prototype,"config",void 0),fr([ni(),vr("design:type",Object)],yr.prototype,"_results",void 0),fr([ni(),vr("design:type",Object)],yr.prototype,"_searchInputIcon",void 0),fr([ni(),vr("design:type",Object)],yr.prototype,"_mobile",void 0),fr([ai("#searchInput"),vr("design:type",HTMLInputElement)],yr.prototype,"searchInput",void 0),fr([ai("#container"),vr("design:type",HTMLElement)],yr.prototype,"_container",void 0),yr=fr([ii("slick-inline-search")],yr);var br=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},wr=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const xr="search-box",kr="_searchbox";let Sr=class extends Ds{constructor(){super(...arguments),this._searchInputIcon="search",this._searchEpoch=0,this._dirtyText=!1,this._containerWidth=0,this._moreOnIdleTimer=0}attachInput(e){this._attachedSearchInput=e}getInputText(){return this._attachedSearchInput?this._attachedSearchInput.value||"":this._searchInput&&this._searchInput.value||""}render(){var e,t,i,s,o;if(!this.settings)return Lt``;const n=(null===(e=this._results)||void 0===e?void 0:e.groups)||[],r=(null===(i=null===(t=this.settings)||void 0===t?void 0:t.discovery)||void 0===i?void 0:i.searchBoxPlaceholderText)||Ze.phrase("search-text")||"search text",a=!(!this._results||0!==n.length||!this.getInputText().trim()),l=this.settings.heartbeatIcon.iconType,c=(null===(o=null===(s=this.settings)||void 0===s?void 0:s.discovery)||void 0===o?void 0:o.noMatchesText)||Ze.phrase("no-matches-found")||"No matches found",h=0===n.length&&!a;return Lt`
    <style>
      :host {
        display: block;
        --slick-i-template-cell-outline: 1px solid var(--slick-discovery-highlight-color, #000);
      }
      #container {
        margin: 0 auto;
        position: relative;
      }
      #searchPanel {
        border-radius: var(--slick-inline-search-border-radius, 24px);
        padding: 0 16px 0 0;
        position: relative;
        border: var(--slick-inline-search-border, 1px solid #e5e5e5);
        background: var(--slick-inline-search-input-background, #ffffff);
      }
      #searchInput {
        border: none;
        width: 100%;
        background: none;
        display: block;
        line-height: var(--slick-inline-search-input-height, 40px);
        font-size: var(--slick-inline-search-input-font-size, 14px);
        padding: var(--slick-inline-search-input-padding, 0 16px);
        outline: none;
        font-family: var(--slick-inline-search-input-font, ${Fs});
        font-weight: var(--slick-inline-search-input-font-weight, inherit);
        color: var(--slick-inline-search-input-color, #555);
      }
      #searchInput::placeholder {
        color: var(--slick-inline-search-placeholder-color, #808080);
      }
      #searchInputIcon {
        cursor: pointer;
      }
      #searchPanel soso-icon {
        color: var(--slick-inline-search-input-icon-color, var(--slick-discovery-highlight-color, #555));
      }
      main {
        display: block;
        background: var(--slick-searchbox-overlay-bg, white);
        color: var(--slick-searchbox-overlay-color, inherit);
        padding: 0;
        position: absolute;
        opacity: 1;
        width: 100%;
        box-shadow: var(--slick-searchbox-overlay-shadow, 0 3px 3px -2px rgb(0 0 0 / 20%), 0 3px 4px 0 rgb(0 0 0 / 14%), 0 1px 8px 0 rgb(0 0 0 / 12%));
        z-index: 1;
      }
      slick-search-group {
        padding: 0;
      }
      #noresults {
        padding: 32px 16px;
        text-align: center;
        font-size: 14px;
        color: var(--slick-inline-search-noresults-color, #808080);
        letter-spacing: 0.5px;
      }
    </style>
    <style mobile>
      @media (max-width: 600px) {
        #searchInput {
          font-size: var(--slick-inline-search-input-font-size, 16px);
        }
      }
    </style>
    <style rtl>
      :host([dir="rtl"]) #searchPanel {
        padding: 0 0 0 16px;
      }
    </style>
    <div id="container">
      <div id="searchSection" ?hidden="${!!this._attachedSearchInput}">
        <div id="searchPanel" class="horizontal center">
          <div class="flex">
            <input id="searchInput" 
              aria-label="Enter search text here and the search results will be automatically updated as you type" 
              autocomplete="off" 
              spellcheck="false" 
              placeholder="${r}"
              @input="${this.onTextInput}"
              @keydown="${this.onTextKeyDown}">
          </div>
          <soso-icon id="searchInputIcon" .icon="${this._searchInputIcon}" @click="${this.clearSearchText}"></soso-icon>
        </div>
      </div>

      <main 
        ?hidden="${h}"
        @nav="${this.onNav}"
        @key-escape="${this.clearSearchText}"
        @search-show-all="${this.popSearchPanel}">

        ${xs(n,(e=>Yo(e)),(e=>{var t;return"ad-slot"===e.style?Lt``:Lt`
      <slick-search-group 
        .descriptors="${(null===(t=this._results)||void 0===t?void 0:t.itemDescriptors)||{}}" 
        .group="${e}"
        .favIcon="${l}">
      </slick-search-group>
      `}))}

        ${a?Lt`<div id="noresults">${c}</div>`:""}
        
      </main>
    </div>
    `}firstUpdated(){if(this._attachedSearchInput){this._attachedSearchInput.addEventListener("input",(()=>this.onTextInput())),this._attachedSearchInput.addEventListener("keydown",(e=>this.onTextKeyDown(e)));let e=this._attachedSearchInput.parentElement;for(;e;){if("form"===e.tagName.toLowerCase()){e.addEventListener("submit",(e=>{e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),setTimeout((()=>{this.popSearchPanel()}))}));break}e=e.parentElement}}window.addEventListener("resize",(()=>this.onWindowResize()),{passive:!0}),this.onWindowResize()}updated(e){e.has("settings")&&(this.onWindowResize(),this.refresh())}async refresh(){const t=async()=>{await this._refresh(),this.attachIntersectionObserver()};Ze.currentSession?await t():e.subscribe("session-established",(()=>{t()}))}async _refresh(){this.settings&&this.setInputValue("")}stopMoreOnIdleTimer(){this._moreOnIdleTimer&&(window.clearTimeout(this._moreOnIdleTimer),this._moreOnIdleTimer=0)}startMoreOnIdleTimer(){this.stopMoreOnIdleTimer(),this._moreOnIdleTimer=window.setTimeout((()=>{this._moreOnIdleTimer=0,this.fullSearch("type")}),1e3)}async fullSearch(e){this.stopMoreOnIdleTimer(),this._search(!0,e)}async fastSearch(){return this.stopMoreOnIdleTimer(),this._search(!1,"type")}async _search(e,t){this._searchEpoch++;const i=this._searchEpoch;let s=this.getInputText().trim();if(s.length>100&&(s=s.substring(0,100),this.setInputValue(s)),!s)return this.clearSearchText(),!1;const o=e?await Ze.fullSearch(xr,s,this.getPanelWidth(),window.innerHeight,t,void 0,void 0,void 0,kr):await Ze.fastSearch(xr,s,this.getPanelWidth(),window.innerHeight,void 0,void 0,kr);return i===this._searchEpoch&&(await this.updateResults(o),!0)}onWindowResize(){if(this._container){const e=this._container.getBoundingClientRect().width;e!==this._containerWidth&&(this._containerWidth=e)}}getPanelWidth(){return this._containerWidth||this.onWindowResize(),this._containerWidth||window.innerWidth}async updateResults(e){const t=await Ze.getTheme();for(const i of e.groups)if(i.template){const e=i.template.id;i.templateId=e,t&&(t.templatesById[e]||(t.templatesById[e]={htmlTemplate:i.template.htmlTemplate}))}this._results=e,this._hiddenQueryString=e.updatedSearchString||void 0}setInputValue(e){this._attachedSearchInput?this._attachedSearchInput.value=e:this._searchInput&&(this._searchInput.value=e,this.updateInputIcon())}updateInputIcon(){const e=this.getInputText();this._searchInputIcon=e?"close":"search"}attachIntersectionObserver(){if(!this._intersectionObserver)if("IntersectionObserver"in window){const e=e=>{var t;const i=e[0];i&&i.isIntersecting&&i.intersectionRatio>.5&&(Ze.widgetAction(xr,"impression",0),null===(t=this._intersectionObserver)||void 0===t||t.unobserve(this),this.refresh())},t={threshold:[0,1]};this._intersectionObserver=new IntersectionObserver(e,t),this._intersectionObserver.observe(this)}else this._intersectionObserver={},Ze.widgetAction(xr,"impression",0)}clearSearchText(){this.stopMoreOnIdleTimer(),this.setInputValue(""),this._results=void 0,this.setFocus()}setFocus(){const e=this._attachedSearchInput||this._searchInput;e&&e.focus({preventScroll:!0})}onTextKeyDown(e){e.stopPropagation();const t=this.getInputText();switch(e.key){case"Enter":case"Return":e.preventDefault(),setTimeout((()=>{this.popSearchPanel()}));break;case"ArrowDown":e.preventDefault(),setTimeout((()=>{this._searchGroup&&this._searchGroup.focus()}));break;case"Esc":case"Escape":e.preventDefault(),t&&setTimeout((()=>{this.clearSearchText()}))}}async onTextInput(){this.searchText(),this.updateInputIcon()}async searchText(){if(this.stopMoreOnIdleTimer(),this._pendingTextSearch)this._dirtyText=!0;else try{this._pendingTextSearch=this.fastSearch(),await this._pendingTextSearch,this._pendingTextSearch=void 0,this._dirtyText?(this._dirtyText=!1,this.searchText()):this.startMoreOnIdleTimer()}finally{this._dirtyText=!1,this._pendingTextSearch=void 0}}onNav(e){this.stopMoreOnIdleTimer();const{anchor:t,href:i}=e.detail;if(i){Ze.widgetAction(xr,"nav",0,i,void 0,{query:this.getInputText()}),Ze.reportGAEvent("search-click","Slickstream search result clicked");try{const e=new URL(i);if(e.host===window.location.host&&e.pathname===window.location.pathname)return}catch(e){}const e=t&&t.getAttribute("href");if(e&&0===e.indexOf("#"))return}}createSearchParams(){var e;const t={},i=(this.getInputText()||this._hiddenQueryString||"").trim();i&&(t.q=i);const s=null===(e=this._results)||void 0===e?void 0:e.drillContext;return s&&(t.c=s),t}popSearchPanel(){Ze.gotoWithParams("search",this.createSearchParams()),this.clearSearchText()}};br([ni(),wr("design:type",Object)],Sr.prototype,"settings",void 0),br([ni(),wr("design:type",Object)],Sr.prototype,"_results",void 0),br([ni(),wr("design:type",Object)],Sr.prototype,"_searchInputIcon",void 0),br([ni(),wr("design:type",HTMLInputElement)],Sr.prototype,"_attachedSearchInput",void 0),br([ai("#searchInput"),wr("design:type",HTMLInputElement)],Sr.prototype,"_searchInput",void 0),br([ai("#container"),wr("design:type",HTMLElement)],Sr.prototype,"_container",void 0),br([ai("slick-search-group"),wr("design:type",tr)],Sr.prototype,"_searchGroup",void 0),Sr=br([ii("slick-search-box")],Sr);const _r=function(e){function t(s){if(i[s])return i[s].exports;var o=i[s]={exports:{},id:s,loaded:!1};return e[s].call(o.exports,o,o.exports,t),o.loaded=!0,o.exports}var i={};return t.m=e,t.c=i,t.p="",t(0)}([function(e,t,i){e.exports=i(1)},function(e,t,i){var s="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol?"symbol":typeof e};!function(){function t(e,t,i,s,o){void 0===o&&(o=.5);var n=u.projectionratio(o,e),r=1-n,a={x:n*t.x+r*s.x,y:n*t.y+r*s.y},l=u.abcratio(o,e);return{A:{x:i.x+(i.x-a.x)/l,y:i.y+(i.y-a.y)/l},B:i,C:a}}var o=Math.abs,n=Math.min,r=Math.max,a=Math.cos,l=Math.sin,c=Math.acos,h=Math.sqrt,d=Math.PI,p={x:0,y:0,z:0},u=i(2),g=i(3),f=function(e){var t=e&&e.forEach?e:[].slice.call(arguments),i=!1;if("object"===s(t[0])){i=t.length;var n=[];t.forEach((function(e){["x","y","z"].forEach((function(t){void 0!==e[t]&&n.push(e[t])}))})),t=n}var r=!1,a=t.length;if(i){if(i>4){if(1!==arguments.length)throw new Error("Only new Bezier(point[]) is accepted for 4th and higher order curves");r=!0}}else if(6!==a&&8!==a&&9!==a&&12!==a&&1!==arguments.length)throw new Error("Only new Bezier(point[]) is accepted for 4th and higher order curves");var l=!r&&(9===a||12===a)||e&&e[0]&&void 0!==e[0].z;this._3d=l;for(var c=[],h=0,d=l?3:2;a>h;h+=d){var p={x:t[h],y:t[h+1]};l&&(p.z=t[h+2]),c.push(p)}this.order=c.length-1,this.points=c;var g=["x","y"];l&&g.push("z"),this.dims=g,this.dimlen=g.length,function(e){for(var t=e.order,i=e.points,s=u.align(i,{p1:i[0],p2:i[t]}),n=0;n<s.length;n++)if(o(s[n].y)>1e-4)return void(e._linear=!1);e._linear=!0}(this),this._t1=0,this._t2=1,this.update()},v=i(4);f.SVGtoBeziers=function(e){return v(f,e)},f.quadraticFromPoints=function(e,i,s,o){if(void 0===o&&(o=.5),0===o)return new f(i,i,s);if(1===o)return new f(e,i,i);var n=t(2,e,i,s,o);return new f(e,n.A,s)},f.cubicFromPoints=function(e,i,s,o,n){void 0===o&&(o=.5);var r=t(3,e,i,s,o);void 0===n&&(n=u.dist(i,r.C));var a=n*(1-o)/o,l=u.dist(e,s),c=(s.x-e.x)/l,h=(s.y-e.y)/l,d=n*c,p=n*h,g=a*c,v=a*h,m=i.x-d,y=i.y-p,b=i.x+g,w=i.y+v,x=r.A,k=x.x+(m-x.x)/(1-o),S=x.y+(y-x.y)/(1-o),_=x.x+(b-x.x)/o,C=x.y+(w-x.y)/o,$={x:e.x+(k-e.x)/o,y:e.y+(S-e.y)/o},P={x:s.x+(_-s.x)/(1-o),y:s.y+(C-s.y)/(1-o)};return new f(e,$,P,s)};var m=function(){return u};f.getUtils=m,f.PolyBezier=g,f.prototype={getUtils:m,valueOf:function(){return this.toString()},toString:function(){return u.pointsToString(this.points)},toSVG:function(e){if(this._3d)return!1;for(var t=this.points,i=["M",t[0].x,t[0].y,2===this.order?"Q":"C"],s=1,o=t.length;o>s;s++)i.push(t[s].x),i.push(t[s].y);return i.join(" ")},update:function(){this._lut=[],this.dpoints=u.derive(this.points,this._3d),this.computedirection()},computedirection:function(){var e=this.points,t=u.angle(e[0],e[this.order],e[1]);this.clockwise=t>0},length:function(){return u.length(this.derivative.bind(this))},_lut:[],getLUT:function(e){if(e=e||100,this._lut.length===e)return this._lut;this._lut=[],e--;for(var t=0;e>=t;t++)this._lut.push(this.compute(t/e));return this._lut},on:function(e,t){t=t||5;for(var i,s=this.getLUT(),o=[],n=0,r=0;r<s.length;r++)i=s[r],u.dist(i,e)<t&&(o.push(i),n+=r/s.length);return!!o.length&&(n/=o.length)},project:function(e){var t=this.getLUT(),i=t.length-1,s=u.closest(t,e),o=s.mdist,n=s.mpos;if(0===n||n===i){var r=n/i,a=this.compute(r);return a.t=r,a.d=o,a}var l,c,h,d=(n+1)/i,p=.1/i;for(o+=1,l=r=(n-1)/i;d+p>r;r+=p)c=this.compute(r),o>(h=u.dist(e,c))&&(o=h,l=r);return(c=this.compute(l)).t=l,c.d=o,c},get:function(e){return this.compute(e)},point:function(e){return this.points[e]},compute:function(e){return u.compute(e,this.points,this._3d)},raise:function(){for(var e,t,i=this.points,s=[i[0]],o=i.length,n=1;o>n;n++)e=i[n],t=i[n-1],s[n]={x:(o-n)/o*e.x+n/o*t.x,y:(o-n)/o*e.y+n/o*t.y};return s[o]=i[o-1],new f(s)},derivative:function(e){var t,i,s=1-e,o=0,n=this.dpoints[0];2===this.order&&(n=[n[0],n[1],p],t=s,i=e),3===this.order&&(t=s*s,i=s*e*2,o=e*e);var r={x:t*n[0].x+i*n[1].x+o*n[2].x,y:t*n[0].y+i*n[1].y+o*n[2].y};return this._3d&&(r.z=t*n[0].z+i*n[1].z+o*n[2].z),r},curvature:function(e){return u.curvature(e,this.points,this._3d)},inflections:function(){return u.inflections(this.points)},normal:function(e){return this._3d?this.__normal3(e):this.__normal2(e)},__normal2:function(e){var t=this.derivative(e),i=h(t.x*t.x+t.y*t.y);return{x:-t.y/i,y:t.x/i}},__normal3:function(e){var t=this.derivative(e),i=this.derivative(e+.01),s=h(t.x*t.x+t.y*t.y+t.z*t.z),o=h(i.x*i.x+i.y*i.y+i.z*i.z);t.x/=s,t.y/=s,t.z/=s,i.x/=o,i.y/=o,i.z/=o;var n={x:i.y*t.z-i.z*t.y,y:i.z*t.x-i.x*t.z,z:i.x*t.y-i.y*t.x},r=h(n.x*n.x+n.y*n.y+n.z*n.z);n.x/=r,n.y/=r,n.z/=r;var a=[n.x*n.x,n.x*n.y-n.z,n.x*n.z+n.y,n.x*n.y+n.z,n.y*n.y,n.y*n.z-n.x,n.x*n.z-n.y,n.y*n.z+n.x,n.z*n.z];return{x:a[0]*t.x+a[1]*t.y+a[2]*t.z,y:a[3]*t.x+a[4]*t.y+a[5]*t.z,z:a[6]*t.x+a[7]*t.y+a[8]*t.z}},hull:function(e){var t,i=this.points,s=[],o=[],n=0,r=0,a=0;for(o[n++]=i[0],o[n++]=i[1],o[n++]=i[2],3===this.order&&(o[n++]=i[3]);i.length>1;){for(s=[],r=0,a=i.length-1;a>r;r++)t=u.lerp(e,i[r],i[r+1]),o[n++]=t,s.push(t);i=s}return o},split:function(e,t){if(0===e&&t)return this.split(t).left;if(1===t)return this.split(e).right;var i=this.hull(e),s={left:new f(2===this.order?[i[0],i[3],i[5]]:[i[0],i[4],i[7],i[9]]),right:new f(2===this.order?[i[5],i[4],i[2]]:[i[9],i[8],i[6],i[3]]),span:i};return s.left._t1=u.map(0,0,1,this._t1,this._t2),s.left._t2=u.map(e,0,1,this._t1,this._t2),s.right._t1=u.map(e,0,1,this._t1,this._t2),s.right._t2=u.map(1,0,1,this._t1,this._t2),t?(t=u.map(t,e,1,0,1),s.right.split(t).left):s},extrema:function(){var e,t,i=this.dims,s={},o=[];return i.forEach(function(i){t=function(e){return e[i]},e=this.dpoints[0].map(t),s[i]=u.droots(e),3===this.order&&(e=this.dpoints[1].map(t),s[i]=s[i].concat(u.droots(e))),s[i]=s[i].filter((function(e){return e>=0&&1>=e})),o=o.concat(s[i].sort(u.numberSort))}.bind(this)),o=o.sort(u.numberSort).filter((function(e,t){return o.indexOf(e)===t})),s.values=o,s},bbox:function(){var e=this.extrema(),t={};return this.dims.forEach(function(i){t[i]=u.getminmax(this,i,e[i])}.bind(this)),t},overlaps:function(e){var t=this.bbox(),i=e.bbox();return u.bboxoverlap(t,i)},offset:function(e,t){if(void 0!==t){var i=this.get(e),s=this.normal(e),o={c:i,n:s,x:i.x+s.x*t,y:i.y+s.y*t};return this._3d&&(o.z=i.z+s.z*t),o}if(this._linear){var n=this.normal(0),r=this.points.map((function(t){var i={x:t.x+e*n.x,y:t.y+e*n.y};return t.z&&s.z&&(i.z=t.z+e*n.z),i}));return[new f(r)]}return this.reduce().map((function(t){return t.scale(e)}))},simple:function(){if(3===this.order){var e=u.angle(this.points[0],this.points[3],this.points[1]),t=u.angle(this.points[0],this.points[3],this.points[2]);if(e>0&&0>t||0>e&&t>0)return!1}var i=this.normal(0),s=this.normal(1),n=i.x*s.x+i.y*s.y;this._3d&&(n+=i.z*s.z);var r=o(c(n));return d/3>r},reduce:function(){var e,t,i=0,s=0,n=.01,r=[],a=[],l=this.extrema().values;for(-1===l.indexOf(0)&&(l=[0].concat(l)),-1===l.indexOf(1)&&l.push(1),i=l[0],e=1;e<l.length;e++)s=l[e],(t=this.split(i,s))._t1=i,t._t2=s,r.push(t),i=s;return r.forEach((function(e){for(i=0,s=0;1>=s;)for(s=i+n;1+n>=s;s+=n)if(!(t=e.split(i,s)).simple()){if(o(i-(s-=n))<n)return[];(t=e.split(i,s))._t1=u.map(i,0,1,e._t1,e._t2),t._t2=u.map(s,0,1,e._t1,e._t2),a.push(t),i=s;break}1>i&&((t=e.split(i,1))._t1=u.map(i,0,1,e._t1,e._t2),t._t2=e._t2,a.push(t))})),a},scale:function(e){var t=this.order,i=!1;if("function"==typeof e&&(i=e),i&&2===t)return this.raise().scale(i);var s=this.clockwise,o=i?i(0):e,n=i?i(1):e,r=[this.offset(0,10),this.offset(1,10)],a=u.lli4(r[0],r[0].c,r[1],r[1].c);if(!a)throw new Error("cannot scale this curve. Try reducing it first.");var l=this.points,c=[];return[0,1].forEach(function(e){var i=c[e*t]=u.copy(l[e*t]);i.x+=(e?n:o)*r[e].n.x,i.y+=(e?n:o)*r[e].n.y}.bind(this)),i?([0,1].forEach(function(o){if(2!==this.order||!o){var n=l[o+1],r={x:n.x-a.x,y:n.y-a.y},d=i?i((o+1)/t):e;i&&!s&&(d=-d);var p=h(r.x*r.x+r.y*r.y);r.x/=p,r.y/=p,c[o+1]={x:n.x+d*r.x,y:n.y+d*r.y}}}.bind(this)),new f(c)):([0,1].forEach(function(e){if(2!==this.order||!e){var i=c[e*t],s=this.derivative(e),o={x:i.x+s.x,y:i.y+s.y};c[e+1]=u.lli4(i,o,a,l[e+1])}}.bind(this)),new f(c))},outline:function(e,t,i,s){function o(e,t,i,s,o){return function(n){var r=s/i,a=(s+o)/i,l=t-e;return u.map(n,0,1,e+r*l,e+a*l)}}t=void 0===t?e:t;var n,r=this.reduce(),a=r.length,l=[],c=[],h=0,d=this.length(),p=void 0!==i&&void 0!==s;r.forEach((function(n){k=n.length(),p?(l.push(n.scale(o(e,i,d,h,k))),c.push(n.scale(o(-t,-s,d,h,k)))):(l.push(n.scale(e)),c.push(n.scale(-t))),h+=k})),c=c.map((function(e){return(n=e.points)[3]?e.points=[n[3],n[2],n[1],n[0]]:e.points=[n[2],n[1],n[0]],e})).reverse();var f=l[0].points[0],v=l[a-1].points[l[a-1].points.length-1],m=c[a-1].points[c[a-1].points.length-1],y=c[0].points[0],b=u.makeline(m,f),w=u.makeline(v,y),x=[b].concat(l).concat([w]).concat(c),k=x.length;return new g(x)},outlineshapes:function(e,t,i){t=t||e;for(var s=this.outline(e,t).curves,o=[],n=1,r=s.length;r/2>n;n++){var a=u.makeshape(s[n],s[r-n],i);a.startcap.virtual=n>1,a.endcap.virtual=r/2-1>n,o.push(a)}return o},intersects:function(e,t){return e?e.p1&&e.p2?this.lineIntersects(e):(e instanceof f&&(e=e.reduce()),this.curveintersects(this.reduce(),e,t)):this.selfintersects(t)},lineIntersects:function(e){var t=n(e.p1.x,e.p2.x),i=n(e.p1.y,e.p2.y),s=r(e.p1.x,e.p2.x),o=r(e.p1.y,e.p2.y),a=this;return u.roots(this.points,e).filter((function(e){var n=a.get(e);return u.between(n.x,t,s)&&u.between(n.y,i,o)}))},selfintersects:function(e){var t,i,s,o,n=this.reduce(),r=n.length-2,a=[];for(t=0;r>t;t++)s=n.slice(t,t+1),o=n.slice(t+2),i=this.curveintersects(s,o,e),a=a.concat(i);return a},curveintersects:function(e,t,i){var s=[];e.forEach((function(e){t.forEach((function(t){e.overlaps(t)&&s.push({left:e,right:t})}))}));var o=[];return s.forEach((function(e){var t=u.pairiteration(e.left,e.right,i);t.length>0&&(o=o.concat(t))})),o},arcs:function(e){e=e||.5;return this._iterate(e,[])},_error:function(e,t,i,s){var n=(s-i)/4,r=this.get(i+n),a=this.get(s-n),l=u.dist(e,t),c=u.dist(e,r),h=u.dist(e,a);return o(c-l)+o(h-l)},_iterate:function(e,t){var i,s=0,o=1;do{i=0,o=1;var n,r,c,h,d,p=this.get(s),g=!1,f=!1,v=o,m=1;do{if(f=g,h=c,v=(s+o)/2,n=this.get(v),r=this.get(o),(c=u.getccenter(p,n,r)).interval={start:s,end:o},g=e>=this._error(c,p,s,o),(d=f&&!g)||(m=o),g){if(o>=1){if(c.interval.end=m=1,h=c,o>1){var y={x:c.x+c.r*a(c.e),y:c.y+c.r*l(c.e)};c.e+=u.angle({x:c.x,y:c.y},y,this.get(1))}break}o+=(o-s)/2}else o=v}while(!d&&i++<100);if(i>=100)break;h=h||c,t.push(h),s=m}while(1>o);return t}},e.exports=f}()},function(e,t,i){!function(){var t=Math.abs,s=Math.cos,o=Math.sin,n=Math.acos,r=Math.atan2,a=Math.sqrt,l=Math.pow,c=function(e){return 0>e?-l(-e,1/3):l(e,1/3)},h=Math.PI,d=2*h,p=h/2,u=Number.MAX_SAFE_INTEGER||9007199254740991,g=Number.MIN_SAFE_INTEGER||-9007199254740991,f={x:0,y:0,z:0},v={Tvalues:[-.06405689286260563,.06405689286260563,-.1911188674736163,.1911188674736163,-.3150426796961634,.3150426796961634,-.4337935076260451,.4337935076260451,-.5454214713888396,.5454214713888396,-.6480936519369755,.6480936519369755,-.7401241915785544,.7401241915785544,-.820001985973903,.820001985973903,-.8864155270044011,.8864155270044011,-.9382745520027328,.9382745520027328,-.9747285559713095,.9747285559713095,-.9951872199970213,.9951872199970213],Cvalues:[.12793819534675216,.12793819534675216,.1258374563468283,.1258374563468283,.12167047292780339,.12167047292780339,.1155056680537256,.1155056680537256,.10744427011596563,.10744427011596563,.09761865210411388,.09761865210411388,.08619016153195327,.08619016153195327,.0733464814110803,.0733464814110803,.05929858491543678,.05929858491543678,.04427743881741981,.04427743881741981,.028531388628933663,.028531388628933663,.0123412297999872,.0123412297999872],arcfn:function(e,t){var i=t(e),s=i.x*i.x+i.y*i.y;return void 0!==i.z&&(s+=i.z*i.z),a(s)},compute:function(e,t,i){if(0===e)return t[0];var s=t.length-1;if(1===e)return t[s];var o=t,n=1-e;if(0===s)return t[0];if(1===s)return p={x:n*o[0].x+e*o[1].x,y:n*o[0].y+e*o[1].y},i&&(p.z=n*o[0].z+e*o[1].z),p;if(4>s){var r,a,l,c=n*n,h=e*e,d=0;2===s?(o=[o[0],o[1],o[2],f],r=c,a=n*e*2,l=h):3===s&&(r=c*n,a=c*e*3,l=n*h*3,d=e*h);var p={x:r*o[0].x+a*o[1].x+l*o[2].x+d*o[3].x,y:r*o[0].y+a*o[1].y+l*o[2].y+d*o[3].y};return i&&(p.z=r*o[0].z+a*o[1].z+l*o[2].z+d*o[3].z),p}for(var u=JSON.parse(JSON.stringify(t));u.length>1;){for(var g=0;g<u.length-1;g++)u[g]={x:u[g].x+(u[g+1].x-u[g].x)*e,y:u[g].y+(u[g+1].y-u[g].y)*e},void 0!==u[g].z&&(u[g]=u[g].z+(u[g+1].z-u[g].z)*e);u.splice(u.length-1,1)}return u[0]},derive:function(e,t){for(var i=[],s=e,o=s.length,n=o-1;o>1;o--,n--){for(var r,a=[],l=0;n>l;l++)r={x:n*(s[l+1].x-s[l].x),y:n*(s[l+1].y-s[l].y)},t&&(r.z=n*(s[l+1].z-s[l].z)),a.push(r);i.push(a),s=a}return i},between:function(e,t,i){return e>=t&&i>=e||v.approximately(e,t)||v.approximately(e,i)},approximately:function(e,i,s){return t(e-i)<=(s||1e-6)},length:function(e){var t,i,s=0,o=v.Tvalues.length;for(t=0;o>t;t++)i=.5*v.Tvalues[t]+.5,s+=v.Cvalues[t]*v.arcfn(i,e);return.5*s},map:function(e,t,i,s,o){return s+(o-s)*((e-t)/(i-t))},lerp:function(e,t,i){var s={x:t.x+e*(i.x-t.x),y:t.y+e*(i.y-t.y)};return t.z&&i.z&&(s.z=t.z+e*(i.z-t.z)),s},pointToString:function(e){var t=e.x+"/"+e.y;return void 0!==e.z&&(t+="/"+e.z),t},pointsToString:function(e){return"["+e.map(v.pointToString).join(", ")+"]"},copy:function(e){return JSON.parse(JSON.stringify(e))},angle:function(e,t,i){var s=t.x-e.x,o=t.y-e.y,n=i.x-e.x,a=i.y-e.y;return r(s*a-o*n,s*n+o*a)},round:function(e,t){var i=""+e,s=i.indexOf(".");return parseFloat(i.substring(0,s+1+t))},dist:function(e,t){var i=e.x-t.x,s=e.y-t.y;return a(i*i+s*s)},closest:function(e,t){var i,s,o=l(2,63);return e.forEach((function(e,n){s=v.dist(t,e),o>s&&(o=s,i=n)})),{mdist:o,mpos:i}},abcratio:function(e,i){if(2!==i&&3!==i)return!1;if(void 0===e)e=.5;else if(0===e||1===e)return e;var s=l(e,i)+l(1-e,i);return t((s-1)/s)},projectionratio:function(e,t){if(2!==t&&3!==t)return!1;if(void 0===e)e=.5;else if(0===e||1===e)return e;var i=l(1-e,t);return i/(l(e,t)+i)},lli8:function(e,t,i,s,o,n,r,a){var l=(e-i)*(n-a)-(t-s)*(o-r);return 0!=l&&{x:((e*s-t*i)*(o-r)-(e-i)*(o*a-n*r))/l,y:((e*s-t*i)*(n-a)-(t-s)*(o*a-n*r))/l}},lli4:function(e,t,i,s){var o=e.x,n=e.y,r=t.x,a=t.y,l=i.x,c=i.y,h=s.x,d=s.y;return v.lli8(o,n,r,a,l,c,h,d)},lli:function(e,t){return v.lli4(e,e.c,t,t.c)},makeline:function(e,t){var s=i(1),o=e.x,n=e.y,r=t.x,a=t.y,l=(r-o)/3,c=(a-n)/3;return new s(o,n,o+l,n+c,o+2*l,n+2*c,r,a)},findbbox:function(e){var t=u,i=u,s=g,o=g;return e.forEach((function(e){var n=e.bbox();t>n.x.min&&(t=n.x.min),i>n.y.min&&(i=n.y.min),s<n.x.max&&(s=n.x.max),o<n.y.max&&(o=n.y.max)})),{x:{min:t,mid:(t+s)/2,max:s,size:s-t},y:{min:i,mid:(i+o)/2,max:o,size:o-i}}},shapeintersections:function(e,t,i,s,o){if(!v.bboxoverlap(t,s))return[];var n=[],r=[e.startcap,e.forward,e.back,e.endcap],a=[i.startcap,i.forward,i.back,i.endcap];return r.forEach((function(t){t.virtual||a.forEach((function(s){if(!s.virtual){var r=t.intersects(s,o);r.length>0&&(r.c1=t,r.c2=s,r.s1=e,r.s2=i,n.push(r))}}))})),n},makeshape:function(e,t,i){var s=t.points.length,o=e.points.length,n=v.makeline(t.points[s-1],e.points[0]),r=v.makeline(e.points[o-1],t.points[0]),a={startcap:n,forward:e,back:t,endcap:r,bbox:v.findbbox([n,e,t,r])},l=v;return a.intersections=function(e){return l.shapeintersections(a,a.bbox,e,e.bbox,i)},a},getminmax:function(e,t,i){if(!i)return{min:0,max:0};var s,o,n=u,r=g;-1===i.indexOf(0)&&(i=[0].concat(i)),-1===i.indexOf(1)&&i.push(1);for(var a=0,l=i.length;l>a;a++)s=i[a],(o=e.get(s))[t]<n&&(n=o[t]),o[t]>r&&(r=o[t]);return{min:n,mid:(n+r)/2,max:r,size:r-n}},align:function(e,t){var i=t.p1.x,n=t.p1.y,a=-r(t.p2.y-n,t.p2.x-i);return e.map((function(e){return{x:(e.x-i)*s(a)-(e.y-n)*o(a),y:(e.x-i)*o(a)+(e.y-n)*s(a)}}))},roots:function(e,t){t=t||{p1:{x:0,y:0},p2:{x:1,y:0}};var i=e.length-1,o=v.align(e,t),r=function(e){return e>=0&&1>=e};if(2===i){if(0!==(f=(m=o[0].y)-2*(y=o[1].y)+(b=o[2].y))){var l=-a(y*y-m*b),h=-m+y;return[-(l+h)/f,-(-l+h)/f].filter(r)}return y!==b&&0===f?[(2*y-b)/(2*y-2*b)].filter(r):[]}var p=o[0].y,u=o[1].y,g=o[2].y,f=3*u-p-3*g+o[3].y,m=3*p-6*u+3*g,y=-3*p+3*u,b=p;if(v.approximately(f,0)){if(v.approximately(m,0))return v.approximately(y,0)?[]:[-b/y].filter(r);var w=2*m;return[((k=a(y*y-4*m*b))-y)/w,(-y-k)/w].filter(r)}var x,k,S=(o=(3*(y/=f)-(m/=f)*m)/3)/3,_=(k=(2*m*m*m-9*m*y+27*(b/=f))/27)/2,C=_*_+S*S*S;if(0>C){var $=-o/3,P=a($*$*$),I=-k/(2*P),T=n(-1>I?-1:I>1?1:I),O=2*c(P);return[O*s(T/3)-m/3,O*s((T+d)/3)-m/3,O*s((T+2*d)/3)-m/3].filter(r)}if(0===C)return[2*(x=0>_?c(-_):-c(_))-m/3,-x-m/3].filter(r);var R=a(C);return[(x=c(-_+R))-c(_+R)-m/3].filter(r)},droots:function(e){if(3===e.length){var t=e[0],i=e[1],s=e[2],o=t-2*i+s;if(0!==o){var n=-a(i*i-t*s),r=-t+i;return[-(n+r)/o,-(-n+r)/o]}return i!==s&&0===o?[(2*i-s)/(2*(i-s))]:[]}if(2===e.length)return(t=e[0])!==(i=e[1])?[t/(t-i)]:[]},curvature:function(e,t,i){var s,o,n=v.derive(t),r=n[0],c=n[1],h=v.compute(e,r),d=v.compute(e,c);return i?(s=a(l(h.y*d.z-d.y*h.z,2)+l(h.z*d.x-d.z*h.x,2)+l(h.x*d.y-d.x*h.y,2)),o=l(h.x*h.x+h.y*h.y+h.z*h.z,1.5)):(s=h.x*d.y-h.y*d.x,o=l(h.x*h.x+h.y*h.y,1.5)),0===s||0===o?{k:0,r:0}:{k:s/o,r:o/s}},inflections:function(e){if(e.length<4)return[];var t=v.align(e,{p1:e[0],p2:e.slice(-1)[0]}),i=t[2].x*t[1].y,s=t[3].x*t[1].y,o=t[1].x*t[2].y,n=18*(-3*i+2*s+3*o-(d=t[3].x*t[2].y)),r=18*(3*i-s-3*o),a=18*(o-i);if(v.approximately(n,0)){if(!v.approximately(r,0)){var l=-a/r;if(l>=0&&1>=l)return[l]}return[]}var c=r*r-4*n*a,h=Math.sqrt(c),d=2*n;return v.approximately(d,0)?[]:[(h-r)/d,-(r+h)/d].filter((function(e){return e>=0&&1>=e}))},bboxoverlap:function(e,i){var s,o,n,r,a,l=["x","y"],c=l.length;for(s=0;c>s;s++)if(n=e[o=l[s]].mid,r=i[o].mid,a=(e[o].size+i[o].size)/2,t(n-r)>=a)return!1;return!0},expandbox:function(e,t){t.x.min<e.x.min&&(e.x.min=t.x.min),t.y.min<e.y.min&&(e.y.min=t.y.min),t.z&&t.z.min<e.z.min&&(e.z.min=t.z.min),t.x.max>e.x.max&&(e.x.max=t.x.max),t.y.max>e.y.max&&(e.y.max=t.y.max),t.z&&t.z.max>e.z.max&&(e.z.max=t.z.max),e.x.mid=(e.x.min+e.x.max)/2,e.y.mid=(e.y.min+e.y.max)/2,e.z&&(e.z.mid=(e.z.min+e.z.max)/2),e.x.size=e.x.max-e.x.min,e.y.size=e.y.max-e.y.min,e.z&&(e.z.size=e.z.max-e.z.min)},pairiteration:function(e,t,i){var s=e.bbox(),o=t.bbox(),n=1e5,r=i||.5;if(s.x.size+s.y.size<r&&o.x.size+o.y.size<r)return[(n*(e._t1+e._t2)/2|0)/n+"/"+(n*(t._t1+t._t2)/2|0)/n];var a=e.split(.5),l=t.split(.5),c=[{left:a.left,right:l.left},{left:a.left,right:l.right},{left:a.right,right:l.right},{left:a.right,right:l.left}];c=c.filter((function(e){return v.bboxoverlap(e.left.bbox(),e.right.bbox())}));var h=[];return 0===c.length?h:(c.forEach((function(e){h=h.concat(v.pairiteration(e.left,e.right,r))})),h=h.filter((function(e,t){return h.indexOf(e)===t})))},getccenter:function(e,t,i){var n,a=t.x-e.x,l=t.y-e.y,c=i.x-t.x,h=i.y-t.y,u=a*s(p)-l*o(p),g=a*o(p)+l*s(p),f=c*s(p)-h*o(p),m=c*o(p)+h*s(p),y=(e.x+t.x)/2,b=(e.y+t.y)/2,w=(t.x+i.x)/2,x=(t.y+i.y)/2,k=y+u,S=b+g,_=w+f,C=x+m,$=v.lli8(y,b,k,S,w,x,_,C),P=v.dist($,e),I=r(e.y-$.y,e.x-$.x),T=r(t.y-$.y,t.x-$.x),O=r(i.y-$.y,i.x-$.x);return O>I?((I>T||T>O)&&(I+=d),I>O&&(n=O,O=I,I=n)):T>O&&I>T?(n=O,O=I,I=n):O+=d,$.s=I,$.e=O,$.r=P,$},numberSort:function(e,t){return e-t}};e.exports=v}()},function(e,t,i){!function(){var t=i(2),s=function(e){this.curves=[],this._3d=!1,e&&(this.curves=e,this._3d=this.curves[0]._3d)};s.prototype={valueOf:function(){return this.toString()},toString:function(){return"["+this.curves.map((function(e){return t.pointsToString(e.points)})).join(", ")+"]"},addCurve:function(e){this.curves.push(e),this._3d=this._3d||e._3d},length:function(){return this.curves.map((function(e){return e.length()})).reduce((function(e,t){return e+t}))},curve:function(e){return this.curves[e]},bbox:function(){for(var e=this.curves,i=e[0].bbox(),s=1;s<e.length;s++)t.expandbox(i,e[s].bbox());return i},offset:function(e){var t=[];return this.curves.forEach((function(i){t=t.concat(i.offset(e))})),new s(t)}},e.exports=s}()},function(e,t,i){function s(e,t,i){if("Z"!==t){if("M"===t)return void(n={x:i[0],y:i[1]});var s=[!1,n.x,n.y].concat(i),o=new(e.bind.apply(e,s)),r=i.slice(-2);return n={x:r[0],y:r[1]},o}}var o=i(5),n={x:!1,y:!1};e.exports=function(e,t){for(var i,n,r=o(t).split(" "),a=new RegExp("[MLCQZ]",""),l=[],c={C:6,Q:4,L:2,M:2};r.length;)i=r.splice(0,1)[0],a.test(i)&&((n=s(e,i,r.splice(0,c[i]).map(parseFloat)))&&l.push(n));return new e.PolyBezier(l)}},function(e,t){e.exports=function(e){var t,i,s,o,n,r,a=(e=e.replace(/,/g," ").replace(/-/g," - ").replace(/-\s+/g,"-").replace(/([a-zA-Z])/g," $1 ")).replace(/([a-zA-Z])\s?/g,"|$1").split("|"),l=a.length,c=[],h=0,d=0,p=0,u=0,g=0,f=0,v=0,m=0,y="";for(t=1;l>t;t++)if(o=(s=(i=a[t]).substring(0,1)).toLowerCase(),c=(c=i.replace(s,"").trim().split(" ")).filter((function(e){return""!==e})).map(parseFloat),n=c.length,"m"===o){if(y+="M ","m"===s?(p+=c[0],u+=c[1]):(p=c[0],u=c[1]),h=p,d=u,y+=p+" "+u+" ",n>2)for(r=0;n>r;r+=2)"m"===s?(p+=c[r],u+=c[r+1]):(p=c[r],u=c[r+1]),y+=["L",p,u,""].join(" ")}else if("l"===o)for(r=0;n>r;r+=2)"l"===s?(p+=c[r],u+=c[r+1]):(p=c[r],u=c[r+1]),y+=["L",p,u,""].join(" ");else if("h"===o)for(r=0;n>r;r++)"h"===s?p+=c[r]:p=c[r],y+=["L",p,u,""].join(" ");else if("v"===o)for(r=0;n>r;r++)"v"===s?u+=c[r]:u=c[r],y+=["L",p,u,""].join(" ");else if("q"===o)for(r=0;n>r;r+=4)"q"===s?(g=p+c[r],f=u+c[r+1],p+=c[r+2],u+=c[r+3]):(g=c[r],f=c[r+1],p=c[r+2],u=c[r+3]),y+=["Q",g,f,p,u,""].join(" ");else if("t"===o)for(r=0;n>r;r+=2)g=p+(p-g),f=u+(u-f),"t"===s?(p+=c[r],u+=c[r+1]):(p=c[r],u=c[r+1]),y+=["Q",g,f,p,u,""].join(" ");else if("c"===o)for(r=0;n>r;r+=6)"c"===s?(g=p+c[r],f=u+c[r+1],v=p+c[r+2],m=u+c[r+3],p+=c[r+4],u+=c[r+5]):(g=c[r],f=c[r+1],v=c[r+2],m=c[r+3],p=c[r+4],u=c[r+5]),y+=["C",g,f,v,m,p,u,""].join(" ");else if("s"===o)for(r=0;n>r;r+=4)g=p+(p-v),f=u+(u-m),"s"===s?(v=p+c[r],m=u+c[r+1],p+=c[r+2],u+=c[r+3]):(v=c[r],m=c[r+1],p=c[r+2],u=c[r+3]),y+=["C",g,f,v,m,p,u,""].join(" ");else"z"===o&&(y+="Z ",p=h,u=d);return y.trim()}}]);class Cr{constructor(e){this.id=-1,this.nativePointer=e,this.pageX=e.pageX,this.pageY=e.pageY,this.clientX=e.clientX,this.clientY=e.clientY,self.Touch&&e instanceof Touch?this.id=e.identifier:$r(e)&&(this.id=e.pointerId)}getCoalesced(){return"getCoalescedEvents"in this.nativePointer?this.nativePointer.getCoalescedEvents().map((e=>new Cr(e))):[this]}}const $r=e=>self.PointerEvent&&e instanceof PointerEvent,Pr=()=>{};class Ir{constructor(e,t){this._element=e,this.startPointers=[],this.currentPointers=[];const{start:i=(()=>!0),move:s=Pr,end:o=Pr}=t;this._startCallback=i,this._moveCallback=s,this._endCallback=o,this._pointerStart=this._pointerStart.bind(this),this._touchStart=this._touchStart.bind(this),this._move=this._move.bind(this),this._triggerPointerEnd=this._triggerPointerEnd.bind(this),this._pointerEnd=this._pointerEnd.bind(this),this._touchEnd=this._touchEnd.bind(this),self.PointerEvent?this._element.addEventListener("pointerdown",this._pointerStart):(this._element.addEventListener("mousedown",this._pointerStart),this._element.addEventListener("touchstart",this._touchStart),this._element.addEventListener("touchmove",this._move),this._element.addEventListener("touchend",this._touchEnd))}_triggerPointerStart(e,t){return!!this._startCallback(e,t)&&(this.currentPointers.push(e),this.startPointers.push(e),!0)}_pointerStart(e){0===e.button&&this._triggerPointerStart(new Cr(e),e)&&($r(e)?(this._element.setPointerCapture(e.pointerId),this._element.addEventListener("pointermove",this._move),this._element.addEventListener("pointerup",this._pointerEnd)):(window.addEventListener("mousemove",this._move),window.addEventListener("mouseup",this._pointerEnd)))}_touchStart(e){for(const t of Array.from(e.changedTouches))this._triggerPointerStart(new Cr(t),e)}_move(e){const t=this.currentPointers.slice(),i="changedTouches"in e?Array.from(e.changedTouches).map((e=>new Cr(e))):[new Cr(e)],s=[];for(const e of i){const t=this.currentPointers.findIndex((t=>t.id===e.id));-1!==t&&(s.push(e),this.currentPointers[t]=e)}0!==s.length&&this._moveCallback(t,s,e)}_triggerPointerEnd(e,t){const i=this.currentPointers.findIndex((t=>t.id===e.id));return-1!==i&&(this.currentPointers.splice(i,1),this.startPointers.splice(i,1),this._endCallback(e,t),!0)}_pointerEnd(e){if(this._triggerPointerEnd(new Cr(e),e))if($r(e)){if(this.currentPointers.length)return;this._element.removeEventListener("pointermove",this._move),this._element.removeEventListener("pointerup",this._pointerEnd)}else window.removeEventListener("mousemove",this._move),window.removeEventListener("mouseup",this._pointerEnd)}_touchEnd(e){for(const t of Array.from(e.changedTouches))this._triggerPointerEnd(new Cr(t),e)}}var Tr=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Or=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Rr=class extends ei{static get styles(){return it`
    :host {
      display: inline-block; 
      color: white;
    }
    button {
      background-color: var(--soso-fab-background, #018786);
      background-size: cover;
      background-origin: border-box;
      background-position: 50% 50%;
      box-sizing: border-box;
      cursor: pointer;
      outline: none;
      border: none;
      border-radius: 50%;
      overflow: hidden;
      padding: var(--soso-fab-padding, 16px);
      color: inherit;
      user-select: none;
      position: relative;
      box-shadow: var(--soso-fab-shadow, 0 3px 5px -1px rgba(0,0,0,.2), 0 6px 10px 0 rgba(0,0,0,.14), 0 1px 18px 0 rgba(0,0,0,.12));
      transition: box-shadow 0.28s ease;
    }
    button:focus {
      box-shadow: var(--soso-fab-focus-shadow, 0 5px 5px -3px rgba(0,0,0,.2), 0 8px 10px 1px rgba(0,0,0,.14), 0 3px 14px 2px rgba(0,0,0,.12));
    }
    button::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: currentColor;
      opacity: 0;
      transition: opacity 0.28s ease;
    }
    button:focus::before {
      opacity: 0.18;
    }
    button:active::before {
      opacity: 0;
    }
    button soso-icon {
      transition: transform 0.3s ease;
    }
    button:active soso-icon {
      transform: scale(1.15);
    }

    @media (hover: hover) {
      button:hover::before {
        opacity: 0.08;
      }
      button:focus::before {
        opacity: 0.18;
      }
      button:active::before {
        opacity: 0;
      }
      button:hover,button:focus {
        box-shadow: var(--soso-fab-focus-shadow, 0 5px 5px -3px rgba(0,0,0,.2), 0 8px 10px 1px rgba(0,0,0,.14), 0 3px 14px 2px rgba(0,0,0,.12));
      }
    }
    `}render(){const e=(this.image||"").trim()?`background-image:url("${this.image.trim()}")`:"";return Lt`
    <button aria-label="${this.label||this.icon||""}" style="${e}">
      <soso-icon .icon="${this.icon}" .iconkey="${this.iconkey}" .customSvg="${this.customSvg}"></soso-icon>
    </button>`}focus(){if(this.shadowRoot){const e=this.shadowRoot.querySelector("button");e&&e.focus()}}};Tr([oi({type:String}),Or("design:type",String)],Rr.prototype,"icon",void 0),Tr([oi({type:String}),Or("design:type",String)],Rr.prototype,"iconkey",void 0),Tr([oi({type:String}),Or("design:type",String)],Rr.prototype,"image",void 0),Tr([oi(),Or("design:type",String)],Rr.prototype,"customSvg",void 0),Tr([oi(),Or("design:type",String)],Rr.prototype,"label",void 0),Rr=Tr([Oi("soso-fab")],Rr);var Er=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},jr=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const Lr={x:400,y:500},zr={x:200,y:250},Mr=.8,Ar="heartbeat";let Dr=class extends Ds{constructor(){super(),this.count=0,this.visitors=0,this.voted=!1,this.favCount=0,this.location="",this.animatingHeartCount=!1,this.compact=!1,this.compactActive=!1,this.bttShowing=!1,this.savedPopupShowing=!1,this.animating=!1,this.hearts=new Set,this.hue=Math.random(),this.hearting=!1,this.heartCount=0,this.colorMap=new Map,this.locationShownSet=new Set,this.heartingTimer=0,this.heartDownTimer=0,this.pendingCount=0,this.popupToShowOnClick="none",this.linkedPanelShowing=!0,this.bttEnabled=!1,this.compactActiveModeTimer=0,this.prevScrollValue=0,this.scrollingUp=!1,this.linkedPanelPollTimer=0,this.scrolling=!1,this.bigCanvas=this.useBigCanvas()}useBigCanvas(){return window.innerWidth>750&&window.innerHeight>750}render(){var e,t,i,s,o;const n=this.bigCanvas?Lr:zr,r=`width: ${n.x}px; height: ${n.y}px;`,a=!!(null===(e=this.config)||void 0===e?void 0:e.hideTotalCount),l=this.count<((null===(t=this.config)||void 0===t?void 0:t.minVisibleCount)||1),c=this.config&&"right"===this.config.tongueDirection;let h=c;"rtl"===this.dir&&(h=!c);const d=(null===(i=this.iconSettings)||void 0===i?void 0:i.iconType)||"heart",p=(this.bttSettings&&this.bttSettings.iconImage||"").trim(),u=!Ze.isMemberSignedIn();return this.config&&!this.style.transform&&this.adjustHeartPosition(),Lt`
    <style>
      :host {
        display: block;
        position: fixed;
        bottom: var(--slick-heartbeat-bottom, 16px);
        right: var(--slick-heartbeat-right, 0px);
        pointer-events: none;
        z-index: var(--slick-heartbeat-zindex, 100002);
        padding: 0 5px 0 0;
        -moz-user-select: none;
        -webkit-user-select: none;
        -webkit-touch-callout: none;
        -ms-user-select: none;
        user-select: none;
        transition: transform 0.3s ease;
        outline: none;
      }
      #canvas {
        position: absolute;
        right: 0;
        bottom: 52px;
        overflow: hidden;
        display: var(--slick-heart-fab-display, block);
      }
      #canvas.right-tongue {
        right: initial;
        left: 0;
      }
      soso-icon.heart {
        height: 30px;
        width: 30px;
        position: absolute;
        margin-left: -15px;
        top: 0;
        left: 0;
        opacity: 0;
      }
      slick-fab {
        color: var(--slick-heartbeat-color, #2196f3);
        margin-right: 5px;
        cursor: pointer;
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
        -webkit-touch-callout: none;
        user-select: none;
        pointer-events: auto;
        --fab-background: var(--slick-heartbeat-background, rgba(255,255,255,1));
        --fab-padding: 10px;
      }
      slick-fab#heartFab {
        color: var(--slick-heart-fab-color, var(--slick-heartbeat-color, #2196f3));
      }
      slick-fab#searchFab {
        --fab-background: var(--slick-search-fab-background, var(--slick-heartbeat-color, #2196f3));
        color: var(--slick-search-fab-color, var(--slick-heartbeat-background, rgba(255,255,255,1)));
        margin-top: 8px;
        display: var(--slick-search-fab-display, flex);
      }
      slick-fab#backToTop {
        --fab-background: var(--slick-btt-fab-background, var(--slick-heartbeat-background, rgba(255,255,255,1)));
        color: var(--slick-btt-fab-color, var(--slick-heartbeat-color, #2196f3));
        display: var(--slick-btt-fab-display, none);
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.3s ease;
        margin-bottom: 8px;
      }
      slick-fab#backToTop.showing {
        opacity: 1;
        pointer-events: auto;
      }
      #heartFabPanel {
        display: var(--slick-heart-fab-display, flex);
      }
      .favoriteCount {
        line-height: 1;
        padding: 2px;
        border-radius: 2px;
        color: var(--slick-favcount-color, var(--slick-heart-fab-color, var(--slick-heartbeat-color, #2196f3)));
        letter-spacing: 0.05em;
        font-family: sans-serif;
        min-width: 40px;
        max-width: 60px;
        white-space: nowrap;
        text-align: center;
        -moz-user-select: none;
        -webkit-user-select: none;
        -webkit-touch-callout: none;
        -ms-user-select: none;
        user-select: none;
        font-size: 13px;
        height: 17px;
        display: var(--slick-heart-fab-display, inline-block);
        transform: translateX(-2.5px);
      }
      .visitorCount {
        line-height: 1;
        padding: 2px;
        border-radius: 2px;
        letter-spacing: 0.05em;
        font-family: sans-serif;
        position: absolute;
        right: 10px;
        width: 40px;
        text-align: center;
        -moz-user-select: none;
        -webkit-user-select: none;
        -webkit-touch-callout: none;
        -ms-user-select: none;
        user-select: none;
        font-size: 13px;
        height: 13px;
        top: -40px;
        display: var(--slick-heart-fab-display, inline-block);
        background: var(--slick-heartbeat-color, #2196f3);
        color: white;
      }
      .fillContainer {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        pointer-events: none;
      }
      .transparent {
        opacity: 0;
      }
      .hidden {
        display: none !important;
      }
      .fabPopup {
        position: absolute;
        white-space: nowrap;
        top: 22px;
        right: 58px;
        color: white;
        margin: -12px 0 0;
        padding: 6px 8px;
        font-size: 11px;
        text-transform: uppercase;
        background: rgba(0,0,0,0.8);
        border-radius: 2px;
        box-shadow: 0 3px 1px -2px rgba(0,0,0,.2), 0 2px 2px 0 rgba(0,0,0,.14), 0 1px 5px 0 rgba(0,0,0,.12);
        line-height: 1;
        font-family: system-ui, sans-serif;
        transform: translate3d(84px,0,0) scale(0.1);
        opacity: 0;
        transition: transform 0.3s ease, opacity 0.3s ease;
        will-change: transform;
      }
      .fabPopup.right-tongue.showing,
      .fabPopup.showing {
        opacity: 1;
        transform: translate3d(0,0,0) scale(1);
      }
      .fabPopup::after {
        content: "";
        position: absolute;
        bottom: 100%;
        left: 100%;
        transform: translateY(18px);
        border: 7px solid rgba(0,0,0,0.8);
        border-right-color: transparent;
        border-bottom-color: transparent;
        border-top-color: transparent;
        border-left-color: rgba(0,0,0,0.8);
        width: 0;
        height: 0;
        margin: 0 auto;
      }

      .fabPopup.right-tongue {
        right: initial;
        left: 58px;
        transform: translate3d(-84px,0,0) scale(0.1);
      }
      .fabPopup.right-tongue::after {
        border-left-color: transparent;
        border-right-color: rgba(0,0,0,0.8);
        right: 100%;
        left: initial;
      }

      #locationPopup {
        z-index: 1;
        display: var(--slick-location-popup-display, block);
      }
      #iconsPanel {
        line-height: 1;
        text-align: center;
        position: relative;
      }
      #favCountsButton {
        position: absolute;
        top: 0;
        right: 50%;
        white-space: nowrap;
        pointer-events: none;
        border: none;
        outline: none;
        padding: 10px 0 11px 6px;
        cursor: pointer;
        opacity: 0;
        background: none;
        transform: translateX(50%);
        transition: opacity 0.4s ease, transform 0.3s ease;
      }
      #favCountsButton.active {
        opacity: 1;
        transform: translateX(7px);
        pointer-events: auto;
      }
      #favCountsButton.active.showingCount {
        transform: translateX(0);
      }

      #favCountsButton.right-tongue {
        right: auto;
        left: 50%;
        padding: 10px 6px 11px 0;
        transform: translateX(-50%);
      }
      #favCountsButton.right-tongue.active {
        transform: translateX(-7px);
      }
      #favCountsButton.right-tongue.active.showingCount {
        transform: translateX(0);
      }
      #favCountsButton.right-tongue #favCounts {
        padding: 5px 5px 5px 28px;
        border-radius: 0 12px 12px 0;
        flex-direction: row-reverse;
      }
      #favCountsButton.right-tongue #favCounts soso-icon {
        margin: 0 0 0 2px;
      }
      slick-fab.right-tongue {
        margin-right: 0;
        margin-left: 5px;
      }

      #favCounts {
        padding: 5px 28px 5px 5px;
        border-radius: 12px 0 0 12px;
        line-height: 1;
        background: var(--slick-search-fab-background, var(--slick-heartbeat-color, #2196f3));
        color: var(--slick-search-fab-color, var(--slick-heartbeat-background, rgba(255,255,255,1)));
        direction: ltr;
      }
      #favCounts soso-icon {
        width: 1.2em;
        height: 1.2em;
        margin: 0 2px 0 0;
      }
      #favCountLabel {
        opacity: 0;
        transition: opacity 0.5s ease;
      }
      #favCountLabel.showing {
        opacity: 1;
      }
      #searchOverlay {
        pointer-events: auto;
        position: absolute;
        right: 6px;
        bottom: 0px;
        background: red;
        border: none;
        padding: 0;
        width: 50px;
        height: 50px;
        opacity: 0;
        border-radius: 10px;
        outline: none;
        cursor: pointer;
        display: var(--slick-search-fab-display, block);
      }
      #heartOverlay {
        pointer-events: auto;
        position: absolute;
        right: 6px;
        bottom: 50px;
        background: blue;
        border: none;
        padding: 0;
        width: 50px;
        height: 50px;
        opacity: 0;
        border-radius: 10px;
        outline: none;
        cursor: pointer;
        display: var(--slick-heart-fab-display, block);
      }

      #container.compact {
        transition: transform 0.4s ease;
        transform: scale(0.65);
      }
      #container.compact #favCountsButton.active {
        opacity: 0;
      }
      #container.compact .favoriteCount {
        transition: opacity 0.6s ease;
        opacity: 0;
        height: 0;
      }
      #container.compact slick-fab#backToTop {
        transition: transform 0.4s ease;
        transform: translateY(-18px);
      }
      #container.compact slick-fab#searchFab {
        transition: transform 0.4s ease;
        transform: translateY(6px);
      }
      #container.compact #heartFabPanel {
        transition: transform 0.4s ease;
        transform: translateY(-6px);
      }
      #container.compact #canvas {
        transition: transform 0.4s ease;
        transform: translateY(-6px);
      }

      #container.compact.compact-active {
        transform: none;
      }
      #container.compact.compact-active #favCountsButton.active {
        opacity: 1;
      }
      #container.compact.compact-active .favoriteCount {
        opacity: 1;
        height: auto;
      }
      #container.compact.compact-active .favoriteCount.transparent {
        opacity: 0;
      }
      #container.compact.compact-active slick-fab#searchFab {
        transform: none;
      }
      #container.compact.compact-active slick-fab#backToTop {
        transform: none;
      }
      #container.compact.compact-active #heartFabPanel {
        transform: none;
      }
      #container.compact.compact-active #canvas {
        transform: none;
      }
      
      slick-popup-actions {
        left: initial;
        right: 0;
      }
      #savedLabel {
        font-size: 13px;
        font-family: sans-serif;
        line-height: 1;
        padding: 6px;
        pointer-events: none;
        white-space: nowrap;
      }
      #signinPrompt {
        width: 220px;
        font-size: 13px;
        line-height: 1.4;
        padding: 16px 8px 8px;
        color: #808080;
      }

      @media(hover:hover) {
        #favCountsButton.active:hover {
          transform: translateX(0);
        }
        #favCountsButton.active:hover #favCountLabel {
          opacity: 1;
        }
      }
    </style>
    <style rtl>
      :host([dir="rtl"]) {
        padding: 0 0 0 5px;
        left: var(--slick-heartbeat-right, 0px);
        right: initial;
      }
      :host([dir="rtl"]) .favoriteCount {
        transform: translateX(2.5px);
      }
      :host([dir="rtl"]) slick-popup-actions {
        left: 0;
        right: initial;
      }
    </style>
    <div id="container" class="${this.compact?"compact":""} ${this.compactActive?"compact-active":""} ${this.favCount?"showing-tongue":""}">
      <div id="iconsPanel" class="vertical layout">

      ${p?Lt`<slick-fab label="Scroll to top" title="Scroll to top" id="backToTop" .image="${p}" class="${h?"right-tongue":""} ${this.bttShowing?"showing":""}" @click="${this.scrollToTop}"></slick-fab>`:Lt`<slick-fab label="Scroll to top" title="Scroll to top" id="backToTop" icon="expand-less" class="${h?"right-tongue":""} ${this.bttShowing?"showing":""}" @click="${this.scrollToTop}"></slick-fab>`} 
        
        <label 
          aria-label="This page has been favorited ${this.countString(this.count)} times"
          class="favoriteCount ${l?"transparent":""} ${a?"hidden":""}">${this.countString(this.count)}</label>

        <div id="heartFabPanel" style="position: relative;">
          <button id="favCountsButton" 
            aria-label="View my favorites"
            class="${this.config&&this.config.disableTongue?"hidden":this.favCount?"active":""} ${this.animatingHeartCount?"showingCount":""} ${h?"right-tongue":""}" 
            @click="${this.openFaves}">
            <div id="favCounts" class="horizontal layout center">
              <soso-icon icon="bookmark"></soso-icon>
              <span id="favCountLabel" aria-label="You have ${1===this.favCount?"1 favorite":this.favCount+" favorites"}" class="${this.animatingHeartCount?"showing":""}">${this.favCount}</span>
            </div>
          </button>
          <slick-fab id="heartFab" 
            label="Add to favorites"
            .customSvg="${"custom"===d?null===(s=this.iconSettings)||void 0===s?void 0:s.customSvgOutline:void 0}"
            .customSvgActive="${"custom"===d?null===(o=this.iconSettings)||void 0===o?void 0:o.customSvgFilled:void 0}"
            .active="${this.voted}"
            .icon="${d}-outline"
            .activeIcon="${d}" 
            class="${h?"right-tongue":""}"
            @click="${this.onHeartClick}">
          </slick-fab>
          <div id="locationPopup" class="fabPopup ${h?"right-tongue":""}">${this.location}</div>

          <slick-popup-actions 
            .autohide="${!1}"
            .showing="${this.savedPopupShowing}"
            style="--slick-popup-actions-shadow: none; --slick-popup-actions-border: 1px solid #f0f0f0;">
            <div id="savedLabel">${Ze.phrase("favorite-added")}</div>
          </slick-popup-actions>

          <slick-popup-actions  id="popupSignin">
            <div id="signinPrompt">${Ze.phrase("prompt-to-sign-in")}</div>
            <div style="padding: 0 0 8px;">
              <soso-button @click="${this.signin}">${Ze.phrase("sign-in")}</soso-button>
            </div>
          </slick-popup-actions>

          <slick-popup-actions id="popupMenu">
            <button @click="${this.removeFavorite}">${Ze.phrase("remove-favorite")}</button>
            <button @click="${this.openFaves}">${this.getMyFavsLabel()}</button>
            ${u?Lt`<button @click="${this.signin}">${Ze.phrase("prompt-to-sign-in-short")}</button>`:""}
          </slick-popup-actions>
        </div>
        <slick-fab label="Open search panel" id="searchFab" icon="search" @click="${this.openSearch}" class="${h?"right-tongue":""}"></slick-fab>
      </div>
      
      <div id="canvas" class="${h?"right-tongue":""}" style="${r}"></div>
      
      <label class="visitorCount ${h?"right-tongue":""} ${this.visitors>0?"":"transparent"}">${this.countString(this.visitors)}</label>
    </div>
    <button aria-label="Add favorite" id="heartOverlay" class="${this.compact&&!this.compactActive?"":"hidden"}" @click="${this.onHeartOverlayClick}"></button>
    <button aria-label="Search" id="searchOverlay" class="${this.compact&&!this.compactActive?"":"hidden"}" @click="${this.openSearch}"></button>
    `}getMyFavsLabel(){var e,t;let i=null===(t=null===(e=Ze.currentSession)||void 0===e?void 0:e.settings.discovery)||void 0===t?void 0:t.myFavoritesText;return i||(i=Ze.phrase("my-favorite-pages")),i}updated(e){const t=window.innerWidth<600;if(e.has("bttSettings")&&(this.bttEnabled=!!this.bttSettings&&("always"===this.bttSettings.showButton||"desktop-only"===this.bttSettings.showButton&&!t),this.refreshBttVisibility()),e.has("config")&&this.config){switch(this.config.compactMode||"default"){case"always":this.compact=!0;break;case"mobile-only":this.compact=t;break;default:this.compact=!1}const e="always"===this.config.showSearchButton||"desktop-only"===this.config.showSearchButton&&!t,i="always"===this.config.showFavoriteButton||"desktop-only"===this.config.showFavoriteButton&&!t;e?this.style.removeProperty("--slick-search-fab-display"):this.style.setProperty("--slick-search-fab-display","none"),i?this.style.removeProperty("--slick-heart-fab-display"):this.style.setProperty("--slick-heart-fab-display","none"),this.attachLinkedPanel(),this.adjustHeartPosition(),this.config.tabIndex?this.setAttribute("tabindex",`${this.config.tabIndex}`):this.removeAttribute("tabindex")}this.config||(this.style.setProperty("--slick-heart-fab-display","none"),this.style.setProperty("--slick-search-fab-display","none"))}firstUpdated(){this.attachTouchListeners(),e.subscribe("notification-hearts-added",(e=>{const t=e&&e.payload;if(t&&t.addedHeartsByReader)for(const e in t.addedHeartsByReader){const i=Math.min(5,t.addedHeartsByReader[e]);this.addHearts(i,e),i&&this.showLocation(e,t.location)}this.updateCount(t.totalFavorites,!0)}));const t=e=>{const t=e.currentPage;if(t){this.updateCount(t.totalFavorites),this.voted=t.isFavorite||!1;const i=this.favCount||0;this.favCount=e.totalUserFavorites||0,this.favCount>i&&(this.animatingHeartCount=!0,setTimeout((()=>{this.animatingHeartCount=!1}),3e3)),e.isSuperAdmin&&(this.visitors=e.activeVisitors)}};e.subscribe("session-updated",t),e.subscribe("membership-updated",t),e.subscribe("notification-visitor-arrived",(e=>{var t;const i=e&&e.payload;i&&i.activeVisitors&&(null===(t=Ze.currentSession)||void 0===t?void 0:t.isSuperAdmin)&&(this.visitors=i.activeVisitors)})),e.subscribe("notification-visitor-departed",(e=>{var t;const i=e&&e.payload;i&&i.activeVisitors&&(null===(t=Ze.currentSession)||void 0===t?void 0:t.isSuperAdmin)&&(this.visitors=i.activeVisitors)})),e.subscribe("external-heart-added",(()=>{Ze.isMemberSignedIn()||setTimeout((()=>{this.popupMenu&&(this.popupMenu.showing=!1),this.popupSignin&&(this.popupSignin.showing=!0,setTimeout((()=>{this.popupSignin.showing=!1}),6e3))}))})),window.addEventListener("resize",(()=>{this.bigCanvas=this.useBigCanvas(),this.linkedPanel&&this.adjustHeartPosition()})),document.addEventListener("scroll",(()=>{this.onScroll()}),{passive:!0}),this.refresh(),Ze.widgetAction(Ar,"impression",0),bi()}async refresh(){const e=Ze.currentSession;e&&e.currentPage&&(this.updateCount(e.currentPage.totalFavorites),this.voted=e.currentPage.isFavorite||!1,this.favCount=e.totalUserFavorites||0,this.visitors=e.isSuperAdmin?e.activeVisitors:0)}updateCount(e,t){const i=e||0;if(i!==this.count)if(t){const e=this.pendingCount>0;this.pendingCount=i,e||setTimeout((()=>{this.count=this.pendingCount>0?this.pendingCount:this.count,this.pendingCount=0}),1500)}else this.count=i}attachTouchListeners(){this.tracker||this.fab&&(this.tracker=new Ir(this.fab,{start:()=>(this.onDown(),!0),end:()=>{this.onUp()}}))}clearHeartDownTimer(){this.heartDownTimer&&(window.clearTimeout(this.heartDownTimer),this.heartingTimer=0)}onHeartOverlayClick(){this.onDown(),setTimeout((()=>this.onUp()))}shouldSigninToFav(){var e,t;return!("mandatory-membership"!==(null===(e=this.membership)||void 0===e?void 0:e.behavior)||!Ze.currentSession||(null===(t=Ze.currentSession.identity)||void 0===t?void 0:t.email))}onHeartClick(){var e,t;const i=!(null===(e=Ze.currentSession)||void 0===e?void 0:e.settings.membership.disableHeartPopup);switch(this.popupToShowOnClick){case"actions":i&&setTimeout((()=>{this.popupSignin.showing=!1,this.popupMenu.showing=!0}));break;case"signin":{const e=(null===(t=Ze.currentSession)||void 0===t?void 0:t.settings.membership.signinPromptsMode)||"default",i=window.innerWidth<=600;let s=!0;switch(e){case"desktop-only":s=!i;break;case"mobile-only":s=i;break;case"none":s=!1}s&&(setTimeout((()=>{this.popupMenu.showing=!1,this.popupSignin.showing=!0})),setTimeout((()=>{this.popupSignin.showing=!1}),6e3));break}}}onDown(){var e;if(this.popupToShowOnClick="none",this.onUserActivity(),!this.hearting){if(this.shouldSigninToFav())return void this.openMembershipDialog(!0);if(this.isAnimationDisabled()&&this.voted){return void(!(null===(e=Ze.currentSession)||void 0===e?void 0:e.settings.membership.disableHeartPopup)?(this.closePopups(),this.popupMenu&&(this.popupMenu.showing||(this.popupToShowOnClick="actions"))):this.removeFavorite())}this.clearHeartDownTimer(),this.hearting=!0,this.addLocalHeart(),this.nextHeartTick(),this.heartDownTimer=window.setTimeout((()=>{this.hearting&&(this.hearting=!1),this.heartingTimer=0}),1e4)}}onUp(){this.clearHeartDownTimer(),this.hearting=!1,this.notifyHearts(),this.heartingTimer&&window.clearTimeout(this.heartingTimer),this.heartingTimer=window.setTimeout((()=>{this.heartingTimer=0}),2e3)}notifyHearts(){this.heartCount&&(Ze.addHearts(this.heartCount),this.heartCount=0)}showPopupOnHeart(){var e;const t=(null===(e=Ze.currentSession)||void 0===e?void 0:e.settings.membership.signinPromptsMode)||"default",i=window.innerWidth<=600;let s=!0;switch(t){case"desktop-only":s=!i;break;case"mobile-only":s=i;break;case"none":s=!1}s&&(this.favCount>=1&&!Ze.isMemberSignedIn()?this.popupToShowOnClick="signin":(this.savedPopupShowing=!0,setTimeout((()=>{this.savedPopupShowing=!1}),2500)))}heartTick(){this.hearting&&(this.addLocalHeart(),this.nextHeartTick())}nextHeartTick(){window.setTimeout((()=>this.heartTick()),250)}addLocalHeart(){this.heartCount++,this.addHeart(),this.voted||(this.voted=!0,this.updateCount(this.count+1),this.showPopupOnHeart()),this.heartCount>3&&this.notifyHearts()}heartColor(e){if(e&&"___AUTO___"!==e){this.colorMap.has(e)||this.colorMap.set(e,this.createNewColor());const t=this.colorMap.get(e);if(t)return t}return"var(--slick-heartbeat-color, #2196f3)"}showLocation(e,t){this.locationPopup&&t&&e&&!this.isAnimationDisabled()&&(this.locationShownSet.has(e)||(this.location=t,this.locationPopup.classList.add("showing"),setTimeout((()=>{this.hideLocation()}),3e3),this.locationShownSet.add(e)))}hideLocation(){this.locationPopup&&this.locationPopup.classList.remove("showing")}createNewColor(){return this.hue+=.618033988749895,this.hue%=1,`hsl(${Math.floor(360*this.hue)}, 50%, 60%)`}countString(e){return e<=0?"":e>=1e6?`${(e/1e6).toFixed(1)}M`:e>=1e4?`${(e/1e3).toFixed(1)}k`:e.toLocaleString()}isAnimationDisabled(){return!!this.config&&!0===this.config.disableAnimation}async addHearts(e,t){if(!this.isAnimationDisabled())for(let i=0;i<e;i++)await X(250+Math.round(250*Math.random())),this.addHeart(t)}addHeart(e){var t,i;if(this.isAnimationDisabled()||document.hidden||e&&this.hearts.size>=30)return;const s=this.bigCanvas?Lr:zr,o={x:Math.round(((1-Mr)/2+Math.random()*Mr)*s.x),y:0},n={x:Math.round((.8-.2+Math.random()*Mr/2)*s.x),y:Math.round((.5+.2*Math.random())*(s.y-30))},r={x:Math.round((.25-.2+Math.random()*Mr/2)*s.x),y:Math.round((.2+.2*Math.random())*(s.y-30))},a={x:s.x-32,y:s.y-30-7};let l=!(!this.config||"right"!==this.config.tongueDirection);"rtl"===this.dir&&(l=!l),l&&(a.x=s.x-a.x,o.x=s.x-o.x,n.x=s.x-n.x,r.x=s.x-r.x);const c=(null===(t=this.iconSettings)||void 0===t?void 0:t.iconType)||"heart",h="custom"===c&&(null===(i=this.iconSettings)||void 0===i?void 0:i.customSvgFilled)||void 0,d=Math.random()>.75,p=new _r(a.x,a.y,d?r.x:n.x,n.y,d?n.x:r.x,r.y,o.x,o.y),u=new Fi;u.classList.add("heart"),u.customSvg=h,u.icon=c,u.style.color=this.heartColor(e);const g={node:u,points:p.getLUT(10),duration:Math.round(1e3*(Math.random()*(this.bigCanvas?4:2)+(this.bigCanvas?.75:.5)))};this.canvas.appendChild(g.node),this.hearts.add(g),this.animateHearts()}animateHearts(){this.animating||(this.animating=!0,window.requestAnimationFrame(this.tick.bind(this)))}tick(e){if(!this.animating)return;const t=[];for(const i of this.hearts){i.start||(i.start=e);const s=Math.min(1,(e-i.start)/i.duration),o=Math.max(0,Math.ceil(s*(i.points.length-1))-1),n=i.points[o],r=i.points[o+1],a=9*s-Math.floor(9*s),l=n.x+(r.x-n.x)*a,c=n.y+(r.y-n.y)*a;i.node.style.transform=`translate3d(${l}px, ${c}px, 0)`;let h=1;s>.6&&(h=2.5*(1-s)),i.node.style.opacity=`${h.toFixed(2)}`,1===s&&t.push(i)}t.forEach((e=>{e.node.parentElement&&e.node.parentElement.removeChild(e.node),this.hearts.delete(e)})),0===this.hearts.size?this.animating=!1:window.requestAnimationFrame(this.tick.bind(this))}openSearch(){this.closePopups(),Ze.widgetAction(Ar,"open-search",0),this.openDiscovery("search")}openFaves(){this.closePopups(),Ze.widgetAction(Ar,"open-favorites",0),this.openDiscovery("favorites")}openDiscovery(e){this.closePopups(),this.dispatchEvent(ui("slick-show-discovery",{page:e})),this.onUserActivity(),Ze.reportGAEvent("search-start","Slickstream search button clicked")}openMembershipDialog(e){var t,i;Ze.membershipService.memberSignin(e?null===(i=null===(t=Ze.currentSession)||void 0===t?void 0:t.currentPage)||void 0===i?void 0:i.id:void 0),Ze.widgetAction(Ar,"open-membership-dialog",0)}clearCompactActiveModeTimer(){this.compactActiveModeTimer&&(window.clearTimeout(this.compactActiveModeTimer),this.compactActiveModeTimer=0)}activateCompactMode(){this.clearCompactActiveModeTimer(),this.compact&&(this.compactActive=!0,this.compactActiveModeTimer=window.setTimeout((()=>{this.compactActive=!1,this.clearCompactActiveModeTimer()}),5e3))}onUserActivity(){this.compact&&this.activateCompactMode()}getScrollValue(){return void 0!==window.pageYOffset?window.pageYOffset:document.documentElement&&document.documentElement.scrollTop||document.body.scrollTop}onScroll(){if(this.compact){const e=100,t=this.getScrollValue(),i=t-(this.prevScrollValue||0),s=this.scrollingUp;this.scrollingUp=i<0,this.scrollingUp?Math.abs(i)>=e?(this.prevScrollValue=t,setTimeout((()=>this.onUserActivity()))):s||(this.prevScrollValue=t):this.prevScrollValue=t}this.refreshBttVisibility()}getIntersectionObserver(){if(!this._intersectionObserver){const e=e=>{const t=e[0];if(t){const e=this.linkedPanelShowing;t.isIntersecting||t.intersectionRatio>=.9?this.linkedPanelShowing=!0:this.linkedPanelShowing=!1,e!==this.linkedPanelShowing&&this.adjustHeartPosition()}},t={threshold:1};this._intersectionObserver=new IntersectionObserver(e,t)}return this._intersectionObserver}resetLinkedPanel(e){if(this.linkedPanel===e)return void this.adjustHeartPosition();const t=this.getIntersectionObserver();this.linkedPanel&&t.unobserve(this.linkedPanel),this.linkedPanel=e,t.observe(this.linkedPanel),this.adjustHeartPosition()}resetLinkedSelectors(){var e,t;const i=null===(t=null===(e=this.config)||void 0===e?void 0:e.linkedSelectors)||void 0===t?void 0:t.length;if(i&&i>1){const e=this.getSelectorList();e.length?this.linkTopMostElement(e):this.linkedPanel&&this.adjustHeartPosition()}else this.linkedPanel&&this.adjustHeartPosition()}linkTopMostElement(e){if(1===e.length)this.resetLinkedPanel(e[0]);else{let t=Number.MAX_SAFE_INTEGER,i=null;for(const s of e)if(s){const e=s.getBoundingClientRect(),o=e.top||e.y||0;o<t&&(t=o,i=s)}i&&this.resetLinkedPanel(i)}}getSelectorList(){var e,t;const i=[];return(null===(t=null===(e=this.config)||void 0===e?void 0:e.linkedSelectors)||void 0===t?void 0:t.length)&&this.config.linkedSelectors.forEach((e=>{const t=document.querySelector(e.trim());t&&function(e){const t=e.getBoundingClientRect();if(t.width&&t.height){const i=t.bottom||(t.top||t.y)+t.height;if(Math.abs(window.innerHeight-i)<100){if(void 0!==window.getComputedStyle){const t=window.getComputedStyle(e);if("0"===t.opacity||"hidden"===t.visibility)return!1}return!0}}return!1}(t)&&i.push(t)})),i}async attachLinkedPanel(){var e,t;if(null===(t=null===(e=this.config)||void 0===e?void 0:e.linkedSelectors)||void 0===t?void 0:t.length){const e=this.getSelectorList();if(0===e.length)return void setTimeout((()=>{this.attachLinkedPanel()}),1e3);this.linkTopMostElement(e)}this.startLinkedPanelTimer()}stopLinkedPanelTimer(){this.linkedPanelPollTimer&&(window.clearInterval(this.linkedPanelPollTimer),this.linkedPanelPollTimer=0)}startLinkedPanelTimer(){this.linkedPanel?this.linkedPanelPollTimer||(this.linkedPanelPollTimer=window.setInterval((()=>{this.resetLinkedSelectors()}),1e3)):this.stopLinkedPanelTimer()}adjustHeartPosition(){var e;let t=0;if(this.linkedPanel&&this.linkedPanelShowing){const e=this.linkedPanel.getBoundingClientRect();if(e.bottom>0&&e.top<window.innerHeight){const i=Math.max(0,window.innerHeight-e.bottom);t=e.height+i}}t=Math.max((null===(e=this.config)||void 0===e?void 0:e.minLinkedItemHeight)||0,t),this.style.transform=`translateY(${-t}px)`}focus(){this.searchFab&&this.searchFab.focus()}refreshBttVisibility(){if(this.bttEnabled&&this.bttSettings){const e=window.innerWidth<600;this.style.setProperty("--slick-btt-fab-display","flex");let t=this.bttSettings&&this.bttSettings.heightOffset||"100";e&&(t=this.bttSettings.heightOffsetMobile||t),t=t.trim();const i=t.indexOf("%")>0;let s=100;const o=/(\d+)/gi.exec(t);o&&o.length>1&&(s=+o[1]),i&&(s=window.innerHeight*(Math.min(s,100)/100));const n=(document.scrollingElement||document.body).scrollTop;this.bttShowing=n>=s}else this.style.removeProperty("--slick-btt-fab-display")}scrollToTop(){let e=(document.scrollingElement||document.body).scrollTop;if(this.bttSettings&&this.bttSettings.scrollToSelector){const t=document.querySelector(this.bttSettings.scrollToSelector);if(t){const i=t.getBoundingClientRect();e=-(i.y||i.top)}}this.animateScrollTo(e),Ze.widgetAction("back-to-top","back-to-top",0)}animateScrollTo(t){if(this.scrolling)return;e.dispatch("scrolling-page-start");const i=(document.scrollingElement||document.body).scrollTop;let s=0;const o=n=>{try{s||(s=n);const r=Math.min(1,(n-s)/500);window.scrollTo(0,i-r*t),1===r?(this.scrolling=!1,e.dispatch("scrolling-page-end")):requestAnimationFrame((e=>o(e)))}catch(t){this.scrolling=!1,window.scrollTo(0,0),e.dispatch("scrolling-page-end")}};this.scrolling=!0,requestAnimationFrame((e=>o(e)))}removeFavorite(){var e;this.closePopups();const t=null===(e=Ze.currentSession)||void 0===e?void 0:e.currentPage;t&&Ze.removeFavorite(t.id),this.voted=!1}signin(){this.closePopups(),this.openMembershipDialog(!1)}closePopups(){this.savedPopupShowing=!1}};Er([oi({type:Object}),jr("design:type",Object)],Dr.prototype,"config",void 0),Er([oi({type:Object}),jr("design:type",Object)],Dr.prototype,"membership",void 0),Er([oi({type:Object}),jr("design:type",Object)],Dr.prototype,"iconSettings",void 0),Er([oi({type:Object}),jr("design:type",Object)],Dr.prototype,"bttSettings",void 0),Er([ni(),jr("design:type",Object)],Dr.prototype,"count",void 0),Er([ni(),jr("design:type",Object)],Dr.prototype,"visitors",void 0),Er([ni(),jr("design:type",Object)],Dr.prototype,"voted",void 0),Er([ni(),jr("design:type",Object)],Dr.prototype,"favCount",void 0),Er([ni(),jr("design:type",Object)],Dr.prototype,"location",void 0),Er([ni(),jr("design:type",Boolean)],Dr.prototype,"bigCanvas",void 0),Er([ni(),jr("design:type",Object)],Dr.prototype,"animatingHeartCount",void 0),Er([ni(),jr("design:type",Object)],Dr.prototype,"compact",void 0),Er([ni(),jr("design:type",Object)],Dr.prototype,"compactActive",void 0),Er([ni(),jr("design:type",Object)],Dr.prototype,"bttShowing",void 0),Er([ni(),jr("design:type",Object)],Dr.prototype,"savedPopupShowing",void 0),Er([ai("#canvas"),jr("design:type",HTMLDivElement)],Dr.prototype,"canvas",void 0),Er([ai("#heartFab"),jr("design:type",or)],Dr.prototype,"fab",void 0),Er([ai("#searchFab"),jr("design:type",or)],Dr.prototype,"searchFab",void 0),Er([ai("#locationPopup"),jr("design:type",HTMLDivElement)],Dr.prototype,"locationPopup",void 0),Er([ai("#popupMenu"),jr("design:type",oo)],Dr.prototype,"popupMenu",void 0),Er([ai("#popupSignin"),jr("design:type",oo)],Dr.prototype,"popupSignin",void 0),Dr=Er([ii("slick-heartbeat"),jr("design:paramtypes",[])],Dr);var Hr=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Fr=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Br=class extends ei{constructor(){super(...arguments),this.favs=!0,this.minFavVisibleCount=0,this.showStoryIndicators=!1}static get styles(){return hi}render(){var e,t,i;if(!this.data)return Lt``;const s=this.data.viewerUrl||this.data.url,o=(null===(e=this.favSettings)||void 0===e?void 0:e.iconType)||"heart";return Lt`
    <style>
      * {
        box-sizing: border-box;
      }
      :host {
        display: block;
        padding: 16px 12px;
      }
      .sectionTitle {
        font-size: var(--slick-article-section-title-size, 12px);
        text-transform: uppercase;
        letter-spacing: 1px;
      }
      a.titleLink {
        text-decoration: none;
        font-size: var(--slick-article-title-size, 18px);
        color: inherit;
        outline: none;
        display: inline-block;
        border: none;
      }
      a.descLink {
        text-decoration: none;
        color: inherit;
        outline: none;
        border: none;
        -webkit-line-clamp: var(--slick-grid-text-lines, 3);
        -webkit-box-orient: vertical;
        display: -webkit-box;
        -webkit-hyphens: auto;
        -moz-hyphens: auto;
        overflow: hidden;
        hyphens: auto;
      }
      #description {
        margin: 6px 0;
        font-size: var(--slick-article-description-size, 13px);
      }
      #byline {
        margin: 4px 0 0;
        font-size: var(--slick-article-author-size, 12px);
        color: #808080;
        font-style: italic;
      }
      #inlineMetaPanel {
        margin-bottom: 4px;
      }
      .hidden {
        display: none !important;
      }
      .favCount {
        color: var(--slick-discovery-highlight-color, #2196f3);
        font-size: 13px;
        font-family: sans-serif;
        line-height: 1;
        transform: translateX(-5px);
        pointer-events: none;
      }
      slick-heart-button {
        margin: 4px 0 0 -10px;
        color: var(--slick-discovery-highlight-color, #2196f3);
      }
      #pinnedLabel.horizontal.layout {
        color: var(--slick-discovery-highlight-color, #2196f3);
        font-size: 13px;
        letter-spacing: 0.5px;
        transform: translateX(5px);
        margin-bottom: 12px;
      }
      #pinnedLabel soso-icon {
        margin-right: 8px;
        width: 20px;
        height: 20px;
      }
    </style>
    <style>
      @media (max-width: 780px) {
        :host {
          padding: 14px 6px 16px;
        }
      }
      @media(hover:hover) {
        a.titleLink:hover {
          color: var(--slick-discovery-highlight-color, #2196f3);
        }
        a.descLink:hover {
          color: var(--slick-discovery-highlight-color, #2196f3);
        }
      }
    </style>
    <div class="horizontal layout">
      <div id="mainPanel" class="flex">
        ${this.data.pinned?Lt`
        <div id="pinnedLabel" class="horizontal layout center">
          <soso-icon icon="pin"></soso-icon>
          <span>Pinned post</span>
        </div>
        `:""}
        
        <div id="inlineMetaPanel" class="horizontal layout">
          <div class="sectionTitle flex">${this.data.sectionHtml||""}</div>
        </div>
        <div class="horizontal layout">
          <div class="flex">
            <div id="titleLinkPanel">
              <a class="titleLink" @click="${this.onLinkClick}" href="${s}">${this.data.titleText||this.data.titleHtml}</a>
            </div>
            <p id="description">
              <a class="descLink" @click="${this.onLinkClick}" href="${s}">${this._decodeHtml(this.data.descriptionHtml||"")}</a>
            </p>
            ${this.data.authorHtml?Lt`<p id="byline">By ${this.data.authorHtml}</p>`:""}

            <slick-heart-button 
              class="${this.favs?"":" hidden"}"
              .minFavVisibleCount="${this.minFavVisibleCount}"
              .isFavorite="${this.data.isFavorite||!1}"
              .favIcon="${o}"
              .customSvg="${"custom"===o?null===(t=this.favSettings)||void 0===t?void 0:t.customSvgOutline:void 0}"
              .customSvgActive="${"custom"===o?null===(i=this.favSettings)||void 0===i?void 0:i.customSvgFilled:void 0}"
              .totalFavorites="${this.data.totalFavorites}"
              @toggle-favorite="${this.toggleFav}">
            </slick-heart-button>
          </div>
        </div>
      </div>

    </div>
    `}_decodeHtml(e){if("DOMParser"in window)try{const t=(new DOMParser).parseFromString(e,"text/html").documentElement.textContent;if(t)return t}catch(e){}const t=document.createElement("div");return t.innerHTML=e,t.textContent||t.innerText||e}toggleFav(){if(this.data){if(this.data.isFavorite)Ze.removeFavorite(this.data.id),this.data.totalFavorites--;else{if(Ze.shouldSigninToFav())return void pi(this,"signin-and-fav",{pageId:this.data.id});Ze.addHearts(1,this.data.id),this.data.totalFavorites++}this.data.isFavorite=!this.data.isFavorite,this.requestUpdate()}}onLinkClick(e){const t=e.currentTarget;t&&t.href&&(e.stopPropagation(),pi(this,"nav",{href:t.href}))}};Hr([oi({type:Object}),Fr("design:type",Object)],Br.prototype,"data",void 0),Hr([oi({type:Boolean}),Fr("design:type",Object)],Br.prototype,"favs",void 0),Hr([oi({type:Object}),Fr("design:type",Object)],Br.prototype,"favSettings",void 0),Hr([oi({type:Number}),Fr("design:type",Object)],Br.prototype,"minFavVisibleCount",void 0),Hr([oi({type:Boolean}),Fr("design:type",Object)],Br.prototype,"showStoryIndicators",void 0),Br=Hr([ii("content-grid-text-item")],Br);var Ur=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Nr=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const Vr="content-grid";let qr=class extends ei{constructor(){super(...arguments),this.items=[],this.pages=[],this.columns=0,this.layoutDeffered=!1}static get styles(){return hi}render(){var e,t,i,s,o,n,r,a;const l=null===(e=this.settings)||void 0===e?void 0:e.heartbeatIcon,c=(null===(t=this.config)||void 0===t?void 0:t.hideFavorites)||!1,h=(null===(s=null===(i=this.settings)||void 0===i?void 0:i.heartbeat)||void 0===s?void 0:s.minVisibleCount)||0,d=(null===(n=null===(o=this.settings)||void 0===o?void 0:o.discovery)||void 0===n?void 0:n.imageContainmentStyle)||"cover",p=(null===(r=this.settings)||void 0===r?void 0:r.showStoryIndicators)||!1,u=(null===(a=this.config)||void 0===a?void 0:a.cellLayout)||"image-card";return Lt`
    <style>
      :host {
        display: block;
        line-height: 1.5;
        --slick-discovery-cell-height: var(--slick-grid-cell-height, 128px);
      }
      search-view-page-item {
        max-width: 320px;
        width: auto;
      }
      #container {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
      }
    </style>
    <div>
      <slot></slot>
    </div>
    <div id="container" @nav="${this.onNav}" @signin-and-fav="${this.signInAndFav}">
    ${this.items.map((e=>"text-card"===u?Lt`
        <content-grid-text-item
          .data="${e}"
          .favSettings="${l}"
          .favs="${!c}"
          .showStoryIndicators="${p}"
          .minFavVisibleCount="${h}">
        </content-grid-text-item>`:Lt`
        <search-view-page-item
          class="flex"
          .data="${e}"
          .favSettings="${l}"
          .favs="${!c}"
          .showStoryIndicators="${p}"
          .minFavVisibleCount="${h}"
          .imageContainmentStyle="${d}">
        </search-view-page-item>
      `))}
    </div>
    `}firstUpdated(){Ze.currentSession?this.refresh().then((()=>this.attachIntersectionObserver())):e.subscribe("session-established",(()=>{this.items.length||this.refresh().then((()=>this.attachIntersectionObserver()))})),window.addEventListener("resize",(()=>{this.pages.length&&this.deferColumnLayout()}),{passive:!0})}deferColumnLayout(){this.layoutDeffered||(this.layoutDeffered=!0,window.requestAnimationFrame((()=>{this.layoutDeffered=!1,this.refreshColumns()})))}refreshColumns(){if(this.config&&this.pages.length){let e=this.config.itemCountWide||6;if(window.innerWidth<600&&(e=this.config.itemCountNarrow||6),e=Math.min(e,this.pages.length),e!==this.items.length){this.items=[];for(let t=0;t<e;t++){const e=this.pages[t];this.items.push(e)}}if(this.container){const t=this.container.getBoundingClientRect().width,i=Math.min(e,Math.floor(t/170)),s=Math.ceil(e/i),o=Math.max(Math.ceil(e/s),this.config.minColumns||2);o!==this.columns&&(this.columns=o,this.container.style.gridTemplateColumns=`repeat(${o}, 1fr)`)}}}async refresh(){if(this.settings&&this.config){let e=Math.max(this.config.itemCountNarrow||0,this.config.itemCountWide||0);e||(e=6),this.pages=await Ze.contentGridItems(e,this.config.id),this.refreshColumns()}}attachIntersectionObserver(){if(!this.intersectionObserver)if("IntersectionObserver"in window){const e=e=>{var t;const i=e[0];i&&i.isIntersecting&&i.intersectionRatio>.5&&(Ze.widgetAction(Vr,"impression",0),null===(t=this.intersectionObserver)||void 0===t||t.unobserve(this))},t={threshold:[0,1]};this.intersectionObserver=new IntersectionObserver(e,t),this.intersectionObserver.observe(this)}else this.intersectionObserver={},Ze.widgetAction(Vr,"impression",0)}onNav(e){var t;Ze.widgetAction(Vr,"nav",0,e.detail.href,null===(t=this.config)||void 0===t?void 0:t.id),Ze.reportGAEvent("content-grid-click","Slickstream content grid item clicked")}signInAndFav(e){var t,i;const s=null===(t=this.settings)||void 0===t?void 0:t.membership;if(null==s?void 0:s.redirectSignInToUrl)return void window.location.assign(s.redirectSignInToUrl);const o=null===(i=e.detail)||void 0===i?void 0:i.pageId;Ze.membershipService.memberSignin(o,void 0,!1,(()=>{this.refresh()})),Ze.widgetAction(Vr,"open-membership-dialog",0,void 0,void 0)}};Ur([oi({type:Object}),Nr("design:type",Object)],qr.prototype,"settings",void 0),Ur([oi({type:Object}),Nr("design:type",Object)],qr.prototype,"config",void 0),Ur([ni(),Nr("design:type",Array)],qr.prototype,"items",void 0),Ur([ai("#container"),Nr("design:type",HTMLDivElement)],qr.prototype,"container",void 0),qr=Ur([ii("slick-content-grid")],qr);class Wr{constructor(e){this.lastFavsTimestamp=0,this.hookedElements=new Set,this.handler=e=>this.openFaves(e),this.config=e}detach(){for(const e of this.hookedElements)e.removeEventListener("click",this.handler),e.removeEventListener("mousedown",this.handler),e.removeEventListener("touchend",this.handler);this.hookedElements.clear()}async attach(){this.detach();const e=(this.config.selectors||[]).map((e=>this.processSelector(e)));return Promise.all(e)}async processSelector(e){if(e){let t=null;try{t=await vi(e,5e3)}catch(e){}t&&t.length&&t.forEach((e=>{e.addEventListener("click",this.handler),e.addEventListener("mousedown",this.handler),e.addEventListener("touchend",this.handler),this.hookedElements.add(e)}))}}openFaves(e){e&&(e.preventDefault(),e.stopPropagation());const t=Date.now();t-this.lastFavsTimestamp>1e3&&(Ze.widgetAction("favorites-hook","open-favorites",0),document.dispatchEvent(ui("slick-show-discovery",{page:"favorites"}))),this.lastFavsTimestamp=t,Ze.reportGAEvent("search-hook","Site button hooked by Slickstream")}}const Gr="https://cdn.ampproject.org/amp-story-player-v0.css";let Kr=!1,Yr=null;async function Zr(){if(Kr)return!0;if(Yr)return Promise.resolve(Yr);const e=document.createElement("script");return e.setAttribute("slick-amp-story-script",""),e.setAttribute("src","https://cdn.ampproject.org/amp-story-player-v0.js"),Yr=new Promise((t=>{e.onload=()=>{Yr=null,Kr=!0,t(!0)},e.onerror=()=>{Yr=null,t(!1)},e.onabort=()=>{Yr=null,t(!1)},(document.head||document.documentElement).appendChild(e)})),Yr}var Qr=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Xr=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const Jr="story-viewer";let ea=class extends ei{constructor(){super(...arguments),this.playerWidth=300,this.playerHeight=500,this.moreButtonText="",this.hideMoreButton=!1,this.favsAllowed=!1,this.fullscreen=!1,this.fullbleed=!1,this._storyUrl="",this.lastProgress=0,this.originalOverflows=["",""]}static get styles(){return hi}render(){var e,t,i,s,o,n,r;const a=(null===(t=null===(e=Ze.currentSession)||void 0===e?void 0:e.settings.heartbeat)||void 0===t?void 0:t.minVisibleCount)||0,l=(null===(i=Ze.currentSession)||void 0===i?void 0:i.settings.heartbeatIcon.iconType)||"heart";return Lt`
    <style>
      :host {
        display: block;
        margin: 0 auto;
      }
      #container {
        display: block;
        margin: 0 auto;
      }
      amp-story-player {
        display: block;
        margin: 0 auto;
        box-shadow: var(--slick-webstory-shadow, 0 3px 3px -2px rgba(0,0,0,.2), 0 3px 4px 0 rgba(0,0,0,.14), 0 1px 8px 0 rgba(0,0,0,.12));
      }
      #footer {
        padding: 6px 0;
        color: var(--slick-webstory-footer-color, var(--slick-site-color, currentColor));
      }
      label {
        text-transform: uppercase;
        font-family: system-ui, sans-serif;
        font-size: 13px;
      }
      .clickable {
        cursor: pointer;
      }
      #shell.fullscreen {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: var(--slick-webstory-fullscreen-zindex, 2147483647);
        display: grid;
        align-content: center;
        align-items: center;
        background: rgba(255,255,255,0.97);
      }
      #shell.fullscreen.fullbleed #footer{
        display: none;
      }
      #exitFullscreenFab {
        position: absolute;
        bottom: 8px;
        right: 5px;
        --soso-fab-background: white;
        color: var(--slick-webstory-footer-color, var(--slick-site-color, currentColor));
        --soso-fab-padding: 8px;
        display: none;
      }
      #shell.fullscreen.fullbleed #exitFullscreenFab{
        display: block;
      }
      .hidden {
        display: none !important;
      }
    </style>
    <link href="${Gr}" rel="stylesheet" type="text/css">
    <div id="shell" class="${this.fullscreen?"fullscreen":""} ${this.fullbleed?"fullbleed":""}">
      <div id="container" style="width: ${this.playerWidth}px;">
        <amp-story-player 
          style="width: ${this.playerWidth}px; height: ${this.playerHeight}px;" 
          @ready="${this.playerReady}"
          @amp-story-player-restart="${this.playerRestart}"
          @storyNavigation="${this.onStoryNavigation}">
        </amp-story-player>
        <div id="footer" class="horizontal layout center">
          <soso-icon-button class="${this.hideMoreButton?"hidden":""}" icon="carousel" @click="${this.onBrowse}"></soso-icon-button>
          <label class="clickable ${this.hideMoreButton?"hidden":""}" @click="${this.onBrowse}">${this.moreButtonText}</label>
          <span class="flex"></span>

          ${this.fullscreen?Lt`<soso-icon-button icon="fullscreen-exit" title="Exit Fullscreen" @click="${this.exitFullscreen}"></soso-icon-button>`:Lt`<soso-icon-button icon="fullscreen" title="Fullscreen" @click="${this.enterFullscreen}"></soso-icon-button>`}
          
          ${this.page&&this.favsAllowed?Lt`
            <slick-heart-button 
              .minFavVisibleCount="${a}"
              .isFavorite="${!!this.page.isFavorite}"
              .favIcon="${l}"
              .customSvg="${"custom"===l?null===(o=null===(s=Ze.currentSession)||void 0===s?void 0:s.settings.heartbeatIcon)||void 0===o?void 0:o.customSvgOutline:void 0}"
              .customSvgActive="${"custom"===l?null===(r=null===(n=Ze.currentSession)||void 0===n?void 0:n.settings.heartbeatIcon)||void 0===r?void 0:r.customSvgFilled:void 0}"
              .totalFavorites="${this.page.totalFavorites}"
              .rightAlignPopup="${!0}"
              @toggle-favorite="${this.onToggleFavorite}">
            </slick-heart-button>
          `:Lt``}
        </div>
      </div>
      <soso-fab id="exitFullscreenFab" icon="fullscreen-exit" @click="${this.exitFullscreen}"></soso-fab>
    </div>
    `}firstUpdated(){if(this.asp){const e={controls:[{name:"restart",position:"start",backgroundImageUrl:"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgcHJlc2VydmVBc3BlY3RSYXRpbz0ieE1pZFlNaWQgbWVldCIgZm9jdXNhYmxlPSJmYWxzZSIgc3R5bGU9InBvaW50ZXItZXZlbnRzOiBub25lOyBkaXNwbGF5OiBibG9jazsgd2lkdGg6IDEwMCU7IGhlaWdodDogMTAwJTsiPjxnPjxwYXRoIGZpbGw9IndoaXRlIiBkPSJNMTcuNjUgNi4zNUMxNi4yIDQuOSAxNC4yMSA0IDEyIDRjLTQuNDIgMC03Ljk5IDMuNTgtNy45OSA4czMuNTcgOCA3Ljk5IDhjMy43MyAwIDYuODQtMi41NSA3LjczLTZoLTIuMDhjLS44MiAyLjMzLTMuMDQgNC01LjY1IDQtMy4zMSAwLTYtMi42OS02LTZzMi42OS02IDYtNmMxLjY2IDAgMy4xNC42OSA0LjIyIDEuNzhMMTMgMTFoN1Y0bC0yLjM1IDIuMzV6Ij48L3BhdGg+PC9nPjwvc3ZnPg=="}]},t=document.createElement("script");t.setAttribute("type","application/json"),t.textContent=JSON.stringify(e),this.asp.appendChild(t)}this.refreshSlot(),this.initializeWidget(),Ze.widgetAction(Jr,"created",0)}async initializeWidget(){if(await Zr()){this.refreshSize();const e=window.AmpStoryPlayer;this.player=new e(window,this.asp),this.player.load()}else console.warn("Failed to initialize web story player - AMP player could not load");Ze.currentSession?(this.refreshSettings(),this.attachIntersectionObserver(),setTimeout((()=>this.refreshPage()))):e.subscribe("session-established",(()=>{this.refreshSettings(),this.attachIntersectionObserver(),setTimeout((()=>this.refreshPage()))}))}refreshSettings(){var e,t,i,s;this.settings=null===(e=Ze.currentSession)||void 0===e?void 0:e.settings.storyViewer,this.moreButtonText=(null===(t=this.settings)||void 0===t?void 0:t.moreStoriesText)||"More stories",this.hideMoreButton=!!(null===(i=this.settings)||void 0===i?void 0:i.hideMoreStories);const o=(null===(s=Ze.currentSession)||void 0===s?void 0:s.settings.membership.behavior)||"optional-membership";this.favsAllowed=!("no-favorites"===o)}refreshSlot(){const e=this.querySelector("a");this.asp&&e&&(this.asp.appendChild(e),this.webStoryUrl=e.getAttribute("href")||"")}refreshSize(){if(this.fullscreen){const e=this.getBoundingClientRect().width;let t=e,i=window.innerHeight;if(e>600){const s=window.innerHeight-56;t=e,i=5/3*t,i>s&&(i=s,t=.6*i),t>950&&(t=950,i=5/3*t),i>1583&&(i=1583,t=.6*i),this.fullbleed=!1}else this.fullbleed=!0;this.playerWidth=t,this.playerHeight=i}else{const e=this.getBoundingClientRect().width;if(e>0){let t=e-20,i=5/3*t;const s=.75*window.innerHeight-60;i>s&&(i=s,t=.6*i),t>460&&(t=460,i=5/3*t),i<300&&(i=300,t=.6*i),this.playerWidth=t,this.playerHeight=i}else setTimeout((()=>this.refreshSize()),500)}}async onToggleFavorite(){this.page&&(this.page.isFavorite?(this.page.isFavorite=!1,this.page.totalFavorites=Math.max(0,this.page.totalFavorites-1),Ze.removeFavorite(this.page.id)):(this.page.isFavorite=!0,this.page.totalFavorites++,Ze.addHearts(1,this.page.id)),this.requestUpdate())}onBrowse(){var e;const t=null===(e=this.settings)||void 0===e?void 0:e.storyExplorerUrl;if(Ze.widgetAction(Jr,"drill",0),t){const e=new URL(t);e.hash=`story/${encodeURIComponent(this._storyUrl)}`,window.location.assign(e.href)}else document.dispatchEvent(ui("slick-show-discovery",{page:"stories"}))}set webStoryUrl(e){e&&e!==this._storyUrl&&(this._storyUrl=e,setTimeout((()=>this.refreshPage())))}async refreshPage(){if(Ze.currentSession&&this._storyUrl&&!this.page)try{const e=await Ze.getPageInfo(this._storyUrl);this.page=e.page}catch(e){console.log("Failed to load web story page info for ",this._storyUrl),console.log(e)}}attachIntersectionObserver(){if(!this.intersectionObserver)if("IntersectionObserver"in window){const e=e=>{var t;const i=e[0];i&&i.isIntersecting&&i.intersectionRatio>.5&&(Ze.widgetAction(Jr,"impression",0),null===(t=this.intersectionObserver)||void 0===t||t.unobserve(this))},t={threshold:[0,1]};this.intersectionObserver=new IntersectionObserver(e,t),this.intersectionObserver.observe(this)}else this.intersectionObserver={},Ze.widgetAction(Jr,"impression",0)}onStoryNavigation(e){const{pageId:t,progress:i}=e.detail;i!==this.lastProgress&&(pi(document.documentElement,"slick-engagement"),Ze.widgetAction(Jr,i>this.lastProgress?"next-page":"prev-page",100,void 0,t),this.lastProgress=i)}restartPlayer(){this._storyUrl&&this.player&&this.player.go(0,-9999)}playerReady(){this.restartPlayer()}playerRestart(){this.restartPlayer(),Ze.widgetAction(Jr,"restart",0)}enterFullscreen(){this.fullscreen||(this.fullscreen=!0,this.originalOverflows=[document.body.style.overflow||"",document.documentElement.style.overflow||""],document.body.style.overflow="hidden",document.documentElement.style.overflow="hidden",this.refreshSize(),Ze.widgetAction(Jr,"full-screen",0))}exitFullscreen(){this.fullscreen&&(this.fullscreen=!1,document.body.style.overflow=this.originalOverflows[0]||"",document.documentElement.style.overflow=this.originalOverflows[1]||"",this.refreshSize(),Ze.widgetAction(Jr,"end-full-screen",0))}};Qr([oi({type:Object}),Xr("design:type",Object)],ea.prototype,"page",void 0),Qr([oi({type:Object}),Xr("design:type",Object)],ea.prototype,"settings",void 0),Qr([ni(),Xr("design:type",Object)],ea.prototype,"playerWidth",void 0),Qr([ni(),Xr("design:type",Object)],ea.prototype,"playerHeight",void 0),Qr([ni(),Xr("design:type",Object)],ea.prototype,"moreButtonText",void 0),Qr([ni(),Xr("design:type",Object)],ea.prototype,"hideMoreButton",void 0),Qr([ni(),Xr("design:type",Object)],ea.prototype,"favsAllowed",void 0),Qr([ni(),Xr("design:type",Object)],ea.prototype,"fullscreen",void 0),Qr([ni(),Xr("design:type",Object)],ea.prototype,"fullbleed",void 0),Qr([ai("amp-story-player"),Xr("design:type",HTMLElement)],ea.prototype,"asp",void 0),ea=Qr([ii("slick-webstory-player")],ea);var ta=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},ia=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let sa=class extends ei{constructor(){super(...arguments),this.src=""}render(){return this.webStoryUrl?Lt`
    <style>
      :host {
        display: block;
      }
    </style>
    <slick-webstory-player .page="${this.pageInfo}">
      <a href="${this.webStoryUrl}">${this.pageInfo?this.pageInfo.titleText||this.pageInfo.titleHtml||this.pageInfo.descriptionHtml||this.pageInfo.url:this.webStoryUrl}</a>
    </slick-webstory-player>
    `:Lt``}updated(t){t.has("src")&&this.src&&(Ze.currentSession?this.refreshSource():e.subscribe("session-established",(()=>{this.pageInfo||this.refreshSource()})))}async refreshSource(){if(this.src){const e=await Ze.getPageInfo(this.src);this.webStoryUrl=e.webStoryUrl,this.pageInfo=e.page}else this.webStoryUrl=void 0,this.pageInfo=void 0}};ta([oi(),ia("design:type",Object)],sa.prototype,"src",void 0),ta([ni(),ia("design:type",String)],sa.prototype,"webStoryUrl",void 0),ta([ni(),ia("design:type",Object)],sa.prototype,"pageInfo",void 0),sa=ta([ii("slick-story-viewer")],sa);var oa=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},na=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let ra=class extends ei{render(){return this.webStoryUrl||this.pageInfo?Lt`
      <style>
        :host {
          display: block;
        }
      </style>
      <slick-webstory-player .page="${this.pageInfo}">
        <a href="${this.webStoryUrl||""}">${this.pageInfo?this.pageInfo.titleText||this.pageInfo.titleHtml||this.pageInfo.descriptionHtml||this.pageInfo.url:this.webStoryUrl}</a>
      </slick-webstory-player>
      `:Lt``}updated(t){t.has("config")&&this.config&&(this.refreshTitle(),Ze.currentSession?this.refreshSource():e.subscribe("session-established",(()=>{this.pageInfo||this.refreshSource()})))}async refreshSource(){if(this.config){if(this.config.url){const e=await Ze.getPageInfo(this.config.url);return this.webStoryUrl=e.webStoryUrl,void(this.pageInfo=e.page)}if(this.config.channelId&&this.config.storyId){const e=await Ze.getStoryPageInfo(this.config.channelId,this.config.storyId);return this.webStoryUrl=e.webStoryUrl,void(this.pageInfo=e.page)}}this.webStoryUrl=void 0,this.pageInfo=void 0}refreshTitle(){var e;this.config&&this.config.header&&this.config.header.trim()?(this.titleDiv||(this.titleDiv=document.createElement("div"),this.titleDiv.classList.add("slick-story-title"),this.titleDiv.style.display="contents",null===(e=this.parentElement)||void 0===e||e.insertBefore(this.titleDiv,this)),this.titleDiv.innerHTML=this.config.header.trim()):this.titleDiv&&this.titleDiv.parentElement&&(this.titleDiv.parentElement.removeChild(this.titleDiv),this.titleDiv=void 0)}};oa([ni(),na("design:type",Object)],ra.prototype,"config",void 0),oa([ni(),na("design:type",String)],ra.prototype,"webStoryUrl",void 0),oa([ni(),na("design:type",Object)],ra.prototype,"pageInfo",void 0),ra=oa([ii("slick-story-widget")],ra);var aa=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},la=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const ca=new Map;let ha=class extends ei{constructor(){super(...arguments),this.cellWidth=210,this.preventNavigation=!1,this.selected=!1,this.pendingImage=!1,this.pendingImageTimer=0,this.fetchedImages=new Map}static get styles(){return hi}render(){if(this.pendingImage=!1,this.pendingImageTimer&&(window.clearTimeout(this.pendingImageTimer),this.pendingImageTimer=0),!this.page||!this.site)return Lt``;let e=ca.get(this.page.id);e||(e=new URL(this.page.viewerUrl||this.page.url,this.site.homePageUrl).toString(),ca.set(this.page.id,e));let t="";if(this.fetchedImages.get(this.page.id))t=`background-image: url("${this.fetchedImages.get(this.page.id)}");`;else if(0===this.fetchedImages.size){const e=this.thumbnailUrl();this.fetchedImages.set(this.page.id,e),t=`background-image: url("${e}");`}else this.page.image&&(this.pendingImage=!0);const i=this.cellWidth,s=this.cellWidth*(5/3);return Lt`
    <style>
      :host {
        display: block;
        margin-top: 10px;
      }
      a, a:visited, a:hover {
        color: inherit;
        text-decoration: none;
        display: block;
        height: 100%;
      }
      #card {
        box-shadow: var(--slick-story-carousel-cell-shadow, 0 3px 1px -2px rgba(0,0,0,.2), 0 2px 2px 0 rgba(0,0,0,.14), 0 1px 5px 0 rgba(0,0,0,.12));
        background-color: transparent;
        background-size: cover;
        background-origin: border-box;
        background-position: 50% 50%;
        box-sizing: border-box;
        position: relative;
        border-radius: var(--slick-story-carousel-cell-radius, 10px);
        overflow: hidden;
      }
      #cardLink {
        position: relative;
      }
      #cardLink::after {
        content: '';
        position: absolute;
        bottom: -12px;
        left: 0;
        width: 100%;
        height: 4px;
        background: var(--slick-story-carousel-selected-color, var(--slick-site-color, #ffffff));
        opacity: 0;
        transition: opacity 0.18s ease;
        border-radius: 4px;
        pointer-events: none;
      }
      #cardLink.selected::after {
        opacity: 1;
      }

      #overlay {
        position: absolute;
        left: 0;
        right: 0;
        bottom: 0;
        background: var(--slick-story-carousel-cell-text-bg, linear-gradient(to top, rgba(0,0,0,0.7) 10%, rgba(0,0,0,0)));
        border-radius: 0 0 var(--slick-story-carousel-cell-radius, 10px) var(--slick-story-carousel-cell-radius, 10px);
        padding: 16px;
        color: var(--slick-story-carousel-font-color, white);
        font-size: var(--slick-story-carousel-font-size, 18px);
        font-weight: var(--slick-story-carousel-font-weight, 400);
        pointer-events: none;
      }
      #pageTitle {
        line-height: var(--slick-story-carousel-line-height, 1.25);
        -webkit-line-clamp: var(--slick-story-carousel-text-lines, 3);
        -webkit-box-orient: vertical;
        display: -webkit-box;
        overflow: hidden;
      }

      @media (max-width: 600px) {
        #overlay {
          padding: 12px;
          font-size: var(--slick-story-carousel-font-size, 15px);
        }
      }

      @media(hover:hover) {
        #card {
          transition: box-shadow 0.3s ease, transform 0.28s ease;
        }
        #card:hover {
          transform: scale(1.03);
          box-shadow: var(--slick-story-carousel-cell-shadow, 0 2px 4px -1px rgba(0,0,0,.2), 0 4px 5px 0 rgba(0,0,0,.14), 0 1px 10px 0 rgba(0,0,0,.12));
        }
      }

      
    </style>
    <a id="cardLink" class="${this.selected?"selected":""}" href="${e}" @click="${this.onNav}">
      <div id="card" style="width: ${i}px; height: ${s}px; ${t}">
        <div id="overlay" class="vertical layout">
          <div id="pageTitle">${this.page.titleText||this.page.titleHtml||this.page.descriptionHtml}</div>
        </div>
      </div>
    </a>
    `}updated(){this.pendingImage&&(this.pendingImageTimer=window.setTimeout((()=>{if(this.page&&this.pendingImage&&this.page.image){let e=this.fetchedImages.get(this.page.id);e||(e=this.thumbnailUrl(),this.fetchedImages.set(this.page.id,e)),this.card.style.backgroundImage=`url("${e}")`}this.pendingImage=!1}),100))}thumbnailUrl(){if(this.page){const e=this.cellWidth,t=e*(5/3);return Ze.thumbnailUrl(this.page,e,t)||""}return""}onNav(e){e.stopPropagation(),this.preventNavigation&&e.preventDefault(),pi(this,"nav",this.page)}};aa([oi({type:Number}),la("design:type",Object)],ha.prototype,"cellWidth",void 0),aa([oi({type:Boolean}),la("design:type",Object)],ha.prototype,"preventNavigation",void 0),aa([oi({type:Boolean}),la("design:type",Object)],ha.prototype,"selected",void 0),aa([ni(),la("design:type",Object)],ha.prototype,"page",void 0),aa([ni(),la("design:type",Object)],ha.prototype,"site",void 0),aa([ai("#card"),la("design:type",HTMLDivElement)],ha.prototype,"card",void 0),ha=aa([ii("slick-story-carousel-item")],ha);var da=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},pa=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let ua=class extends ei{constructor(){super(...arguments),this.preventNavigation=!1,this.leftScroll=!1,this.rightScroll=!0,this.pages=[],this.cellheight=-1,this.cellwidth=-1,this.cellgap=-1,this.cellMap=new Map}static get styles(){return hi}render(){return this.resolveSizes(),Lt`
    <style>
      :host {
        display: block;
      }
      #container {
        position: relative;
        box-sizing: border-box;
        display: block;
      }
      #overlay {
        position: absolute;
        top: 0;
        right: 0;
        left: 0;
        bottom: 0;
        pointer-events: none;
        padding: 0 12px;
      }
      soso-icon-button {
        background: var(--slick-strip-icon-bg, rgba(255,255,255,0.8));
        border-radius: 50%;
        --soso-icon-button-padding: 4px;
        cursor: pointer;
        transition: opacity 0.3s ease;
        opacity: 0;
        color: var(--slick-icon-color, var(--slick-discovery-highlight-color, #000));
        transition: transform 0.28s ease;
      }
      soso-icon-button.showing {
        opacity: 1;
        pointer-events: auto;
      }

      @media (max-width: 600px) {
        #overlay {
          padding: 0 4px;
        }
      }

      @media(hover: hover) {
        #overlay {
          opacity: 0;
          transition: opacity 0.18s ease;
        }
        #container:hover #overlay {
          opacity: 1;
        }
        soso-icon-button:hover {
          background: var(--slick-strip-icon-bg, rgba(255,255,255,1));
          transform: scale(1.1);
        }
      }
    </style>
    <div id="container">
      <horiz-slider-view 
        id="scroller"
        .cellheight="${this.cellheight}"
        .cellwidth="${this.cellwidth+this.cellgap}"
        @scrolled="${this.onStripScroll}">
      </horiz-slider-view>
      <div id="overlay" class="horizontal layout center">
        <soso-icon-button label="Scroll left" icon="chevron-left" class="${this.leftScroll?"showing":""}" @click="${this.prevPage}"></soso-icon-button>
        <span class="flex"></span>
        <soso-icon-button label="Scroll right" icon="chevron-right" class="${this.rightScroll?"showing":""}" @click="${this.nextPage}"></soso-icon-button>
      </div>
    </div>
    `}getSizeProperty(e){const t=(window.getComputedStyle(this).getPropertyValue(e)||"").trim();if(t){const e=t.match(/\d+/g);if(e&&e[0]){const t=+e[0];if(!Number.isNaN(t))return t}}}resolveSizes(){const e=window.innerWidth<800;this.cellgap<=0&&(this.cellgap=this.getSizeProperty("--slick-story-carousel-cell-gap")||(e?16:20)),this.cellwidth<=0&&(this.cellwidth=this.getSizeProperty("--slick-story-carousel-cell-width")||(e?120:180),this.cellheight=this.cellwidth*(5/3)+24)}onStripScroll(e){this.pendingScroll||setTimeout((()=>{this.pendingScroll&&this.scroller&&(this.leftScroll=this.pendingScroll.scrollLeft>0,this.rightScroll=this.pendingScroll.scrollWidth-(this.pendingScroll.scrollLeft+this.scroller.getBoundingClientRect().width)>0,this.pendingScroll=void 0)}),300),this.pendingScroll=e.detail}nextPage(){this.scroller.nextScrollPage()}prevPage(){this.scroller.prevScrollPage()}firstUpdated(){this.pages&&this.scroller&&(this.scroller.delegate=this)}set stories(e){this.cellMap.clear(),this.pages=e||[],this.scroller&&(this.scroller.delegate=this)}set selected(e){if(e!==this._selectedId){if(this._selectedId){const e=this.cellMap.get(this._selectedId);e&&(e.selected=!1)}if(this._selectedId=e,e){const t=this.cellMap.get(e);t&&(t.selected=!0)}}}get length(){return this.pages.length}createElement(){const e=new ha;return e.cellWidth=this.cellwidth,e.style.marginLeft=this.cellgap/2+"px",e.style.marginRight=this.cellgap/2+"px",e}updateElement(e,t){const i=e,s=this.pages[t];i.site=this.site,i.page=s,i.preventNavigation=this.preventNavigation,i.selected=s.id===this._selectedId,this.cellMap.set(s.id,i)}};da([oi({type:Boolean}),pa("design:type",Object)],ua.prototype,"preventNavigation",void 0),da([ni(),pa("design:type",Object)],ua.prototype,"leftScroll",void 0),da([ni(),pa("design:type",Object)],ua.prototype,"rightScroll",void 0),da([ai("#scroller"),pa("design:type",$i)],ua.prototype,"scroller",void 0),ua=da([ii("slick-story-carousel")],ua);var ga=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},fa=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let va=class extends ei{constructor(){super(...arguments),this.stories=[],this.widget="story-carousel"}render(){return Lt`
    <style>
      :host {
        display: block;
      }
    </style>
    <div>
      <slot></slot>
    </div>
    <slick-story-carousel .site="${this.site}" .stories="${this.stories}" @nav="${this.onNav}"></slick-story-carousel>
    `}firstUpdated(){Ze.currentSession?this.refresh():e.subscribe("session-established",(()=>{this.stories.length||this.refresh()}))}async refresh(){this.site=(await Ze.getSiteInfo()).site,this.stories=await Ze.populateStories(),await this.updateComplete,this.attachIntersectionObserver(),Ze.widgetAction(this.widget,"created",0)}attachIntersectionObserver(){if(!this.intersectionObserver)if("IntersectionObserver"in window){const e=e=>{var t;const i=e[0];i&&i.isIntersecting&&i.intersectionRatio>.5&&(Ze.widgetAction(this.widget,"impression",0),null===(t=this.intersectionObserver)||void 0===t||t.unobserve(this))},t={threshold:[0,1]};this.intersectionObserver=new IntersectionObserver(e,t),this.intersectionObserver.observe(this)}else this.intersectionObserver={},Ze.widgetAction(this.widget,"impression",0)}onNav(e){const t=e.detail;t&&Ze.widgetAction(this.widget,"nav",0,t.viewerUrl||t.url)}};ga([ni(),fa("design:type",Array)],va.prototype,"stories",void 0),ga([ni(),fa("design:type",Object)],va.prototype,"site",void 0),va=ga([ii("slick-story-carousel-widget")],va);class ma{constructor(e,t){this.map=new Map,this.keys=[],this._capacity=e||100,this._listener=t}_bump(e){const t=this.keys.filter((t=>t!==e));t.unshift(e),this.keys=t}_trim(){const e=[],t=[];for(;this.keys.length>this._capacity;){const t=this.keys.pop();t&&e.push(t)}e.length&&(e.forEach((e=>{const i=this.map.get(e);i&&t.push(i),this.map.delete(e)})),this._listener&&this._listener.onKeysDiscarded(e,t))}has(e){return this.map.has(e)}get(e){const t=this.map.get(e);return this._bump(e),t}set(e,t){this.has(e)?(this.map.set(e,t),this.keys.unshift(e)):(this.map.set(e,t),this._bump(e)),setTimeout((()=>{this._trim()}))}clear(){this.map.clear(),this.keys=[]}}var ya=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},ba=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const wa="story-explorer";let xa=class extends ei{constructor(){super(...arguments),this.playerWidth=300,this.playerHeight=500,this.current=null,this.fullscreen=!1,this.fullbleed=!1,this.mobile=window.innerWidth<=600,this.stories=[],this.playerMap=new ma(this.mobile?4:8,this),this.pageMap=new Map,this.firstRoute=!0,this.originalOverflows=["",""],this._pendingScrollToView=!1,this._playerSized=!1,this._lastProgress=0,this.storyNavigationListener=e=>{const{pageId:t,progress:i}=e.detail;i!==this._lastProgress&&(pi(document.documentElement,"slick-engagement"),Ze.widgetAction(wa,i>this._lastProgress?"next-page":"prev-page",100,void 0,t),this._lastProgress=i)}}onKeysDiscarded(e,t){for(const e of t){try{e.pause()}catch(e){}e._node.removeEventListener("storyNavigation",this.storyNavigationListener),e._node.remove()}}static get styles(){return hi}render(){var e,t,i,s,o,n,r,a,l;const c=!("no-favorites"===((null===(e=this.settings)||void 0===e?void 0:e.membership.behavior)||"optional-membership")),h=this.current&&(this.current.titleText||this.current.titleHtml)||"",d=(null===(i=null===(t=Ze.currentSession)||void 0===t?void 0:t.settings.heartbeat)||void 0===i?void 0:i.minVisibleCount)||0,p=(null===(s=Ze.currentSession)||void 0===s?void 0:s.settings.heartbeatIcon.iconType)||"heart";return Lt`
    <link href="${Gr}" rel="stylesheet" type="text/css">
    <style>
      :host {
        --slick-story-carousel-cell-width: var(--slick-story-explorer-cell-width, 120);
        --slick-story-carousel-cell-gap: var(--slick-story-explorer-cell-gap, 12);
        --slick-story-carousel-font-size: var(--slick-story-explorer-font-size, 15px);
      }
      amp-story-player {
        display: block;
        margin: 0 auto;
        box-shadow: var(--slick-webstory-shadow, 0 3px 3px -2px rgba(0,0,0,.2), 0 3px 4px 0 rgba(0,0,0,.14), 0 1px 8px 0 rgba(0,0,0,.12));
        transition: opacity 0.2s ease, transform 0.28s ease;
        opacity: 0;
        transform: scale(0.8);
        pointer-events: none;
        overflow: hidden;
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
      }
      amp-story-player.active {
        pointer-events: auto;
        opacity: 1;
        transform: none;
      }
      amp-story-player a:not(:first-of-type) {
        display: none;
      }
      #viewerContainer {
        margin: 0 auto;
        padding: 40px 0 140px;
        position: relative;
      }
      #footer {
        padding: 6px 0;
      }
      #footer soso-icon-button {
        color: var(--slick-webstory-footer-color, var(--slick-site-color, currentColor));
      }
      .clickable {
        cursor: pointer;
      }
      #storyTitle {
        font-size: var(--slick-story-explorer-title-size, 14px);
        font-family: inherit;
        font-weight: inherit;
        padding: 10px 0 0 0;
        text-transform: capitalize;
      }
      #shell.fullscreen {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: var(--slick-webstory-fullscreen-zindex, 2147483647);
        display: grid;
        align-content: center;
        align-items: center;
        background: rgba(255,255,255,0.97);
      }
      #shell.fullscreen.fullbleed #footer{
        display: none;
      }
      #exitFullscreenFab {
        position: absolute;
        bottom: 8px;
        right: 5px;
        --soso-fab-background: white;
        color: var(--slick-webstory-footer-color, var(--slick-site-color, currentColor));
        --soso-fab-padding: 8px;
        display: none;
      }
      #shell.fullscreen.fullbleed #exitFullscreenFab{
        display: block;
      }
      #shell.fullscreen #viewerContainer {
        padding: 0 !important;
      }
      #shell.fullscreen #storyTitle {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      slick-heart-button {
        color: var(--slick-discovery-highlight-color, #2196f3);
      }

      @media (max-width: 600px) {
        :host {
          display: block;
          --slick-story-carousel-cell-width: var(--slick-story-explorer-cell-width, 90);
          --slick-story-carousel-cell-gap: var(--slick-story-explorer-cell-gap, 8);
          --slick-story-carousel-font-size: var(--slick-story-explorer-font-size, 14px);
        }
        #viewerContainer {
          padding: 20px 0 120px;
          position: relative;
        }
        #footer {
          padding: 2px 0;
        }
        #storyTitle {
          font-size: var(--slick-story-explorer-title-size, 13px);
        }
      }
    </style>
    <div>
      <slot></slot>
    </div>
    <slick-story-carousel .selected="${null===(o=this.current)||void 0===o?void 0:o.id}" .preventNavigation="${!0}" @nav="${this.onNav}"></slick-story-carousel>
    <div id="shell" class="${this.fullscreen?"fullscreen":""} ${this.fullbleed?"fullbleed":""}">
      <div id="viewerContainer" style="width: ${this.playerWidth}px;">
        <div id="playerPanel" style="position: relative; width: ${this.playerWidth}px; height: ${this.playerHeight}px;"></div>

        <div id="footer" class="horizontal layout">
          <div id="storyTitle" class="flex">${h}</span></div>
          <div>
          ${this.fullscreen?Lt`<soso-icon-button icon="fullscreen-exit" title="Exit Fullscreen" @click="${this.exitFullscreen}"></soso-icon-button>`:Lt`<soso-icon-button icon="fullscreen" title="Fullscreen" @click="${this.enterFullscreen}"></soso-icon-button>`}
          </div>
          <div>
          ${this.current&&c?Lt`
            <slick-heart-button 
              .minFavVisibleCount="${d}"
              .isFavorite="${!!this.current.isFavorite}"
              .favIcon="${p}"
              .customSvg="${"custom"===p?null===(r=null===(n=Ze.currentSession)||void 0===n?void 0:n.settings.heartbeatIcon)||void 0===r?void 0:r.customSvgOutline:void 0}"
              .customSvgActive="${"custom"===p?null===(l=null===(a=Ze.currentSession)||void 0===a?void 0:a.settings.heartbeatIcon)||void 0===l?void 0:l.customSvgFilled:void 0}"
              .totalFavorites="${this.current.totalFavorites}"
              .rightAlignPopup="${!0}"
              @toggle-favorite="${this.onToggleFavorite}">
            </slick-heart-button>
          `:Lt``}
          </div>
        </div>
      </div>
      <soso-fab id="exitFullscreenFab" icon="fullscreen-exit" @click="${this.exitFullscreen}"></soso-fab>
    </div>
    `}firstUpdated(){Ze.widgetAction(wa,"created",0),e.subscribe("route",(e=>this.handleHashChange(e))),e.subscribe("session-established",(()=>{void 0!==this._pendingStoryUrl&&(this.loadStory(this._pendingStoryUrl,this._pendingScrollToView),this._pendingStoryUrl=void 0)}))}async handleHashChange(e){let t="";"story"===e.path&&e.segments.length>=2&&(t=e.segments[1]);const i=!(!t||!this.firstRoute);this.firstRoute=!1,Ze.currentSession?await this.loadStory(t,i):(this._pendingScrollToView=i,this._pendingStoryUrl=t)}async loadStory(e,t){await this.refreshCarousel(e),!e&&this.stories.length&&(e=this.stories[0].url),await this.playStory(e),t&&this.footer&&this.footer.scrollIntoView({behavior:"smooth",block:"end",inline:"nearest"})}async refreshCarousel(e){if(!this.stories.length){this.pageMap.clear();const t=(await Ze.getSiteInfo()).site;let i=await Ze.populateStories();if(e){let t=null;if(i=i.filter((i=>i.url.toLowerCase()!==e.toLowerCase()||(t=i,!1))),t)i.unshift(t);else{const t=await this.fetchPage(e);t&&i.unshift(t)}}this.stories=i,this.carousel&&(this.carousel.site=t,this.carousel.stories=this.stories)}}async fetchPage(e){const t=this.pageMap.get(e.toLowerCase());if(t)return t;try{const t=await Ze.getPageInfo(e);return t.page?(this.pageMap.set(e.toLowerCase(),t.page),t.page):(console.log(`Failed to find page"${e}"`),null)}catch(t){return console.log(`Failed to find page"${e}"`,t),null}}_refreshPlayerSize(){var e,t,i,s;if(this.fullscreen){const e=this.getBoundingClientRect().width;let t=e,i=window.innerHeight;if(e>600){const s=window.innerHeight-56;t=e,i=5/3*t,i>s&&(i=s,t=.6*i),t>950&&(t=950,i=5/3*t),i>1583&&(i=1583,t=.6*i),this.fullbleed=!1}else this.fullbleed=!0;this.playerWidth=t,this.playerHeight=i}else{const o=this.getBoundingClientRect().width;if(o>0){let n=o-4,r=5/3*n;const a=this.mobile?(null===(t=null===(e=this.settings)||void 0===e?void 0:e.storyExplorer)||void 0===t?void 0:t.reservedSpaceMobile)||90:(null===(s=null===(i=this.settings)||void 0===i?void 0:i.storyExplorer)||void 0===s?void 0:s.reservedSpace)||90,l=this.mobile?194:264,c=window.innerHeight-(l+a);r>c&&(r=c,n=.6*r),n>460&&(n=460,r=5/3*n),r<300&&(r=300,n=.6*r),this.playerWidth=n,this.playerHeight=r,this._playerSized=!0}else setTimeout((()=>this.refreshPlayerSize()),500)}}refreshPlayerSize(){this._playerSized||this._refreshPlayerSize()}async initializePlayer(e){this.refreshPlayerSize(),await Zr();const t=document.createElement("amp-story-player");t.innerHTML=`<a href="${e}"></a>`,this.playerPanel.appendChild(t);const i=new(0,window.AmpStoryPlayer)(window,t);return i._node=t,this.playerMap.set(e,i),t.addEventListener("storyNavigation",this.storyNavigationListener),i}async playStory(e){this.currentPlayer&&this.currentPlayer.pause();let t=this.playerMap.get(e);t?(null==t||t.go(0,-9999),t.play()):(t=await this.initializePlayer(e),t.load(),setTimeout((()=>{t===this.currentPlayer&&(null==t||t.go(0,-9999))}),1e3)),t._node.classList.add("active"),this.currentPlayer&&this.currentPlayer._node.classList.remove("active"),this.currentPlayer=t,e&&(this.current=await this.fetchPage(e),this.current&&Ze.widgetAction(wa,"story-loaded",100,this.current.url))}async onToggleFavorite(){this.current&&(this.current.isFavorite?(this.current.isFavorite=!1,this.current.totalFavorites=Math.max(0,this.current.totalFavorites-1),Ze.removeFavorite(this.current.id)):(this.current.isFavorite=!0,this.current.totalFavorites++,Ze.addHearts(1,this.current.id)),this.requestUpdate())}onNav(e){const t=e.detail;t&&(t.id!==(this.current?this.current.id:-1)?(Ze.goto(["story",t.url]),Ze.widgetAction(wa,"select",0,t.url)):this.currentPlayer&&this.currentPlayer.go(0,-9999))}enterFullscreen(){this.fullscreen||(this.fullscreen=!0,this.originalOverflows=[document.body.style.overflow||"",document.documentElement.style.overflow||""],document.body.style.overflow="hidden",document.documentElement.style.overflow="hidden",this._refreshPlayerSize(),Ze.widgetAction(wa,"full-screen",0))}exitFullscreen(){this.fullscreen&&(this.fullscreen=!1,document.body.style.overflow=this.originalOverflows[0]||"",document.documentElement.style.overflow=this.originalOverflows[1]||"",this._refreshPlayerSize(),Ze.widgetAction(wa,"end-full-screen",0))}};ya([ni(),ba("design:type",Object)],xa.prototype,"settings",void 0),ya([ni(),ba("design:type",Object)],xa.prototype,"playerWidth",void 0),ya([ni(),ba("design:type",Object)],xa.prototype,"playerHeight",void 0),ya([ni(),ba("design:type",Object)],xa.prototype,"current",void 0),ya([ni(),ba("design:type",Object)],xa.prototype,"fullscreen",void 0),ya([ni(),ba("design:type",Object)],xa.prototype,"fullbleed",void 0),ya([ai("#playerPanel"),ba("design:type",HTMLDivElement)],xa.prototype,"playerPanel",void 0),ya([ai("slick-story-carousel"),ba("design:type",ua)],xa.prototype,"carousel",void 0),ya([ai("#footer"),ba("design:type",HTMLDivElement)],xa.prototype,"footer",void 0),xa=ya([ii("slick-story-explorer")],xa);var ka=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Sa=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let _a=class extends Ds{constructor(){super(...arguments),this._showing=!1,this._toast={message:""},this._closeTimer=0}render(){return Lt`
    <style>
      #toast {
        position: fixed;
        left: 12px;
        bottom: 12px;
        padding: 6px 16px;
        margin-right: 20px;
        min-height: 48px;
        max-width: 800px;
        font-size: 14px;
        font-family: ${Fs};
        z-index: var(--slick-toast-zindex, var(--slick-search-panel-zindex, 2147483647));
        transition: ${Hs};
        background: var(--slick-toast-background, #323232);
        color: var(--slick-toast-color, #ffffff);
        border-radius: 3px;
        opacity: 0;
        transform: translate3d(0, 150%, 0);
        pointer-events: none;
      }
      #toast.showing {
        opacity: 1;
        transform: none;
        pointer-events: auto;
      }
      #buttonPanel {
        padding-left: 12px;
      }
      soso-button {
        color: var(--slick-toast-color, #90CAF9);
      }

      @media (max-width: 600px) {
        #toast {
          left: 0;
          bottom: 0;
          width: 100%;
          margin-right: 0;
          padding: 10px 16px;
          border-radius: 0;
        }
      }
    </style>
     <style rtl>
      :host([dir="rtl"]) #buttonPanel {
        padding-right: 12px;
        padding-left: 0;
      }
      :host([dir="rtl"]) #toast {
        left: initial;
        right: 12px;
        margin-left: 20px;
      }
      @media (max-width: 600px) {
        :host([dir="rtl"]) #toast {
          right: 0;
          margin-left: 0;
        }
      }
    </style>
    
    <div id="toast" class="horizontal center ${this._showing?"showing":""}">
      <div class="flex">${this._toast.message}</div>
      ${this._toast.action?Lt`
      <div id="buttonPanel">
        <soso-button @click="${this.onAction}">${this._toast.action}</soso-button>
      </div>
      `:""}
    </div>
    `}show(e){this.cancelTimer(),this._toast=e,this._show(e.duration||4e3)}onAction(){this._hide(),this._toast.actionHandler&&this._toast.actionHandler(this._toast)}cancelTimer(){this._closeTimer&&(window.clearTimeout(this._closeTimer),this._closeTimer=0)}_hide(){this.cancelTimer(),this._showing=!1}_show(e){this._showing=!0,this.cancelTimer(),this._closeTimer=window.setTimeout((()=>{this._showing&&this._hide()}),e)}};ka([ni(),Sa("design:type",Object)],_a.prototype,"_showing",void 0),ka([ni(),Sa("design:type",Object)],_a.prototype,"_toast",void 0),_a=ka([ii(We)],_a);var Ca=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},$a=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Pa=class extends Ds{constructor(){super(...arguments),this.slotId="",this.slotHTML=""}render(){return Lt`
    <style>
      :host {
        display: block;
      }
    </style>
    <div id="container" @click="${this.handleClick}"></div>
    `}updated(e){e.has("slotHTML")&&(this._container.innerHTML=this.slotHTML||""),this.slotId&&this.slotHTML&&this.attachIntersectionObserver()}attachIntersectionObserver(){if(!this._intersectionObserver)if("IntersectionObserver"in window){const e=e=>{var t;const i=e[0];i&&i.isIntersecting&&i.intersectionRatio>.5&&(Ze.notifySlotImpression(this.slotId),null===(t=this._intersectionObserver)||void 0===t||t.unobserve(this))},t={threshold:[0,1]};this._intersectionObserver=new IntersectionObserver(e,t),this._intersectionObserver.observe(this)}else this._intersectionObserver={},Ze.notifySlotImpression(this.slotId)}handleClick(e){const t=e.srcElement||e.target;if(t){let e=null,i=t;const s=["body","head","html"];for(;i&&i.tagName;){const t=i.tagName.toLowerCase();if(s.indexOf(t)>=0)break;if("a"===t){e=i;break}i=i.parentElement}e&&Ze.notifySlotAction(this.slotId,e.href)}}};Ca([oi(),$a("design:type",Object)],Pa.prototype,"slotId",void 0),Ca([oi(),$a("design:type",Object)],Pa.prototype,"slotHTML",void 0),Ca([ai("#container"),$a("design:type",HTMLDivElement)],Pa.prototype,"_container",void 0),Pa=Ca([ii("slick-content-slot")],Pa);class Ia{constructor(){this.containers=new Map,this._subscribed=!1}refresh(){Ze.currentSession?this._doRefresh():this._subscribed||(e.subscribe("session-established",(()=>{this._doRefresh()})),this._subscribed=!0)}clearContainers(){this.containers.forEach((e=>{e.innerHTML=""})),this.containers.clear()}async _doRefresh(){const e=[],t=document.querySelectorAll(".slick-content-slot"),i=new Map;for(let s=0;s<t.length;s++){const o=t[s];if(o){const t=o.dataset.slot;t&&(i.set(t,o),e.push({id:t,width:o.getBoundingClientRect().width}))}}const s=e.length?await Ze.populateSlots(e):[];this.clearContainers(),this.containers=i;for(const e of s){const t=this.containers.get(e.id);if(t){const i=new Pa;i.slotId=e.id,i.slotHTML=e.innerHtml||"",t.appendChild(i)}}}}let Ta=null;const Oa=new Set,Ra=new Map;const Ea=new class{async getGame(){if(this.game)return this.game;if(this.pending)return Promise.resolve(this.pending);this.pending=Ze.getGame();const e=await Promise.resolve(this.pending);return this.game=e,this.pending=void 0,this.game}};var ja=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},La=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const za="game";let Ma=class extends ei{constructor(){super(...arguments),this.header="",this.intersectionObserverAttached=!1,this.intersectionNotified=!1,this.intersectionHandler=e=>{const t=e[0];!this.intersectionNotified&&t&&t.isIntersecting&&t.intersectionRatio>=.5&&(Ze.widgetAction(za,"impression",0),this.intersectionNotified=!0)}}render(){return Lt`
    <style>
      :host {
        display: block;
        max-width: var(--slick-game-max-width, 380px);
        margin: 0 auto;
      }
      #gameContainer {
        position: relative;
        display: block;
        box-sizing: border-box;
      }
    </style>
    <div id="gameContainer" @update-state="${this.updateState}" @nav="${this.onNav}"></div>
    `}updated(){this.refresh()}async refresh(){var e;let t;this.header?(this.titleDiv||(this.titleDiv=document.createElement("div"),this.titleDiv.classList.add("slick-game-title"),this.titleDiv.style.display="contents",null===(e=this.parentElement)||void 0===e||e.insertBefore(this.titleDiv,this)),this.titleDiv.innerHTML=this.header.trim()):this.titleDiv&&this.titleDiv.parentElement&&(this.titleDiv.parentElement.removeChild(this.titleDiv),this.titleDiv=void 0);try{this.manifestString&&(t=JSON.parse(this.manifestString))}catch(e){console.error("Failed to parse game manifest from config"),t=void 0}if(this.game=await Ea.getGame(),this.game&&this.game.srcUrl&&this.game.manifest&&this.game.manifest.tag){this.manifest=this.game.manifest,await async function(e){if(Oa.has(e))return;const t=Ra.get(e);if(t)return Promise.resolve(t);const i=new Promise(((t,i)=>{const s=document.createElement("script");s.async=!0,s.onerror=()=>{Ra.delete(e),i(new Error("Failed to load script"))},s.onabort=()=>{Ra.delete(e),i(new Error("Failed to load script - aborted"))},s.onload=()=>{Ra.delete(e),Oa.add(e),t()},s.src=e,document.head.appendChild(s)}));return Ra.set(e,i),Promise.resolve(i)}(this.game.srcUrl);const e=document.createElement(this.manifest.tag);if(e.page=this.game.pageInfo,e.status=this.game.status,e.data=this.game.data,t&&t[this.game.type]&&(e.manifest=t[this.game.type]),this.gameContainer){for(;this.gameContainer.hasChildNodes()&&this.gameContainer.lastChild;)this.gameContainer.removeChild(this.gameContainer.lastChild);this.gameContainer.appendChild(e)}}this.attachIntersectionObserver()}attachIntersectionObserver(){if(!this.intersectionObserverAttached)if(this.intersectionObserverAttached=!0,"IntersectionObserver"in window){const e={threshold:.5};new IntersectionObserver(this.intersectionHandler,e).observe(this)}else this.intersectionNotified||(Ze.widgetAction(za,"impression",0),this.intersectionNotified=!0)}updateState(e){if(this.game){const t=e.detail;t.status&&Ze.updateGame(this.game.id,t.status,t.data)}}onNav(){this.game&&this.game.pageInfo&&Ze.widgetAction(za,"nav",0,this.game.pageInfo.url,this.game.type)}};ja([oi(),La("design:type",String)],Ma.prototype,"manifestString",void 0),ja([oi(),La("design:type",Object)],Ma.prototype,"header",void 0),ja([ai("#gameContainer"),La("design:type",HTMLDivElement)],Ma.prototype,"gameContainer",void 0),Ma=ja([ii("slick-game")],Ma);const Aa=it`
  .horiz {display: flex; flex-direction: row;}
  .vert {display: flex; flex-direction: column;}
  .center {align-items: center;}
  .center2 {justify-content: center; align-items: center;}
  .flex {flex: 1;}
  .wrap {flex-wrap: wrap;}
`,Da=it`
  :host {
    --c4-font-family-default: "SF Pro Display", -apple-system, BlinkMacSystemFont, "San Francisco", "Helvetica Neue", Helvetica, Ubuntu, Roboto, Noto, "Segoe UI", Arial, sans-serif;
    font-family: var(--c4-font-family, var(--c4-font-family-default));
  }
`;class Ha extends ei{fire(e,t){const i={bubbles:!0,composed:!0,detail:t};this.dispatchEvent(t?new CustomEvent(e,i):new Event(e,i))}}Ha.styles=[it`
    * {box-sizing: border-box;}
    [hidden] {display: none !important;}
  `,Aa];const Fa=ji(class extends Li{constructor(e){var t;if(super(e),e.type!==Ri||"class"!==e.name||(null===(t=e.strings)||void 0===t?void 0:t.length)>2)throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.")}render(e){return" "+Object.keys(e).filter((t=>e[t])).join(" ")+" "}update(e,[t]){var i,s;if(void 0===this.it){this.it=new Set,void 0!==e.strings&&(this.nt=new Set(e.strings.join(" ").split(/\s/).filter((e=>""!==e))));for(const e in t)t[e]&&!(null===(i=this.nt)||void 0===i?void 0:i.has(e))&&this.it.add(e);return this.render(t)}const o=e.element.classList;this.it.forEach((e=>{e in t||(o.remove(e),this.it.delete(e))}));for(const e in t){const i=!!t[e];i===this.it.has(e)||(null===(s=this.nt)||void 0===s?void 0:s.has(e))||(i?(o.add(e),this.it.add(e)):(o.remove(e),this.it.delete(e)))}return zt}});const Ba=new class{constructor(){this._map=new Map}get(e){return this._map.get(e)||null}define(e){for(const t in e)this._map.set(t,e[t])}clear(){this._map.clear()}};var Ua=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Na=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Va=class extends Ha{render(){if(this.icon){const e=Ba.get(this.icon)||this.icon;return Lt`
        <svg viewBox="0 0 24 24" preserveAspectRatio="xMidYMid meet" focusable="false">
          <g>
            <path d=${e}></path>
          </g>
        </svg>
      `}return Lt`<slot></slot>`}};Va.styles=[Ha.styles,it`
      :host {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        position: relative;
        vertical-align: middle;
        fill: currentColor;
        stroke: none;
        width: 24px;
        height: 24px;
      }
      svg {
        pointer-events: none;
        display: block;
        width: 100%;
        height: 100%;
      }
      ::slotted(svg) {
        pointer-events: none;
        display: block;
        width: 100%;
        height: 100%;
        fill: currentColor;
        stroke: none;
      }
    `],Ua([oi(),Na("design:type",String)],Va.prototype,"icon",void 0),Va=Ua([ii("cf-icon")],Va);var qa=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Wa=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Ga=class extends Ha{constructor(){super(...arguments),this.disabled=!1,this.mini=!1,this.trailingIcon=!1,this.on=!1,this.noAimation=!1}render(){const e={hasicon:!!this.offIcon,haslabel:!!this.label,trailingicon:!(!this.offIcon||!this.trailingIcon)};return Lt`
    <button 
      aria-label="${this.label||(this.on?this.onIcon:this.offIcon)||""}" 
      aria-pressed="${this.on}"
      ?disabled="${this.disabled}" 
      class="horiz center2 ${Fa(e)}">
      <div id="iconPanel" class="${this.noAimation?"noanimation":""}">
        <cf-icon id="officon" .icon="${this.offIcon}"></cf-icon>
        <cf-icon id="onicon" .icon="${this.onIcon}"></cf-icon>
      </div>
      <span>${this.label}</span>
    </button>
    `}};Ga.styles=[Ha.styles,Aa,Da,it`
      :host {
        display: inline-block;
        vertical-align: top;
        text-transform: uppercase;
        font-size: 14px;
        color: var(--c4-theme-secondary, var(--c4-theme-primary, #6200ee));
      }
      button {
        cursor: pointer;
        outline: none;
        border-radius: 28px;
        overflow: hidden;
        user-select: none;
        position: relative;
        font-family: inherit;
        text-align: center;
        font-size: inherit;
        letter-spacing: 1.25px;
        line-height: 1;
        padding: var(--c4-padding, 16px);
        text-transform: inherit;
        width: 100%;
        background: currentColor;
        border: none;
        color: inherit;
        box-shadow: var(--c4-shadow, 0px 3px 5px -1px rgb(0 0 0 / 20%), 0px 6px 10px 0px rgb(0 0 0 / 14%), 0px 1px 18px 0px rgb(0 0 0 / 12%));
        transition: box-shadow 0.28s ease;
      }
      button > * {
        color: var(--c4-theme-on-secondary, var(--c4-theme-on-primary, white));
      }
      button::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: var(--c4-theme-on-secondary, var(--c4-theme-on-primary, white));
        opacity: 0;
        pointer-events: none;
      }
      button::after {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: var(--c4-theme-on-secondary, var(--c4-theme-on-primary, white));
        opacity: 0;
        pointer-events: none;
        border-radius: 50%;
        transform: scale(0);
        transition: opacity 0.2s cubic-bezier(0.4, 0.0, 0.2, 1), transform 0.4s cubic-bezier(0.4, 0.0, 0.2, 1);
      }
      button:focus::before {
        opacity: 0.1;
      }
      button:active::after {
        opacity: 0.2;
        transform: scale(1);
        transition: opacity 0.28s cubic-bezier(0.4, 0.0, 0.2, 1), transform 0.28s cubic-bezier(0.4, 0.0, 0.2, 1);
      }
      #iconPanel {
        position: relative;
        width: var(--c4-icon-size, 24px);
        height: var(--c4-icon-size, 24px);
        display: none;
      }
      cf-icon {
        width: var(--c4-icon-size, 24px);
        height: var(--c4-icon-size, 24px);
        position: absolute;
        top: 0;
        left: 0;
        opacity: 1;
        pointer-events: none;
        transition: opacity 0.2s cubic-bezier(0.4, 0.0, 0.2, 1), transform 0.4s cubic-bezier(0.4, 0.0, 0.2, 1);
      }
      #iconPanel.noanimation cf-icon {
        transition: initial;
      }
      #onicon {
        opacity: 0;
        transform: rotateZ(-90deg);
      }
      button span {
        display: none;
      }

      button.hasicon #iconPanel {
        display: block;
      }
      button.haslabel {
        padding: var(--c4-padding, 0 20px);
        height: 48px;
      }
      button.haslabel span {
        display: block;
      }
      button.haslabel::after {
        border-radius: 28px;
      }

      :host([mini]) button.hasicon.haslabel,
      button.hasicon.haslabel {
        padding-inline-start: 12px;
      }
      button.hasicon.haslabel #iconPanel {
        margin-inline-end: 12px;
      }
      
      :host([mini]) button.hasicon.haslabel.trailingicon,
      button.hasicon.haslabel.trailingicon {
        padding-inline-start: 20px;
        padding-inline-end: 12px;
      }
      button.hasicon.haslabel.trailingicon #iconPanel {
        margin-inline-end: 0;
        margin-inline-start: 12px;
      }
      button.horiz.trailingicon {
        flex-direction: row-reverse;
      }

      :host([mini]) button {
        padding: var(--c4-padding, 8px);
      }
      :host([mini]) button.haslabel {
        padding: var(--c4-padding, 0 16px);
        height: 40px;
      }

      :host([disabled]) button {
        background-color: var(--c4-disabled-color, rgba(0, 0, 0, 0.12));
        cursor: initial;
        pointer-events: none;
        box-shadow: none;
      }
      :host([disabled]) button > * {
        color: var(--c4-disabled-text-color, rgba(0, 0, 0, 0.38));
      }

      :host([on]) #officon {
        opacity: 0;
        transform: rotateZ(90deg);
      }
      :host([on]) #onicon {
        opacity: 1;
        transform: rotateZ(0deg);
      }

      @media (hover: hover) {
        button:hover::before {
          opacity: 0.05;
        }
        button:focus:hover::before {
          opacity: 0.1;
        }
      }
    `],qa([oi({type:Boolean,reflect:!0}),Wa("design:type",Object)],Ga.prototype,"disabled",void 0),qa([oi({type:Boolean,reflect:!0}),Wa("design:type",Object)],Ga.prototype,"mini",void 0),qa([oi({type:Boolean,attribute:"trailing-icon"}),Wa("design:type",Object)],Ga.prototype,"trailingIcon",void 0),qa([oi({type:Boolean,reflect:!0}),Wa("design:type",Object)],Ga.prototype,"on",void 0),qa([oi({type:String,attribute:"on-icon"}),Wa("design:type",String)],Ga.prototype,"onIcon",void 0),qa([oi({type:String,attribute:"off-icon"}),Wa("design:type",String)],Ga.prototype,"offIcon",void 0),qa([oi({type:Boolean,attribute:"no-animation"}),Wa("design:type",Object)],Ga.prototype,"noAimation",void 0),qa([oi(),Wa("design:type",String)],Ga.prototype,"label",void 0),Ga=qa([ii("navu-fab")],Ga);var Ka=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Ya=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Za=class extends Ha{constructor(){super(...arguments),this.selectors=[],this._selectorMap=new Map,this._bottomOffset=-1,this._topOffset=-1,this._findAttempts=0,this._resizeObserver=new ResizeObserver((()=>{this._scheduleCompute()})),this._mutObserver=new MutationObserver((()=>{this._scheduleCompute()})),this._pendingCompute=!1}render(){return Lt``}firstUpdated(){window.addEventListener("resize",(()=>this._scheduleCompute()),{passive:!0})}updated(){this._refresh()}async _refresh(){this._detach(),this._selectorMap.clear(),this._findAttempts=0,this._attach()}_detach(){for(const e of this._selectorMap.keys()){const t=this._selectorMap.get(e);t&&this._resizeObserver.unobserve(t)}}async _attach(){const{added:e,missed:t}=await this._findSelectors();if(e){this._detach();for(const e of this._selectorMap.keys()){const t=this._selectorMap.get(e);t&&(this._resizeObserver.observe(t),this._mutObserver.observe(t,{attributes:!0}))}}t&&this._findAttempts<5&&setTimeout((()=>{this._findAttempts++,this._attach()}),3e3)}async _findSelectors(){let e=!1,t=!1;const i=this.selectors.filter((e=>!this._selectorMap.has(e)));for(const s of i)try{const i=await gi(s,3e3);i?(this._selectorMap.set(s,i),t=!0):e=!0}catch(t){e=!0}return{added:t,missed:e}}_scheduleCompute(){this._pendingCompute||(this._pendingCompute=!0,setTimeout((()=>{this._pendingCompute=!1,this._compute()}),1e3))}_compute(){let e=0,t=0;for(const i of this._selectorMap.keys()){const s=this._selectorMap.get(i);if(s){const{height:i,top:o}=s.getBoundingClientRect(),n=i>0?Math.min(window.innerHeight-180,Math.max(0,window.innerHeight-o)):0;n>e&&(e=n);const r=i>0&&o+i<window.innerHeight?Math.min(window.innerHeight-180,Math.max(0,o+i)):0;r>t&&(t=r)}}e!==this._bottomOffset&&(this._bottomOffset=e,this._selectorMap.size&&this.fire("bottom-offset",e)),t!==this._topOffset&&(this._topOffset=t,this._selectorMap.size&&this.fire("top-offset",t))}};Za.styles=[it`
      :host {
        display: none;
      }
    `],Ka([ni(),Ya("design:type",Array)],Za.prototype,"selectors",void 0),Za=Ka([ii("adherence-monitor")],Za);var Qa=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Xa=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Ja=class extends Ha{constructor(){super(...arguments),this.selectors=[],this._selectorMap=new Map,this._findAttempts=0,this._intersectionObserver=new IntersectionObserver((()=>{this._scheduleCompute()})),this._mutObserver=new MutationObserver((()=>{this._scheduleCompute()})),this._pendingCompute=!1}render(){return Lt``}firstUpdated(){window.addEventListener("resize",(()=>this._scheduleCompute()),{passive:!0})}updated(){this._refresh()}async _refresh(){this._detach(),this._selectorMap.clear(),this._findAttempts=0,this._attach()}_detach(){for(const e of this._selectorMap.keys()){const t=this._selectorMap.get(e);t&&this._intersectionObserver.unobserve(t)}}async _attach(){const{added:e,missed:t}=await this._findSelectors();if(e){this._detach();for(const e of this._selectorMap.keys()){const t=this._selectorMap.get(e);t&&(this._intersectionObserver.observe(t),this._mutObserver.observe(t,{attributes:!0}))}}t&&this._findAttempts<5&&setTimeout((()=>{this._findAttempts++,this._attach()}),3e3)}async _findSelectors(){let e=!1,t=!1;const i=this.selectors.filter((e=>!this._selectorMap.has(e)));for(const s of i)try{const i=await gi(s,3e3);i?(this._selectorMap.set(s,i),t=!0):e=!0}catch(t){e=!0}return{added:t,missed:e}}_scheduleCompute(){this._pendingCompute||(this._pendingCompute=!0,setTimeout((()=>{this._pendingCompute=!1,this._compute()}),1e3))}_compute(){let e=!1;for(const t of this._selectorMap.keys()){const i=this._selectorMap.get(t);if(i){const{height:t,top:s}=i.getBoundingClientRect();if(t>0&&s>=0&&s<window.innerHeight){e=!0;break}}}e!==this._somethingVisible&&(this._somethingVisible=e,this.fire("visibility-change",e))}};Ja.styles=[it`
      :host {
        display: none;
      }
    `],Qa([ni(),Xa("design:type",Array)],Ja.prototype,"selectors",void 0),Ja=Qa([ii("visibility-monitor")],Ja);var el=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},tl=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let il=class extends Ha{constructor(){super(...arguments),this.type="text",this.disabled=!1,this.dense=!1,this.trailingIcon=!1}render(){const e={solid:"raised"===this.type||"flat"===this.type,icon:!!this.icon,trailingicon:!(!this.icon||!this.trailingIcon)};return Lt`
    <button ?disabled="${this.disabled}" class="horiz center2 ${Fa(e)}">
      ${this.icon?Lt`<cf-icon .icon="${this.icon}"></cf-icon>`:null}
      <slot></slot>
    </button>
    `}focus(){var e;null===(e=this._b)||void 0===e||e.focus()}};il.styles=[Ha.styles,Aa,Da,it`
      :host {
        display: inline-block;
        vertical-align: top;
        text-transform: uppercase;
        font-size: 14px;
        min-width: 64px;
        color: var(--c4-theme-primary, #6200ee);
      }
      button {
        cursor: pointer;
        outline: none;
        border-radius: var(--c4-border-radius, 4px);
        overflow: hidden;
        color: inherit;
        user-select: none;
        position: relative;
        font-family: inherit;
        text-align: center;
        font-size: inherit;
        letter-spacing: 1.25px;
        line-height: 1;
        padding: var(--c4-padding, 0 8px);
        min-height: 36px;
        text-transform: inherit;
        width: 100%;
      }
      button::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: currentColor;
        opacity: 0;
        pointer-events: none;
      }
      button::after {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: currentcolor;
        opacity: 0;
        pointer-events: none;
        transform: scale(0);
        transition: opacity 0.2s cubic-bezier(0.4, 0.0, 0.2, 1), transform 0.4s cubic-bezier(0.4, 0.0, 0.2, 1);
      }
      button:focus::before {
        opacity: 0.1;
      }
      button:active::after {
        opacity: 0.1;
        transform: scale(1);
        transition: opacity 0.28s cubic-bezier(0.4, 0.0, 0.2, 1), transform 0.28s cubic-bezier(0.4, 0.0, 0.2, 1);
      }
      cf-icon {
        width: var(--c4-icon-size, 18px);
        height: var(--c4-icon-size, 18px);
        margin-inline-end: var(--c4-button-icon-end-margin, 8px);
        flex-shrink: 0;
      }
      button.horiz.trailingicon {
        flex-direction: row-reverse;
      }
      button.trailingicon cf-icon {
        margin-inline-end: 0;
        margin-inline-start: 8px;
      }

      :host([dense]) button {
        min-height: 28px;
      }
      :host([disabled]) button {
        color: var(--c4-disabled-color, rgba(0, 0, 0, 0.38));
        cursor: initial;
        pointer-events: none;
      }

      @media (hover: hover) {
        button:hover::before {
          opacity: 0.05;
        }
        button:focus:hover::before {
          opacity: 0.1;
        }
      }
    `,it`
    :host([type="text"]) button {
      background: none;
      border: none;
    }
    `,it`
    :host([type="outlined"]) button {
      background: none;
      border: 1px solid;
      padding: var(--c4-padding, 0 16px);
      border-color: var(--c4-outline-color, rgba(0, 0, 0, 0.12));
    }
    :host([type="outlined"]) button.icon {
      padding-inline-start: 12px;
    }
    :host([type="outlined"]) button.icon.trailingicon {
      padding-inline-start: 16px;
      padding-inline-end: 12px;
    }
    :host([type="outlined"]) button:focus {
      border-color: var(--c4-outline-focussed-color, currentColor);
    }
    `,it`
    button.solid {
      background: currentColor;
      border: none;
      padding: var(--c4-padding, 0 16px);
      box-shadow: 0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12);
      transition: box-shadow 0.3s cubic-bezier(0.4, 0.0, 0.2, 1);
    }
    button.solid.icon {
      padding-inline-start: var(--c4-button-icon-start-padding, 12px);
    }
    button.solid.icon.trailingicon {
      padding-inline-start: 16px;
      padding-inline-end: 12px;
    }
    button.solid > * {
      color: var(--c4-theme-on-primary, white);
    }
    button.solid::before {
      background: var(--c4-theme-on-primary, white);
    }
    button.solid::after {
      background: var(--c4-theme-on-primary, white);
    }
    button.solid:focus::before {
      opacity: 0.2;
    }
    button.solid:active::after {
      opacity: 0.2;
    }
    button.solid:active {
      box-shadow: 0 6px 10px 0 rgba(0, 0, 0, 0.14), 0 1px 18px 0 rgba(0, 0, 0, 0.12), 0 3px 5px -1px rgba(0, 0, 0, 0.4);
    }
    :host([disabled]) button.solid {
      background-color: var(--c4-disabled-color, rgba(0, 0, 0, 0.12));
      box-shadow: none;
    }
    :host([disabled]) button.solid > *{
      color: var(--c4-disabled-text-color, rgba(0, 0, 0, 0.38));
    }

    @media (hover: hover) {
      button.solid:hover::before {
        opacity: 0.1;
      }
      button.solid:focus:hover::before {
        opacity: 0.2;
      }
    }
    `,it`
    :host([type="flat"]) button.solid {
      box-shadow: none;
    }
    :host([type="flat"]) button.solid:active {
      box-shadow: none;
    }
    `],el([oi({reflect:!0}),tl("design:type",String)],il.prototype,"type",void 0),el([oi({type:Boolean,reflect:!0}),tl("design:type",Object)],il.prototype,"disabled",void 0),el([oi({type:Boolean,reflect:!0}),tl("design:type",Object)],il.prototype,"dense",void 0),el([oi(),tl("design:type",String)],il.prototype,"icon",void 0),el([oi({type:Boolean,attribute:"trailing-icon"}),tl("design:type",Object)],il.prototype,"trailingIcon",void 0),el([ai("button"),tl("design:type",HTMLButtonElement)],il.prototype,"_b",void 0),il=el([ii("cf-button")],il);var sl=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},ol=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let nl=class extends Ha{constructor(){super(...arguments),this.disabled=!1,this.mini=!1}render(){return Lt`
    <button aria-label="${this.label||this.icon||""}" ?disabled="${this.disabled}">
      <cf-icon .icon="${this.icon}"></cf-icon>
    </button>
    `}};nl.styles=[Ha.styles,it`
      :host {
        display: inline-block;
        vertical-align: top;
      }
      button {
        background: none;
        cursor: pointer;
        outline: none;
        border: none;
        border-radius: 50%;
        overflow: hidden;
        padding: var(--c4-padding, 12px);
        color: inherit;
        user-select: none;
        position: relative;
        display: block;
      }
      button::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: currentColor;
        opacity: 0;
        pointer-events: none;
      }
      button::after {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: currentcolor;
        opacity: 0;
        pointer-events: none;
        border-radius: 50%;
        transform: scale(0);
        transition: opacity 0.2s cubic-bezier(0.4, 0.0, 0.2, 1), transform 0.4s cubic-bezier(0.4, 0.0, 0.2, 1);
      }
      button:focus::before {
        opacity: 0.2;
      }
      button:active::after {
        opacity: 0.2;
        transform: scale(1);
        transition: opacity 0.28s cubic-bezier(0.4, 0.0, 0.2, 1), transform 0.28s cubic-bezier(0.4, 0.0, 0.2, 1);
      }
      cf-icon {
        width: var(--c4-icon-size, 24px);
        height: var(--c4-icon-size, 24px);
      }

      :host([mini]) button {
        padding: var(--c4-padding, 8px);
      }

      :host([disabled]) button {
        color: var(--c4-disabled-color, rgba(0, 0, 0, 0.38));
        cursor: initial;
        pointer-events: none;
      }

      @media (hover: hover) {
        button:hover::before {
          opacity: 0.1;
        }
        button:focus:hover::before {
          opacity: 0.2;
        }
      }
    `],sl([oi({type:Boolean,reflect:!0}),ol("design:type",Object)],nl.prototype,"disabled",void 0),sl([oi({type:Boolean,reflect:!0}),ol("design:type",Object)],nl.prototype,"mini",void 0),sl([oi(),ol("design:type",String)],nl.prototype,"icon",void 0),sl([oi(),ol("design:type",String)],nl.prototype,"label",void 0),nl=sl([ii("cf-icon-button")],nl);var rl=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},al=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const ll="journey-guide";let cl=class extends Ha{constructor(){super(...arguments),this.corner="bottom-left",this._viewState="closed",this._suggestions=[],this._noSuggestions=!1,this._openType="user",this._suggestionSeenSet=new Set,this._userHasTypedSomething=!1,this._pointerOutTimer=0,this._triggered=!1,this._triggerElements=[],this._scrollPositionTriggerAttached=!1,this._windowLeaveListenerAttached=!1,this._scrollingUp=!1,this._lastScrollOffset=0,this._scrollChange=0,this._idleTimer=0,this._activityListener=()=>{this._startIdleTimer()},this._scrollPositionInZone=!1,this._scrollPositionListener=()=>{var e,t;const i=window.scrollY,s=null===(e=this._settings)||void 0===e?void 0:e.triggerScrollDepthPercent;if(s){if(document.body.scrollHeight||document.documentElement.scrollHeight||0){const e=(i+window.innerHeight)/document.body.scrollHeight*100>=s;e!==this._scrollPositionInZone&&(this._scrollPositionInZone=e,e&&this._show("trigger"))}}if(!(null===(t=this._settings)||void 0===t?void 0:t.noTriggerOnReverseScroll)){const e=i-this._lastScrollOffset;this._lastScrollOffset=i;const t=e<0;t===this._scrollingUp?this._scrollChange+=Math.abs(e):(this._scrollingUp=t,this._scrollChange=Math.abs(e)),this._triggered||this._scrollingUp&&this._scrollChange>=.4*window.innerHeight&&this._show("trigger")}},this._windowLeaveListener=e=>{(e.clientY<=0||e.clientX<=0||e.clientX>=window.innerWidth||e.clientY>=window.innerHeight)&&this._show("trigger")}}set settings(e){this._settings=e,this.corner=e.position||"bottom-left"}render(){var e,t,i,s;return Lt`
    <div id="container" class="${this._viewState}"  @mouseenter="${this._handleMouseEnter}" @mouseleave="${this._handleMouseLeave}">
      <div id="fabPanel">
        <navu-fab .on="${"closed"!==this._viewState}" off-icon="navigation" on-icon="near-me" @click="${this._onFabClick}"></navu-fab>
      </div>
      <div id="cardPanel">
        ${this._suggestions.map(((e,t)=>Lt`
          <div id="card${t}" class="card ${this._noSuggestions?"no-suggestions":""}" data-id="${e.id}" style="--navu-guide-cell-transition-delay: ${.15*t}s">
            <a href="${e.url}" @click="${t=>this._suggestionClick(t,e)}">
              <cf-button type="raised" .icon="${e.icon}">
                <div class="vert button-innner">
                  ${e.caption?Lt`<div class="cardCaption">${e.caption}</div>`:null}
                  <div class="cardLabel">${e.text}</div>
                </div>
              </cf-button>
            </a>
          </div>
        `))}
      </div>
    </div>
    
    ${"adhere"===(null===(e=this._settings)||void 0===e?void 0:e.linkToBehavior)?Lt`
    <adherence-monitor 
      .selectors="${(null===(t=this._settings)||void 0===t?void 0:t.linkedSelectors)||[]}" 
      @bottom-offset=${this._linkedBottomOffsetChange}
      @top-offset=${this._linkedTopOffsetChange}>
    </adherence-monitor>
    `:null}

    ${"hide-when-visible"===(null===(i=this._settings)||void 0===i?void 0:i.linkToBehavior)?Lt`
    <visibility-monitor 
      .selectors="${(null===(s=this._settings)||void 0===s?void 0:s.linkedSelectors)||[]}"
      @visibility-change=${this._linkedVisibilityChange}>
    </visibility-monitor>
    `:null}
    
    `}firstUpdated(){Ze.currentSession?this._refresh():e.subscribe("session-established",(()=>{this._refresh()})),e.subscribe("search-panel-closed",(()=>{this._settings&&this._startIdleTimer()})),document.querySelectorAll("input").forEach((e=>{e.addEventListener("input",(()=>{this._userHasTypedSomething=!0}))}))}_refresh(){const e=Ze.currentSession;if(this._suggestionSeenSet.clear(),this._viewState="closed",e){this._suggestions=[];for(const t of e.suggestions||[])"standard"===t.type&&this._suggestions.push(t);this._noSuggestions=!this._suggestions.length,this._suggestions.push({text:this._noSuggestions?"Search":"More...",icon:"search",id:"___more___",type:"standard",url:""}),this._startIdleTimer()}}updated(e){var t;if(e.has("_settings")&&this._settings)switch(this._attachScrollElementTriggers(),this._attachScrollPositionTrigger(),this._attachWindowLeaveListener(),this._settings.linkToBehavior){case"adhere":this._settings.minLinkedItemHeight&&(null===(t=this._settings.linkedSelectors)||void 0===t?void 0:t.length)?this._setContainerOffset(this._settings.minLinkedItemHeight):this._setContainerOffset(null);break;case"hide-when-visible":this.style.display="none"}}_setContainerOffset(e){var t;const i=null===(t=this._settings)||void 0===t?void 0:t.position;if(e&&i)switch(i){case"bottom-left":case"bottom-right":this.style.setProperty("--internal-navu-container-transform",`translateY(-${e}px)`);break;case"top-left":case"top-right":this.style.setProperty("--internal-navu-container-transform",`translateY(${e}px)`);break;case"none":this.style.removeProperty("--internal-navu-container-transform")}else this.style.removeProperty("--internal-navu-container-transform")}_show(e){switch(e){case"trigger":if(this._noSuggestions||this._triggered||this._userHasTypedSomething)return;this._viewState="short";break;case"user":this._viewState="long"}this._triggered=!0;for(let e=0;e<("long"===this._viewState?this._suggestions.length:1);e++)this._reportSugesstionImpression(this._suggestions[e])}_hide(){this._viewState="closed"}_cancelPointerTimer(){this._pointerOutTimer&&(window.clearTimeout(this._pointerOutTimer),this._pointerOutTimer=0)}_isHoverable(){const e=window.matchMedia&&window.matchMedia("(hover: hover)");return e&&e.matches}_handleMouseEnter(){this._isHoverable()&&(this._cancelPointerTimer(),"long"!==this._viewState&&this._show("user"))}_handleMouseLeave(){this._isHoverable()&&(this._cancelPointerTimer(),"closed"!==this._viewState&&(this._pointerOutTimer=window.setTimeout((()=>{"closed"!==this._viewState&&"user"===this._openType&&this._hide(),this._pointerOutTimer=0}),2e3)))}_onFabClick(){"closed"!==this._viewState?this._hide():this._show("user")}async _suggestionClick(e,t){const i=e.shiftKey||e.metaKey||e.ctrlKey;e.stopPropagation();let s=!1;i||(e.preventDefault(),s=!0),t.url&&await Ze.widgetAction(ll,"nav",0,t.url,void 0,{suggestionId:t.id}),s&&t.url?window.location.assign(t.url):"___more___"===t.id&&this._openSearch()}_openSearch(){this._hide(),Ze.widgetAction(ll,"open-search",0),Ze.goto("search");const e=document.querySelector("slick-search-panel");e&&e._focus&&e._focus()}_reportSugesstionImpression(e){if(e&&!this._suggestionSeenSet.has(e.id)){const t={suggestionId:e.id};Ze.widgetAction(ll,"impression",0,void 0,void 0,t),this._suggestionSeenSet.add(e.id)}}_stopIdleTimer(){this._idleTimer&&(window.clearTimeout(this._idleTimer),this._idleTimer=0),document.removeEventListener("click",this._activityListener),window.removeEventListener("scroll",this._activityListener)}_startIdleTimer(){if(this._stopIdleTimer(),this._settings){const e=1e3*(this._settings.triggerIdleDelayInSecs||10);this._idleTimer=window.setTimeout((()=>{this._show("trigger")}),e),document.addEventListener("click",this._activityListener,{passive:!0}),window.addEventListener("scroll",this._activityListener,{passive:!0})}}_detachScrollElementTriggers(){this._triggerObserver&&this._triggerElements.forEach((e=>{var t;return null===(t=this._triggerObserver)||void 0===t?void 0:t.unobserve(e)})),this._triggerElements=[]}async _attachScrollElementTriggers(){var e;this._detachScrollElementTriggers();const t=(null===(e=this._settings)||void 0===e?void 0:e.triggerSelectorsInView)||[];if(t.length&&"IntersectionObserver"in window){this._triggerObserver||(this._triggerObserver=new IntersectionObserver((e=>{let t=!1;for(const i of e)if(i.intersectionRatio>.1){t=!0;break}t&&this._show("trigger")}),{threshold:[0,.1,.5,1]})),this._triggerElements=[];for(const e of t)try{const t=await gi(e,2e3);t&&this._triggerElements.push(t)}catch(e){}this._triggerElements.forEach((e=>{var t;return null===(t=this._triggerObserver)||void 0===t?void 0:t.observe(e)}))}}_attachScrollPositionTrigger(){this._settings&&void 0===this._settings.triggerScrollDepthPercent&&(this._settings.triggerScrollDepthPercent=80),this._scrollPositionTriggerAttached||(this._scrollPositionInZone=!1,window.addEventListener("scroll",this._scrollPositionListener,{passive:!0}),this._scrollPositionTriggerAttached=!0)}_attachWindowLeaveListener(){if(this._settings){!this._settings.noTriggerOnMouseOut?this._windowLeaveListenerAttached||(document.addEventListener("mouseleave",this._windowLeaveListener),this._windowLeaveListenerAttached=!0):(document.removeEventListener("mouseleave",this._windowLeaveListener),this._windowLeaveListenerAttached=!1)}}_linkedBottomOffsetChange(e){var t,i;const s=null===(t=this._settings)||void 0===t?void 0:t.position;if(s)switch(s){case"bottom-left":case"bottom-right":{let t=e.detail||0;(null===(i=this._settings)||void 0===i?void 0:i.minLinkedItemHeight)&&(t=Math.max(t,this._settings.minLinkedItemHeight)),this._setContainerOffset(t);break}}else this._setContainerOffset(null)}_linkedTopOffsetChange(e){var t,i;const s=null===(t=this._settings)||void 0===t?void 0:t.position;if(s)switch(s){case"top-left":case"top-right":{let t=e.detail||0;(null===(i=this._settings)||void 0===i?void 0:i.minLinkedItemHeight)&&(t=Math.max(t,this._settings.minLinkedItemHeight)),this._setContainerOffset(t);break}}else this._setContainerOffset(null)}_linkedVisibilityChange(e){const t=!!e.detail;this.style.display=t?"none":""}};cl.styles=[Ha.styles,Da,it`
    :host {
      display: block;
      position: fixed;
      bottom: var(--navu-guide-vert-offset, 0);
      left: var(--navu-guide-horiz-offset, 0);
    }

    #container {
      transform: var(--internal-navu-container-transform);
      transition: transform 0.18s ease;
    }

    #fabPanel {
      padding: var(--navu-guide-fab-padding, 16px);
      border-radius: 50%;
    }
    navu-fab {
      --c4-padding: 10px;
      --c4-shadow: none;
      --c4-theme-on-secondary: var(--navu-guide-highlight, var(--slick-site-color, #0277BD));
      --c4-theme-secondary: var(--navu-guide-fab-bg, rgba(255,255,255,0.7));
      transform: scale(0.7);
      transition: transform 0.18s ease;
      border: var(--navu-guide-fab-border);
      border-radius: 50%;
    }
    #cardPanel {
      position: absolute;
      left: 100%;
      left: calc(100% + 8px);
      bottom: 16px;
      width: 280px;
      pointer-events: none;
      opacity: 0;
      align-items: start;
      gap: 10px;
      display: flex;
      flex-direction: column-reverse;
    }
    .card {
      cursor: pointer;
      border-radius: 4px;
      user-select: none;
      text-align: left;
      letter-spacing: 0.5px;
      white-space: nowrap;
      pointer-events: none;
      transform: translateY(100%);
      opacity: 0;
      position: relative;
      --c4-theme-primary: var(--navu-guide-button-bg, var(--navu-guide-highlight, var(--slick-site-color, #0277BD)));
      --c4-padding: 12px 16px;
      transition: opacity 0.3s ease-out, transform 0.28s ease-out;
    }
    #card0::before {
      content: "";
      position: absolute;
      top: -7px;
      left: 0;
      width: 100%;
      height: 100%;
      border-radius: 4px;
      background-color: var(--navu-guide-button-bg, var(--navu-guide-highlight, var(--slick-site-color, #a2c7e0)));
      box-shadow: rgb(0 0 0 / 20%) 0px 3px 5px -1px, rgb(0 0 0 / 14%) 0px 6px 10px 0px, rgb(0 0 0 / 12%) 0px 1px 18px 0px;
      transform: scaleX(0.92);
      transition: opacity 0.2s ease;
      opacity: 0.4;
    }
    #card0.no-suggestions::before {
      display: none;
    }
    #card0.card {
      transform-origin: left center;
      z-index: 1;
      transform: translateX(-32px) scale(0);
    }
    .button-innner {
      text-align: left;
      text-transform: initial;
      letter-spacing: 0.5px;
      white-space: initial;
    }
    .cardCaption {
      text-transform: uppercase;
      font-size: 12px;
      opacity: 0.7;
      padding-bottom: 8px;
      letter-spacing: 1px;
      font-weight: 300;
    }
    .cardLabel {
      line-height: 1.5;
      max-height: calc(var(--navu-guide-cta-lines, 2) * 1.5em);
      -webkit-line-clamp: var(--navu-guide-cta-lines, 2);
      -webkit-box-orient: vertical;
      display: -webkit-box;
      -webkit-hyphens: var(--navu-guide-cta-hyphens, auto);
      -moz-hyphens: var(--navu-guide-cta-hyphens, auto);
      overflow: hidden;
      hyphens: var(--navu-guide-cta-hyphens, auto);
    }

    .short navu-fab,
    .long navu-fab {
      transform: scale(1);
      --c4-theme-secondary: var(--navu-guide-fab-select-bg, var(--navu-guide-highlight, var(--slick-site-color, #0277BD)));
      --c4-theme-on-secondary: var(--navu-guide-fab-select-fg,  #ffffff);
      --c4-shadow: 0px 3px 5px -1px rgb(0 0 0 / 20%), 0px 6px 10px 0px rgb(0 0 0 / 14%), 0px 1px 18px 0px rgb(0 0 0 / 12%);
      border: var(--navu-guide-fab-select-border);
    }
    .long #cardPanel,
    .short #cardPanel {
      pointer-events: auto;
      opacity: 1;
    }
    .long #card0.card,
    .short #card0.card {
      transform: translateX(0) scale(1) !important;
      opacity: 1;
      pointer-events: auto;
    }
    .long #card0::before {
      opacity: 0;
    }
    .long .card {
      opacity: 1;
      pointer-events: auto;
      transform: translateY(0) !important;
      transition-delay: var(--navu-guide-cell-transition-delay, 0);
    }
    `,it`
    :host([corner="bottom-right"]) {
      left: initial;
      right: var(--navu-guide-horiz-offset, 0);
    }
    :host([corner="bottom-right"]) #cardPanel {
      left: initial;
      right: 100%;
      right: calc(100% + 8px);
      align-items: end;
    }
    :host([corner="bottom-right"]) #card0.card {
      transform-origin: right center;
      transform: translateX(32px) scale(0);
    }
    `,it`
    :host([corner="top-left"]) {
      bottom: initial;
      top: var(--navu-guide-vert-offset, 0);
    }
    :host([corner="top-left"]) #cardPanel {
      bottom: initial;
      top: 16px;
      flex-direction: column;
    }
    :host([corner="top-left"]) .card {
      transform: translateY(-100%);
    }
    :host([corner="top-left"]) #card0::before {
      top: initial;
      bottom: -7px;
    }
    `,it`
    :host([corner="top-right"]) {
      bottom: initial;
      top: var(--navu-guide-vert-offset, 0);
      left: initial;
      right: var(--navu-guide-horiz-offset, 0);
    }
    :host([corner="top-right"]) #cardPanel {
      bottom: initial;
      top: 16px;
      flex-direction: column;
      left: initial;
      right: 100%;
      right: calc(100% + 8px);
      align-items: end;
    }
    :host([corner="top-right"]) #card0.card {
      transform-origin: right center;
      transform: translateX(32px) scale(0);
    }
    :host([corner="top-right"]) .card {
      transform: translateY(-100%);
    }
    :host([corner="top-right"]) #card0::before {
      top: initial;
      bottom: -7px;
    }
    `,it`
    @media (hover: none) {
      .card {
        display: none;
      }
      #card0.card {
        display: block;
      }
      #card0::before {
        display: none;
      }
      .card[data-id="___more___"] {
        display: block;
      }
    }
    `],rl([oi({reflect:!0}),al("design:type",String)],cl.prototype,"corner",void 0),rl([ni(),al("design:type",Object)],cl.prototype,"_settings",void 0),rl([ni(),al("design:type",String)],cl.prototype,"_viewState",void 0),rl([ni(),al("design:type",Array)],cl.prototype,"_suggestions",void 0),rl([ni(),al("design:type",Object)],cl.prototype,"_noSuggestions",void 0),cl=rl([ii("navu-guide")],cl);var hl=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},dl=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};const pl="journey-guide";let ul=class extends Ha{constructor(){super(...arguments),this.position="top",this._suggestions=[],this._hidden=!1,this._showing=!1,this._suggestionSeenSet=new Set,this._triggerElements=[],this._scrollPositionTriggerAttached=!1,this._windowLeaveListenerAttached=!1,this._scrollingUp=!1,this._lastScrollOffset=0,this._scrollChange=0,this._idleTimer=0,this._activityListener=()=>{this._startIdleTimer()},this._scrollPositionInZone=!1,this._scrollPositionListener=()=>{var e,t;const i=window.scrollY,s=null===(e=this.settings)||void 0===e?void 0:e.triggerScrollDepthPercent;if(s){if(document.body.scrollHeight||document.documentElement.scrollHeight||0){const e=(i+window.innerHeight)/document.body.scrollHeight*100>=s;e!==this._scrollPositionInZone&&(this._scrollPositionInZone=e,e&&this._show())}}const o=i-this._lastScrollOffset;this._lastScrollOffset=i;const n=o<0;n===this._scrollingUp?this._scrollChange+=Math.abs(o):(this._scrollingUp=n,this._scrollChange=Math.abs(o));switch((null===(t=this.settings)||void 0===t?void 0:t.bannerScrollDirection)||"scroll-up"){case"default":this._show();break;case"scroll-up":n?this._scrollChange>50&&this._show():this._scrollChange>20&&this._hide()}},this._windowLeaveListener=e=>{(e.clientY<=0||e.clientX<=0||e.clientX>=window.innerWidth||e.clientY>=window.innerHeight)&&this._show()}}set settings(e){this._settings=e,this.position=(null==e?void 0:e.bannerPosition)||"top"}get settings(){return this._settings}render(){var e,t,i,s;const o=this._suggestions[0],n=((null==o?void 0:o.caption)||"").trim(),r=((null==o?void 0:o.text)||"").trim();return Lt`
    <div id="container" class="horiz center ${this._showing?"showing":""}" ?hidden="${this._hidden||!this._suggestions.length}">
      <div id="messagePanel" class="flex">
        <div id="messageInner">
          <span id="caption" ?hidden="${!n}">${n}:</span>
          <a 
            id="message" 
            href="${(null==o?void 0:o.url)||""}"
            @click="${e=>this._suggestionClick(e,o)}">
              ${r}
          </a>
        </div>
      </div>
      <cf-icon-button icon="search" @click="${this._openSearch}"></cf-icon-button>
    </div>

    ${"adhere"===(null===(e=this.settings)||void 0===e?void 0:e.linkToBehavior)?Lt`
    <adherence-monitor 
      .selectors="${(null===(t=this.settings)||void 0===t?void 0:t.linkedSelectors)||[]}" 
      @bottom-offset=${this._linkedBottomOffsetChange}
      @top-offset=${this._linkedTopOffsetChange}>
    </adherence-monitor>
    `:null}

    ${"hide-when-visible"===(null===(i=this.settings)||void 0===i?void 0:i.linkToBehavior)?Lt`
    <visibility-monitor 
      .selectors="${(null===(s=this.settings)||void 0===s?void 0:s.linkedSelectors)||[]}"
      @visibility-change=${this._linkedVisibilityChange}>
    </visibility-monitor>
    `:null}
    `}_show(){this._showing||(this._showing=!0,this.style.transform="translateY(0px)",this._suggestions.length&&this._reportSugesstionImpression(this._suggestions[0]),document.body.classList.add("navu-suggestion-bar-showing"))}_hide(){this._showing&&(this.style.transform="",this._showing=!1,document.body.classList.remove("navu-suggestion-bar-showing"))}firstUpdated(){Ze.currentSession?this._refresh():e.subscribe("session-established",(()=>{this._refresh()})),e.subscribe("search-panel-closed",(()=>{this._hidden=!1,this.settings&&this._startIdleTimer()}))}_refresh(){const e=Ze.currentSession;if(this._suggestionSeenSet.clear(),e){this._suggestions=[];for(const t of e.suggestions||[])"standard"===t.type&&this._suggestions.push(t);this._startIdleTimer()}}updated(e){e.has("_settings")&&this.settings&&(this._attachScrollElementTriggers(),this._attachScrollPositionTrigger(),this._attachWindowLeaveListener())}async _suggestionClick(e,t){const i=e.shiftKey||e.metaKey||e.ctrlKey;e.stopPropagation();let s=!1;i||(e.preventDefault(),s=!0),t.url&&await Ze.widgetAction(pl,"nav",0,t.url,void 0,{suggestionId:t.id}),s&&t.url&&window.location.assign(t.url)}_openSearch(){this._hidden=!0,Ze.widgetAction(pl,"open-search",0),Ze.goto("search");const e=document.querySelector("slick-search-panel");e&&e._focus&&e._focus()}_reportSugesstionImpression(e){if(e&&!this._suggestionSeenSet.has(e.id)){const t={suggestionId:e.id};Ze.widgetAction(pl,"impression",0,void 0,void 0,t),this._suggestionSeenSet.add(e.id)}}_stopIdleTimer(){this._idleTimer&&(window.clearTimeout(this._idleTimer),this._idleTimer=0),document.removeEventListener("click",this._activityListener),window.removeEventListener("scroll",this._activityListener)}_startIdleTimer(){if(this._stopIdleTimer(),this.settings){const e=1e3*(this.settings.triggerIdleDelayInSecs||10);this._idleTimer=window.setTimeout((()=>{this._show()}),e),document.addEventListener("click",this._activityListener,{passive:!0}),window.addEventListener("scroll",this._activityListener,{passive:!0})}}_detachScrollElementTriggers(){this._triggerObserver&&this._triggerElements.forEach((e=>{var t;return null===(t=this._triggerObserver)||void 0===t?void 0:t.unobserve(e)})),this._triggerElements=[]}async _attachScrollElementTriggers(){var e;this._detachScrollElementTriggers();const t=(null===(e=this.settings)||void 0===e?void 0:e.triggerSelectorsInView)||[];if(t.length&&"IntersectionObserver"in window){this._triggerObserver||(this._triggerObserver=new IntersectionObserver((e=>{let t=!1;for(const i of e)if(i.intersectionRatio>.1){t=!0;break}t&&this._show()}),{threshold:[0,.1,.5,1]})),this._triggerElements=[];for(const e of t)try{const t=await gi(e,2e3);t&&this._triggerElements.push(t)}catch(e){}this._triggerElements.forEach((e=>{var t;return null===(t=this._triggerObserver)||void 0===t?void 0:t.observe(e)}))}}_attachScrollPositionTrigger(){this.settings&&void 0===this.settings.triggerScrollDepthPercent&&(this.settings.triggerScrollDepthPercent=80),this._scrollPositionTriggerAttached||(this._scrollPositionInZone=!1,window.addEventListener("scroll",this._scrollPositionListener,{passive:!0}),this._scrollPositionTriggerAttached=!0)}_attachWindowLeaveListener(){if(this.settings){!this.settings.noTriggerOnMouseOut?this._windowLeaveListenerAttached||(document.addEventListener("mouseleave",this._windowLeaveListener),this._windowLeaveListenerAttached=!0):(document.removeEventListener("mouseleave",this._windowLeaveListener),this._windowLeaveListenerAttached=!1)}}_linkedBottomOffsetChange(e){var t,i;const s=null===(t=this.settings)||void 0===t?void 0:t.bannerPosition;if(s)switch(s){case"bottom":{let t=e.detail||0;(null===(i=this.settings)||void 0===i?void 0:i.minLinkedItemHeight)&&(t=Math.max(t,this.settings.minLinkedItemHeight)),this._setContainerOffset(t);break}}else this._setContainerOffset(null)}_linkedTopOffsetChange(e){var t,i;const s=null===(t=this.settings)||void 0===t?void 0:t.bannerPosition;if(s)switch(s){case"top":{let t=e.detail||0;(null===(i=this.settings)||void 0===i?void 0:i.minLinkedItemHeight)&&(t=Math.max(t,this.settings.minLinkedItemHeight)),this._setContainerOffset(t);break}}else this._setContainerOffset(null)}_linkedVisibilityChange(e){const t=!!e.detail;this.style.display=t?"none":""}_setContainerOffset(e){var t;const i=null===(t=this.settings)||void 0===t?void 0:t.bannerPosition;if(e&&i)switch(i){case"bottom":this.style.setProperty("--internal-navu-container-transform",`translateY(-${e}px)`);break;case"top":this.style.setProperty("--internal-navu-container-transform",`translateY(${e}px)`);break;case"none":this.style.removeProperty("--internal-navu-container-transform")}else this.style.removeProperty("--internal-navu-container-transform")}};ul.styles=[Ha.styles,Da,it`
    :host {
      display: block;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      font-size: 14px;
      font-weight: 400;
      line-height: 1;
      pointer-events: none;
      height: 44px;
      transform: translateY(-110%);
      transition: transform 0.3s ease;
    }
    :host([position="bottom"]) {
      top: initial;
      bottom: 0;
      transform: translateY(110%);
    }
    #container {
      height: 44px;
      background-color: var(--navu-guide-bar-bg, var(--slick-site-color, #0277BD));
      color: var(--navu-guide-bar-fg, #ffffff);
      padding: 0 6px 0 16px;
      opacity: 0;
      transform: var(--internal-navu-container-transform);
      transition: opacity 0.18s ease, transform 0.18s ease;
    }
    #container.showing {
      opacity: 1;
      pointer-events: auto;
    }
    cf-icon-button {
      --c4-padding: 8px;
    }
    #messagePanel {
      position: relative;
      height: 100%;
    }
    #messageInner {
      position: absolute;
      top: 0;
      left: 0px;
      width: 100%;
      line-height: 44px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    #caption {
      text-transform: uppercase;
      font-size: 12px;
      opacity: 0.7;
      padding-right: 8px;
      letter-spacing: 1px;
      font-weight: 300;
      display: inline-block;
    }
    a, a:hover, a:visited {
      color: inherit;
      text-decoration: none;
      outline: none;
      border: none;
      cursor: pointer;
    }

    @media (max-width: 600px) {
    }
    `],hl([oi({reflect:!0}),dl("design:type",String)],ul.prototype,"position",void 0),hl([ni(),dl("design:type",Object)],ul.prototype,"_settings",void 0),hl([ni(),dl("design:type",Array)],ul.prototype,"_suggestions",void 0),hl([ni(),dl("design:type",Object)],ul.prototype,"_hidden",void 0),hl([ni(),dl("design:type",Object)],ul.prototype,"_showing",void 0),ul=hl([ii("navu-guide-bar")],ul);const gl="highlighter-is-highlighting",fl="slick-highlighter-active";class vl{constructor(){"IntersectionObserver"in window&&(this._observer=new IntersectionObserver((e=>{if(this._state){const{intersectionRatio:t}=e[0];t>=.6?this._state.active?this._state.seen||this._highlight():this._unhighlight():this._state.seen?t<.6&&this._unhighlight():this._state.active=!0}}),{threshold:[0,.25,.75,1]}))}detach(){this._observer&&this._state&&(this._observer.unobserve(this._state.element),this._state=void 0)}async attach(e){this.detach(),this._settings=e;const t=await this.findElement(e);t&&e===this._settings&&this._observer&&(this._state={element:t,active:!1,seen:!1,timeout:e.durationInSecs||5},this._observer.observe(t))}async findElement(e){if(!e.selectors.length)return null;for(let t=0;t<30;t++){if(this._settings!==e)return null;let t=null;for(const i of e.selectors)try{const e=document.querySelector(i);if(e){t=e;break}}catch(e){t=null}if(t)return t;await X(1e3)}return null}_unhighlight(){this._state&&(document.body.classList.remove(fl),this._state.element.classList.remove(gl),this._state.element.style.zIndex=this._cachedZ||"",this._state.element.style.position=this._cachedPosition||"",this._backPanel&&(this._backPanel.style.opacity="0",setTimeout((()=>{this._backPanel&&(this._backPanel.style.display="none")}),410)),this._state.seen=!0,this.detach())}_highlight(){if(this._state&&!this._state.seen){if(!this._backPanel){this._backPanel=document.createElement("div"),document.body.appendChild(this._backPanel);const e=this._backPanel.style;e.position="fixed",e.opacity="0",e.top="0",e.left="0",e.width="100%",e.height="100%",e.zIndex="var(--highlight-backdrop-zindex, 999)",e.backgroundColor="var(--highlight-backdrop-color, rgba(0,0,0,0.6))",e.transition="opacity 0.4s ease",this._backPanel.addEventListener("click",(()=>this._unhighlight()))}this._backPanel.style.display="block",this._backPanel.style.opacity="0",this._cachedZ=this._state.element.style.zIndex,this._cachedPosition=this._state.element.style.position,this._state.element.style.zIndex="var(--highlight-element-zindex, 999999)",this._state.element.style.position="var(--highlight-element-position, relative)",this._state.element.classList.add(gl),this._state.seen=!0,document.body.classList.add(fl),this._backPanel.getBoundingClientRect(),this._backPanel.style.opacity="1",this._state.timeout&&window.setTimeout((()=>{this._unhighlight()}),1e3*this._state.timeout)}}}const ml="slick-film-strip",yl="slick-game-panel",bl="slick-story-viewer-panel",wl="slick-content-grid",xl="slick-story-carousel",kl="slick-story-explorer",Sl="slick-inline-search-panel",_l="slick-content-slot",Cl="slick-search-box",$l="slick-search-box-input";var Pl=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Il=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Tl=class extends Ha{render(){if(!this.settings)return Lt``;const e=this.settings.backgroundImageUrl?`background-image: url("${this.settings.backgroundImageUrl}");`:"display: none;",t=this.settings.dialogImageUrl?`background-image: url("${this.settings.dialogImageUrl}");`:"display: none;";return Lt`
    <div id="bufferPanel">
    </div>
    <div id="imagePanel" style="${e}"></div>
    <div id="container">
      <div id="innerContainer" class="horiz center2">
        <div id="mainPanel">
          <div id="lockPanel" class="horiz center2" style="${t}"></div>
          <div id="message">${this.settings.message||Ze.phrase("exclusive-content-sign-in-cta")}</div>
          <div id="buttonBar">
            <cf-button type="raised" @click="${this._signIn}">${Ze.phrase("sign-in")}</cf-button>
          </div>
        </div>
      </div>
    </div>
    
    `}_signIn(){const e=this.membershipSettings;(null==e?void 0:e.redirectSignInToUrl)?window.location.assign(e.redirectSignInToUrl):Ze.membershipService.memberSignin(void 0,void 0,!0,(()=>{this.fire("sign-in")}))}};Tl.styles=[Ha.styles,it`
    :host {
      display: block;
      margin: 32px 0;
      font-size: 18px;
      position: relative;
    }
    #bufferPanel {
      background: var(--slick-exclusive-panel-buffer-bg, #fafafa);
      height: 200vh;
      height: 180vh + max(70vh, 600px);
    }
    #container {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
    }
    #innerContainer {
      padding: 32px 16px;
      min-height: max(70vh, 600px);
      position: sticky;
      top: 0px;
    }
    #imagePanel {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 80vh;
      height: max(70vh, 600px);
      pointer-events: none;
      background-color: transparent;
      background-size: cover;
      background-origin: border-box;
      background-position: 50% 50%;
      background-repeat: no-repeat;
      -webkit-filter: var(--slick-exclusive-panel-bg-filter, blur(10px));
      filter: var(--slick-exclusive-panel-bg-filter, blur(10px));
    }
    #mainPanel {
      background-color: var(--slick-exclusive-panel-overlay-bg, white);
      color: var(--slick-exclusive-panel-overlay-color, #242424);
      padding: 76px 20px 32px;
      text-align: center;
      border-radius: 10px;
      box-shadow: 0 11px 15px -7px rgba(0,0,0,.2), 0 24px 38px 3px rgba(0,0,0,.14), 0 9px 46px 8px rgba(0,0,0,.12);
      position: relative;
    }
    #buttonBar {
      margin-top: 24px;
      --c4-theme-primary: var(--slick-exclusive-panel-button-color, var(--slick-site-color)); 
    }
    #lockPanel {
      border-radius: 50%;
      color: var(--slick-exclusive-panel-overlay-bg, white);
      border: 5px solid;
      width: 120px;
      height: 120px;
      background-color: transparent;
      background-size: cover;
      background-origin: border-box;
      background-position: 50% 50%;
      background-repeat: no-repeat;
      position: absolute;
      left: 50%;
      top: 0px;
      transform: translate3d(-50%, -50%, 0px);
      overflow: hidden;
    }
    cf-button {
      --c4-padding: 16px;
      width: 100%;
      max-width: 350px;
    }
    `],Pl([ni(),Il("design:type",Object)],Tl.prototype,"membershipSettings",void 0),Pl([ni(),Il("design:type",Object)],Tl.prototype,"settings",void 0),Tl=Pl([ii("slick-exclusive-panel")],Tl);class Ol{constructor(t,i){this._dirty=!1,this._processing=!1,this._map=new Map,this._membershipSettings=t,this._settings=i,this._subToken=e.subscribe("membership-status-changed",(()=>{this._refresh()})),Ze.currentSession?this._refresh():e.subscribe("session-established",(()=>{this._refresh()}))}get settings(){return this._settings}updateMembership(e){this._membershipSettings=e,this._panel&&(this._panel.membershipSettings=e)}detach(){this._clear(),e.unsubscribe("membership-status-changed",this._subToken)}async _refresh(){this._processing?this._dirty=!0:(this._processing=!0,this._dirty=!1,await this._resetState(),this._processing=!1,this._dirty&&this._refresh())}async _resetState(){let e=!1;const t=Ze.currentSession;if(t&&(e=!(!t.identity.name&&!t.identity.email)),e)return void this._clear();if(this._map.size)return;const i=[];for(const e of this._settings.hideSelectors||[]){const t=await vi(e,2e3);t&&i.push(...t)}const{hideStartSelector:s,hideEndSelector:o}=this._settings;let n=null,r=null;try{n=s?await gi(s,2e3):null}catch(e){O("exclusive-service","error","_resetState failed to find startNode",e)}try{r=o?await gi(o,2e3):null}catch(e){O("exclusive-service","error","_resetState failed to find endNode",e)}if(n&&r){const e=n.parentElement;if(e&&e===r.parentElement){i.push(n);let e=n;for(;e.nextElementSibling&&e.nextElementSibling!==e&&(e=e.nextElementSibling,i.push(e),e!==r););}}else if(n){i.push(n);let e=n;for(;e.nextElementSibling&&e.nextElementSibling!==e;)e=e.nextElementSibling,i.push(e)}else if(r){i.push(r);let e=r;for(;e.previousElementSibling&&e.previousElementSibling!==e;)e=e.previousElementSibling,i.push(e)}this._clear(),i.length&&(this._injectPanel(i[0]),this._hide(i),Ze.notifyContentHidden())}_injectPanel(e){const t=e.parentElement;t&&(this._panel||(this._panel=new Tl,this._panel.addEventListener("sign-in",(()=>{this._refresh()}))),this._panel.settings=this._settings,this._panel.membershipSettings=this._membershipSettings,t.insertBefore(this._panel,e))}_clear(){this._panel&&this._panel.parentElement&&this._panel.parentElement.removeChild(this._panel);for(const e of this._map.keys()){const t=this._map.get(e);if(t){const i=t.parentNode;i&&(i.insertBefore(e,t),i.removeChild(t))}}this._map.clear()}_hide(e){for(let t=0;t<e.length;t++){const i=e[t],s=i.parentElement;if(s){const e=document.createComment(`slick-exclusive-hidden-${t+1}`);s.insertBefore(e,i),s.removeChild(i),this._map.set(i,e)}}}}class Rl{constructor(){this._pendingMembershipCallbacks=[]}_navigateToSSO(e,t){if(e.ssoAuthenticationUrl){const i=new URL(e.ssoAuthenticationUrl),s=new URL(window.location.href);if(t){const e=J(s.href)||{};e[Ye]=`${t}`,s.search=ee(e)}const o={};return o.return=s.href,o.site=Ze.siteCode,i.search=ee(o),window.location.assign(i.href),!0}return!1}async memberSignin(e,t,i,s){var o;const n=null===(o=Ze.currentSession)||void 0===o?void 0:o.settings.membership;if(n&&Ze.currentSession){const o=await B();await o.deleteLastSearch();const r="mandatory-membership"===n.behavior&&e;if(n.useSSO&&n.ssoAuthenticationUrl&&!r&&this._navigateToSSO(n))return;if(n.redirectSignInToUrl)return void window.location.assign(n.redirectSignInToUrl);this._membershipDialog||(this._membershipDialog=new to,this._membershipDialog.addEventListener("update",(()=>this._resolveMembershipCallbacks())),this._membershipDialog.addEventListener("sso",(()=>{this._navigateToSSO(n,e)}))),s&&this._pendingMembershipCallbacks.push(s),this._membershipDialog.membershipSettings=n,this._membershipDialog.pageToHeart=e,this._membershipDialog.defaultEmail=t,this._membershipDialog.exclusive=i||!1,this._membershipDialog.sso=!i&&!(!n.useSSO||!n.ssoAuthenticationUrl),this._membershipDialog.show()}}_resolveMembershipCallbacks(){for(;this._pendingMembershipCallbacks.length;){const e=this._pendingMembershipCallbacks.shift();if(e)try{e()}catch(e){}}}}const El=new class{constructor(){this.epoch=0,this.stories=[],this.storyContainers=[],this.games=[],this.gameContainers=[],this.contentGrids=[],this.contentGridContainers=[],this.contentGridSettings=[],this.inlineSearches=[],this.inlineSearchContainers=[],this.inlineSearchSettings=[],this.searchBoxes=[],this.storyCarousels=[],this.storyCarouselContainers=[],this.contentSlots=[]}async loadWidgets(e){if(this.pendingLoad)try{await Promise.resolve(this.pendingLoad)}catch(e){}this.pendingLoad=this._loadWidgets(e),await Promise.resolve(this.pendingLoad),this.pendingLoad=void 0}unloadWidgets(){this.removeAll()}removeAll(){var e,t,i,s,o,n,r,a,l,c,h;null===(e=this.cssStyleNode)||void 0===e||e.remove(),null===(t=this.toolbarNode)||void 0===t||t.remove(),null===(i=this.heartbeatNode)||void 0===i||i.remove(),null===(s=this._guideNode)||void 0===s||s.remove(),null===(o=this._guideBarNode)||void 0===o||o.remove(),this.contentGrids.forEach((e=>e.remove())),this.contentGridContainers.forEach((e=>e.remove())),this.searchBoxes.forEach((e=>e.remove())),this.inlineSearches.forEach((e=>e.remove())),this.inlineSearchContainers.forEach((e=>e.remove())),this.storyCarousels.forEach((e=>e.remove())),this.storyCarouselContainers.forEach((e=>e.remove())),this.games.forEach((e=>e.remove())),this.gameContainers.forEach((e=>e.remove())),this.storyContainers.forEach((e=>e.remove())),this.contentSlots.forEach((e=>e.remove)),null===(n=this.searchHook)||void 0===n||n.detach(),null===(r=this.favoritesHook)||void 0===r||r.detach(),null===(a=this.storyExplorer)||void 0===a||a.remove(),null===(l=this.filmStrip)||void 0===l||l.remove(),null===(c=this.filmStripContainer)||void 0===c||c.remove(),this.searchNode&&(this.searchNode.closePanel(),this.searchNode.remove()),this.searchPanel&&(this.searchPanel.close(),this.searchPanel.remove()),null===(h=this.snackbar)||void 0===h||h.remove(),this.cssStyleNode=void 0,this.toolbarNode=void 0,this.heartbeatNode=void 0,this._guideNode=void 0,this._guideBarNode=void 0,this.searchNode=void 0,this.searchPanel=void 0,this.snackbar=void 0,this.filmStrip=void 0,this.filmStripContainer=void 0,this.contentGrids=[],this.contentGridContainers=[],this.games=[],this.gameContainers=[],this.storyContainers=[],this.storyCarousels=[],this.storyCarouselContainers=[],this.storyExplorer=void 0,this.cachedStoryCarouselSettings=void 0,this.contentGridSettings=[],this.inlineSearchContainers=[],this.inlineSearches=[],this.inlineSearchSettings=[],this.contentSlots=[],this.searchBoxes=[],this._highlighter&&(this._highlighter.detach(),this._highlighter=void 0),this._detachExclusiveContentService()}async _loadWidgets(e){if(this.epoch=Date.now(),this.injectCSS(e),this.injectFilmstrip(e),this.injectFilmstripToolbar(e),this.injectHeartbeat(e),this.injectSearch(e),this.injectSearchHooks(e),this.injectFavoritesHooks(e),this.injectContentGrids(e),this.injectInlineSearch(e),this.injectSearchBoxes(e),this.injectGames(e),this.injectStories(e),this.injectStoryCarousels(e),this.injectStoryExplorer(e),this.injectContentSlots(e),this.injectGuide(e),this.injectHighlighter(e),this._attachExclusiveContentService(e),this.injectSnackbar(e),Ze.membershipService=new Rl,!window.firstWidgetRenderedTimestamp){const e=performance.now();window.firstWidgetRenderedTimestamp=e,Ze.notifyWidgetsRendered(e)}}_detachExclusiveContentService(){this._exclusiveService&&(this._exclusiveService.detach(),this._exclusiveService=void 0)}_attachExclusiveContentService(e){const t=e.exclusiveContent;if(t){if(this._exclusiveService&&JSON.stringify(t)===JSON.stringify(this._exclusiveService.settings||{}))return void this._exclusiveService.updateMembership(e.membership);this._detachExclusiveContentService(),this._exclusiveService=new Ol(e.membership,t)}else this._detachExclusiveContentService()}injectHighlighter(e){e.highlight?(this._highlighter||(this._highlighter=new vl),this._highlighter.attach(e.highlight)):this._highlighter&&(this._highlighter.detach(),this._highlighter=void 0)}injectSnackbar(e){e.discovery?this.snackbar||(this.snackbar=new _a,document.body.appendChild(this._createComment("Slickstream snackbar")),document.body.appendChild(this.snackbar)):this.snackbar&&this.snackbar.remove()}injectSearch(e){if(!e.discovery)return this.searchNode&&(this.searchNode.closePanel(),this.searchNode.remove(),this.searchNode=void 0),void(this.searchPanel&&(this.searchPanel.close(),this.searchPanel.remove(),this.searchPanel=void 0));if("search4"===e.searchType)if(this.searchNode&&(this.searchNode.closePanel(),this.searchNode.remove(),this.searchNode=void 0),this.searchPanel)this.searchPanel.settings=e;else{if(this.searchPanel=new ur,this.searchPanel.settings=e,e.adInjection&&e.adInjection.enableAdsInSearch){const t=e.adInjection.searchSlotClassNames.join(" ").trim();this.searchPanel.innerHTML=`\n            <div id="slickSearchAdSlot1" class="slick-search-ad-slot" slot="search-slot-1"><div class="${t}"></div></div>\n            <div id="slickSearchAdSlot2" class="slick-search-ad-slot" slot="search-slot-2"><div class="${t}"></div></div>\n            <div id="slickSearchAdSlot3" class="slick-search-ad-slot" slot="search-slot-3"><div class="${t}"></div></div>\n            <div id="slickSearchAdSlot4" class="slick-search-ad-slot" slot="search-slot-4"><div class="${t}"></div></div>\n          `}document.body.appendChild(this._createComment("Search added by Slickstream")),document.body.appendChild(this.searchPanel)}else if(this.searchPanel&&(this.searchPanel.close(),this.searchPanel.remove(),this.searchPanel=void 0),this.searchNode)this.searchNode.settings=e;else{if(this.searchNode=new Ko,this.searchNode.settings=e,e.adInjection&&e.adInjection.enableAdsInSearch){const t=e.adInjection.searchSlotClassNames.join(" ").trim();this.searchNode.innerHTML=`\n            <div id="slickSearchAdSlot1" class="slick-search-ad-slot" slot="search-slot-1"><div class="${t}"></div></div>\n            <div id="slickSearchAdSlot2" class="slick-search-ad-slot" slot="search-slot-2"><div class="${t}"></div></div>\n            <div id="slickSearchAdSlot3" class="slick-search-ad-slot" slot="search-slot-3"><div class="${t}"></div></div>\n            <div id="slickSearchAdSlot4" class="slick-search-ad-slot" slot="search-slot-4"><div class="${t}"></div></div>\n          `}document.body.appendChild(this._createComment("Search added by Slickstream")),document.body.appendChild(this.searchNode)}}injectGuide(e){const t=()=>{this._guideNode&&(this._guideNode.remove(),this._guideNode=void 0)},i=()=>{this._guideBarNode&&(this._guideBarNode.remove(),this._guideBarNode=void 0)},s=e.journeyGuide;if(s)switch(s.type){case"banner":t(),"none"===s.bannerPosition?i():this._guideBarNode?this._guideBarNode.settings=s:(this._guideBarNode=new ul,this._guideBarNode.settings=s,document.body.appendChild(this._createComment("Journey Guide added by Navu")),document.body.appendChild(this._guideBarNode));break;case"floating":i(),"none"===s.position?t():this._guideNode?this._guideNode.settings=s:(this._guideNode=new cl,this._guideNode.settings=s,document.body.appendChild(this._createComment("Journey Guide added by Navu")),document.body.appendChild(this._guideNode))}else t(),i()}injectHeartbeat(e){var t;const i=e.heartbeat;let s=!(!i||"none"===i.showFavoriteButton&&"none"===i.showSearchButton);s||(s=!(!e.backToTop||"none"===e.backToTop.showButton)),this.heartbeatNode?s?(this.heartbeatNode.config=i,this.heartbeatNode.membership=e.membership,this.heartbeatNode.iconSettings=e.heartbeatIcon,this.heartbeatNode.bttSettings=e.backToTop):null===(t=this.heartbeatNode.parentElement)||void 0===t||t.removeChild(this.heartbeatNode):s&&(this.heartbeatNode=new Dr,this.heartbeatNode.config=i,this.heartbeatNode.membership=e.membership,this.heartbeatNode.iconSettings=e.heartbeatIcon,this.heartbeatNode.bttSettings=e.backToTop,document.body.appendChild(this._createComment("Favorites and Search added by Slickstream")),document.body.appendChild(this.heartbeatNode))}injectFilmstripToolbar(e){var t;const i=e.filmstripToolbar&&"do-not-inject"!==e.filmstripToolbar.injection;this.toolbarNode?i?this.toolbarNode.config=e.filmstripToolbar:null===(t=this.toolbarNode.parentElement)||void 0===t||t.removeChild(this.toolbarNode):i&&(this.toolbarNode=new us,this.toolbarNode.config=e.filmstripToolbar,document.body.appendChild(this._createComment("Filmstrip toolbar added by Slickstream")),document.body.appendChild(this.toolbarNode))}injectCSS(e){const t=(e.css||"").trim();if(this.cssStyleNode){if(this.cssStyleNode.innerHTML.trim()===t)return;this.cssStyleNode.parentElement&&(this.cssStyleNode.parentElement.removeChild(this.cssStyleNode),this.cssStyleNode=void 0)}t&&(this.cssStyleNode=this.injectCSSNode(t))}_createComment(e){return document.createComment(e)}injectCSSNode(e){const t=document.createElement("style");return t.innerHTML=e,document.body.appendChild(this._createComment("The following style block was added by Slickstream")),document.body.appendChild(t),t}async injectFilmstrip(e){var t,i,s;const o=e.filmstrip;if(!o||"do-not-inject"===o.injection)return null===(t=this.filmStrip)||void 0===t||t.remove(),null===(i=this.filmStripContainer)||void 0===i||i.remove(),this.filmStrip=void 0,void(this.filmStripContainer=void 0);const n=this.epoch;if(this.filmStrip)return this.filmStrip.searchEnabled=o.includeSearch,this.filmStrip.mode=o.mode||"og-card",void(o.thumbnailSize&&(this.filmStrip.thumbnailSize=o.thumbnailSize));let r=document.querySelector(`.${ml}`);if(r)null===(s=this.filmStripContainer)||void 0===s||s.remove(),this.filmStripContainer=void 0;else if(o.selector&&(r=(await this.injectContainerPanel(o.selector,o.position||"after selector",ml,!1))[0]||null,r)){if(this.filmStripContainer=r,n!==this.epoch)return this.filmStripContainer.remove(),void(this.filmStripContainer=void 0);o.cssIfInjected&&this.injectCSSNode(o.cssIfInjected)}if(r){const e=await this.injectFilmStripComponent(o);e?this.filmStrip=e:O("widget-manager","error","Failed to inject filmstrip in the provided container")}}async injectContainerPanel(e,t,i,s){const o=[];try{const n=s?await vi(e,5e3):[await gi(e,5e3)];if(n&&n.length)for(const e of n){const s=document.createElement("div");switch(s.classList.add(i),t){case"after selector":e.insertAdjacentElement("afterend",s);break;case"before selector":e.insertAdjacentElement("beforebegin",s);break;case"first child of selector":e.insertAdjacentElement("afterbegin",s);break;case"last child of selector":e.insertAdjacentElement("beforeend",s)}o.push(s)}}catch(t){O("widget-manager","error",`Failed to inject ${i} for selector ${e}`)}return o}async injectFilmStripComponent(e){try{const t=`.${ml}`,i=await gi(t,3e4);if(i){const t=new ls;return t.topLevelWidget=!0,t.searchEnabled=e.includeSearch,t.mode=e.mode||"og-card",t.containment=e.imageContainment||"cover",e.thumbnailSize&&(t.thumbnailSize=e.thumbnailSize),i.appendChild(this._createComment("Filmstrip added by Slickstream")),i.appendChild(t),t}}catch(e){O("widget-manager","error","Failed to inject filmstrip. Selector nor found")}return null}async injectStories(e){const t=this.epoch,i=e.storyViewer,s=i&&"auto-inject"===i.injection;if(i&&s){if(!this.stories.length){if(i.selector&&(this.storyContainers=await this.injectContainerPanel(i.selector,i.position||"after selector",bl,!0)),t!==this.epoch)return void this.storyContainers.forEach((e=>{var t;return null===(t=e.parentElement)||void 0===t?void 0:t.removeChild(e)}));this.stories=[],this.storyContainers.forEach((e=>{const t=new ra;t.config=i,e.appendChild(t),this.stories.push(t)}))}}else this.stories.forEach((e=>{var t;return null===(t=e.parentElement)||void 0===t?void 0:t.removeChild(e)})),this.storyContainers.forEach((e=>{var t;return null===(t=e.parentElement)||void 0===t?void 0:t.removeChild(e)}))}async injectStoryExplorer(e){const t=this.epoch;if(e.storyExplorer&&"do-not-inject"===e.storyExplorer.injection&&this.storyExplorer)return void this.storyExplorer.remove();if(this.storyExplorer)return void(e.storyExplorer&&"auto-inject"===e.storyExplorer.injection&&(this.storyExplorer.innerHTML=e.storyExplorer.titleHtml||""));if(e.storyExplorer&&"auto-inject"===e.storyExplorer.injection&&e.storyExplorer.selector){const t=await this.injectContainerPanel(e.storyExplorer.selector,e.storyExplorer.position||"after selector",kl,!1);e.storyExplorer.titleHtml&&t.forEach((t=>{var i;return t.dataset.titleHtml=null===(i=e.storyExplorer)||void 0===i?void 0:i.titleHtml}))}let i=null;try{i=await gi(`.${kl}`,3e4)}catch(e){return}t===this.epoch&&i&&(this.storyExplorer=new xa,i.dataset.titleHtml&&(this.storyExplorer.innerHTML=i.dataset.titleHtml),this.storyExplorer.settings=e,i.appendChild(this._createComment("Story Explorer added by Slickstream")),i.appendChild(this.storyExplorer))}async injectContentGridComponents(e){const t=e.contentGrids||[],i=[];try{const s=`.${wl}`,o=await vi(s,3e4);if(o&&o.length)for(const s of o){for(;s.hasChildNodes()&&s.lastChild;)s.removeChild(s.lastChild);let o=null;const n=s.dataset.config;if(n)for(const e of t)if(e.id===n){o=e;break}o||(o=t[0]),o||(o={injection:"auto-inject"});const r=new qr;r.settings=e,r.config=o,o.titleHtml&&(r.innerHTML=o.titleHtml.trim()),s.appendChild(this._createComment("Content Grid added by Slickstream")),s.appendChild(r),i.push(r)}}catch(e){O("widget-manager","error","Failed to inject content grid. Selector nor found")}return i}async injectContentGrids(e){const t=()=>{this.contentGrids.forEach((e=>{var t;return null===(t=e.parentElement)||void 0===t?void 0:t.removeChild(e)})),this.contentGridContainers.forEach((e=>{var t;return null===(t=e.parentElement)||void 0===t?void 0:t.removeChild(e)})),this.contentGrids=[],this.contentGridContainers=[]};if(e.noContentGrids)return void t();const i=this.epoch,s=e.contentGrids||[];if(this.contentGrids.length){if(JSON.stringify(s)===JSON.stringify(this.contentGridSettings))return void(this.contentGridSettings=s);t()}if(this.contentGridSettings=s,s.length){for(const e of s)switch(e.injection){case"do-not-inject":break;case"auto-inject":if(e.selector){const t=await this.injectContainerPanel(e.selector,e.position||"after selector",wl,!1);if(t&&i!==this.epoch)return void t.forEach((e=>{var t;return null===(t=e.parentElement)||void 0===t?void 0:t.removeChild(e)}));t&&t.length&&(t.forEach((t=>t.dataset.config=e.id)),this.contentGridContainers.push(...t))}}this.contentGrids=await this.injectContentGridComponents(e)}else 0===this.contentGrids.length&&(this.contentGrids=await this.injectContentGridComponents(e))}async injectContentSlots(e){const t=e.slots||[];this.contentSlots.forEach((e=>e.remove())),this.contentSlots=[];const i=this.epoch;for(const e of t)switch(e.type){case"simple":{const t=e;if(t.selector){const e=await this.injectContainerPanel(t.selector,t.position||"after selector",_l,!1);if(e){if(i!==this.epoch)return void e.forEach((e=>e.remove()));e.forEach((e=>e.dataset.slot=t.id))}this.contentSlots.push(...e)}break}}Ta||(Ta=new Ia),Ta.refresh()}async injectSearchBoxes(e){var t;if((null===(t=e.searchBox)||void 0===t?void 0:t.enabled)||!1){const t=await vi(`.${Cl}`,0);for(const i of t){let t=i.querySelector("slick-search-box");t||(t=new Sr,i.appendChild(this._createComment("SearchBox added by Slickstream")),i.appendChild(t),this.searchBoxes.push(t)),t.settings=e}const i=await vi(`input.${$l}`,0);for(const t of i){const i=t;if("true"!==i.dataset.slickAttached){const t=new Sr;t.settings=e,t.attachInput(i),i.insertAdjacentElement("afterend",t),i.autocomplete="off",i.dataset.slickAttached="true",this.searchBoxes.push(t)}}}else this.searchBoxes.forEach((e=>e.remove())),this.searchBoxes=[]}async injectInlineSearch(e){const t=()=>{this.inlineSearches.forEach((e=>{var t;return null===(t=e.parentElement)||void 0===t?void 0:t.removeChild(e)})),this.inlineSearchContainers.forEach((e=>{var t;return null===(t=e.parentElement)||void 0===t?void 0:t.removeChild(e)})),this.inlineSearches=[],this.inlineSearchContainers=[]};if(!e.inlineSearches||0===e.inlineSearches.length)return void t();const i=this.epoch,s=e.inlineSearches||[];if(this.inlineSearches.length){if(JSON.stringify(s)===JSON.stringify(this.inlineSearchSettings))return void(this.inlineSearchSettings=s);t()}if(this.inlineSearchSettings=s,s.length)for(const e of s)if("auto-inject"===e.injection){if(!document.querySelector(`.${Sl}[data-config="${e.id}"]`)&&e.selector){const t=await this.injectContainerPanel(e.selector,e.position||"after selector",Sl,!1);if(t&&i!==this.epoch)return void t.forEach((e=>{var t;return null===(t=e.parentElement)||void 0===t?void 0:t.removeChild(e)}));t&&t.length&&(t.forEach((t=>t.dataset.config=e.id)),this.inlineSearchContainers.push(...t))}}this.inlineSearches=await this.injectContentInlineSearchComponents(e)}async injectContentInlineSearchComponents(e){const t=e.inlineSearches||[],i=[];try{const s=await vi(`.${Sl}`,3e4);if(s&&s.length)for(const o of s){let s=null;const n=o.dataset.config;if(n){for(const e of t)if(e.id===n){s=e;break}}else s={id:"_"};if(s){o.innerHTML="";const t=new yr;t.settings=e,t.config=s,s.titleHtml&&(t.innerHTML=s.titleHtml.trim()),o.appendChild(this._createComment("Dynamic content module added by Slickstream")),o.appendChild(t),i.push(t)}}}catch(e){O("widget-manager","error","Failed to inject inline search. Selector not found")}return i}async injectStoryCarousels(e){const t=this.epoch;let i=e.storyCarousel;if(i||(i={injection:"inject-within-container"}),"do-not-inject"!==i.injection){if(this.storyCarousels.length&&this.cachedStoryCarouselSettings){const{injection:e,selector:t,position:s,titleHtml:o}=this.cachedStoryCarouselSettings;if(e===i.injection&&t===i.selector&&s===i.position&&o===i.titleHtml)return;this.storyCarousels.forEach((e=>{var t;return null===(t=e.parentElement)||void 0===t?void 0:t.remove()})),this.storyCarouselContainers.forEach((e=>{var t;return null===(t=e.parentElement)||void 0===t?void 0:t.remove()})),this.storyCarousels=[],this.storyCarouselContainers=[]}switch(this.cachedStoryCarouselSettings=i,i.injection){case"auto-inject":if(i.selector&&(this.storyCarouselContainers=await this.injectContainerPanel(i.selector,i.position||"after selector",xl,!1),i.titleHtml))for(const e of this.storyCarouselContainers)e.dataset.titleHtml=i.titleHtml;if(t!==this.epoch)return void this.storyCarouselContainers.forEach((e=>{var t;return null===(t=e.parentElement)||void 0===t?void 0:t.removeChild(e)}));this.storyCarousels=await this.injectStoryCarouselComponent();break;case"inject-within-container":this.storyCarousels=await this.injectStoryCarouselComponent()}}else this.storyCarousels.forEach((e=>{var t;return null===(t=e.parentElement)||void 0===t?void 0:t.remove()})),this.storyCarouselContainers.forEach((e=>{var t;return null===(t=e.parentElement)||void 0===t?void 0:t.remove()}))}async injectStoryCarouselComponent(){const e=[];try{const t=`.${xl}`,i=await vi(t,3e4);if(i&&i.length)for(const t of i){for(;t.hasChildNodes()&&t.lastChild;)t.removeChild(t.lastChild);const i=new va;t.dataset.titleHtml&&(i.innerHTML=t.dataset.titleHtml),t.appendChild(this._createComment("Story Carousel added by Slickstream")),t.appendChild(i),e.push(i)}}catch(e){console.error(e)}return e}async injectGames(e){const t=this.epoch,i=e.game,s=i&&i.injections&&i.injections.length;if(i&&s){if(!this.games.length)for(const e of i.injections)switch(e.injection){case"do-not-inject":break;case"auto-inject":if(e.selector&&(this.gameContainers=await this.injectContainerPanel(e.selector,e.position||"after selector",yl,!0)),t!==this.epoch)return void this.gameContainers.forEach((e=>{var t;return null===(t=e.parentElement)||void 0===t?void 0:t.removeChild(e)}));this.games=await this.injectGameComponent(i,e);break;case"inject-within-container":this.games=await this.injectGameComponent(i,e)}}else this.games.forEach((e=>{var t;return null===(t=e.parentElement)||void 0===t?void 0:t.removeChild(e)})),this.gameContainers.forEach((e=>{var t;return null===(t=e.parentElement)||void 0===t?void 0:t.removeChild(e)}))}async injectGameComponent(e,t){const i=[];try{const s=`.${yl}`,o=await vi(s,3e4);if(o&&o.length)for(const s of o){for(;s.hasChildNodes()&&s.lastChild;)s.removeChild(s.lastChild);const o=new Ma;o.manifestString=e.manifest||"",o.header=t.header||"",s.appendChild(this._createComment("Game added by Slickstream")),s.appendChild(o),i.push(o)}}catch(e){console.error(e)}return i}injectSearchHooks(e){this.searchHook?e.searchHook?(this.searchHook.config=e.searchHook,this.searchHook.attach()):this.searchHook.detach():e.searchHook&&(this.searchHook=new gr(e.searchHook),this.searchHook.attach())}injectFavoritesHooks(e){this.favoritesHook?e.favoritesHook?(this.favoritesHook.config=e.favoritesHook,this.favoritesHook.attach()):this.favoritesHook.detach():e.favoritesHook&&(this.favoritesHook=new Wr(e.favoritesHook),this.favoritesHook.attach())}};class jl{constructor(t){this._enableInsecure=!1,this.favorites={getState(){var e;const t=Ze.currentSession;return(null===(e=null==t?void 0:t.currentPage)||void 0===e?void 0:e.isFavorite)||!1},async setState(t){var i,s;const o=this.getState(),n=null===(s=null===(i=Ze.currentSession)||void 0===i?void 0:i.currentPage)||void 0===s?void 0:s.id;n&&o!==t&&(t?(Ze.addHearts(1,n),e.dispatch("external-heart-added")):Ze.removeFavorite(n))},getCount(){var e,t;return(null===(t=null===(e=Ze.currentSession)||void 0===e?void 0:e.currentPage)||void 0===t?void 0:t.totalFavorites)||0}},this._enableInsecure=t}get user(){return this._user||(this._user=new Ll(this._enableInsecure)),this._user}}class Ll{constructor(e){this._enableInsecure=!1,this._enableInsecure=e}get name(){var e;return this._enableInsecure?null===(e=Ze.currentSession)||void 0===e?void 0:e.identity.name:void 0}get emailAddress(){var e;return this._enableInsecure?null===(e=Ze.currentSession)||void 0===e?void 0:e.identity.email:void 0}get status(){var e;return(null===(e=Ze.currentSession)||void 0===e?void 0:e.identity.status)||"anonymous"}async signOut(){Ze.currentSession&&await Ze.memberSignout()}openSignInDialog(e){Ze.membershipService.memberSignin(void 0,e)}}function zl(e){document.dispatchEvent(ui(e))}var Ml=function(e,t,i,s){var o,n=arguments.length,r=n<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(e,t,i,s);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(r=(n<3?o(r):n>3?o(t,i,r):o(t,i))||r);return n>3&&r&&Object.defineProperty(t,i,r),r},Al=function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)};let Dl=class extends Ts{constructor(){super(...arguments),this.disabled=!0,this.code=""}render(){return Lt`
    <style>
      :host {
        --soso-highlight-color: var(--slick-discovery-highlight-color);
        font-size: 15px;
      }
      soso-button {
        color: var(--slick-discovery-highlight-color);
      }
      slick-text-input {
        margin-top: 20px;
      }
    </style>
    <soso-dialog-view label="${Ze.phrase("favorites")}">
      <div slot="main" id="form" @input="${this.onInput}">
        <div clas="message">${Ze.phrase("enter-new-password")}</div>
        <slick-text-input id="txtPassword" label="${Ze.phrase("password")}" type="password"></slick-text-input>
      </div>
      <soso-button id="cancelButton" slot="footer" @click="${this.hide}">${Ze.phrase("cancel")}</soso-button>
      <soso-button slot="footer" .disabled="${this.disabled}" @click="${this.submit}">${Ze.phrase("reset-password")}</soso-button>
    </soso-dialog-view>
    `}firstUpdated(){this.resetState()}async beforeShow(){this.resetState()}resetState(){this.clearFields(),this.focus()}clearFields(){this.txtPassword&&(this.txtPassword.value="",this.onInput())}focus(){this.txtPassword&&this.txtPassword.input&&this.txtPassword.input.focus()}onInput(){if(this.txtPassword){const e=this.txtPassword.value.trim();this.disabled=!e}}onEnterKey(){this.submit()}submit(){this.resetPassword()}async resetPassword(){if(this.areInputsValid()&&this.areInputsValid())try{const e=this.txtPassword.value.trim();await Ze.resetPasswordWithCode(this.code,e),this.fireRefreshState()}catch(e){console.error(e),window.alert(e.message||e)}}areInputsValid(){return this.onInput(),!this.disabled}async fireRefreshState(){this.hide(),pi(this,"update")}};Ml([ni(),Al("design:type",Object)],Dl.prototype,"disabled",void 0),Ml([ai("#txtPassword"),Al("design:type",Ns)],Dl.prototype,"txtPassword",void 0),Dl=Ml([ii("slick-password-reset-dialog")],Dl);const Hl={close:"M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z","checkbox-filled":"M19 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.11 0 2-.9 2-2V5c0-1.1-.89-2-2-2zm-9 14l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z","checkbox-unfilled":"M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z","radio-unchecked":"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z","radio-checked":"M12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zm0-5C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z",search:"M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z","chevron-left":"M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z","chevron-right":"M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z",more:"M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z","more-vert":"M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z","more-horiz":"M6 10c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm12 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm-6 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z",back:"M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z",heart:"M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z","heart-outline":"M16.5 3c-1.74 0-3.41.81-4.5 2.09C10.91 3.81 9.24 3 7.5 3 4.42 3 2 5.42 2 8.5c0 3.78 3.4 6.86 8.55 11.54L12 21.35l1.45-1.32C18.6 15.36 22 12.28 22 8.5 22 5.42 19.58 3 16.5 3zm-4.4 15.55l-.1.1-.1-.1C7.14 14.24 4 11.39 4 8.5 4 6.5 5.5 5 7.5 5c1.54 0 3.04.99 3.57 2.36h1.87C13.46 5.99 14.96 5 16.5 5c2 0 3.5 1.5 3.5 3.5 0 2.89-3.14 5.74-7.9 10.05z",star:"M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z","star-outline":"M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z",wine:"M6,3l0,6c0,2.97,2.16,5.43,5,5.91V19H8v2h8v-2h-3v-4.09c2.84-0.48,5-2.94,5-5.91l0-6H6z M16,8H8l0-3h8C16,5,16,8,16,8z","wine-outline":"M6,3l0,6c0,2.97,2.16,5.43,5,5.91V19H8v2h8v-2h-3v-4.09c2.84-0.48,5-2.94,5-5.91V3H6z M12,13c-1.86,0-3.41-1.28-3.86-3h7.72 C15.41,11.72,13.86,13,12,13z M16,8H8l0-3h8L16,8z",custom:"M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z","custom-outline":"M16.5 3c-1.74 0-3.41.81-4.5 2.09C10.91 3.81 9.24 3 7.5 3 4.42 3 2 5.42 2 8.5c0 3.78 3.4 6.86 8.55 11.54L12 21.35l1.45-1.32C18.6 15.36 22 12.28 22 8.5 22 5.42 19.58 3 16.5 3zm-4.4 15.55l-.1.1-.1-.1C7.14 14.24 4 11.39 4 8.5 4 6.5 5.5 5 7.5 5c1.54 0 3.04.99 3.57 2.36h1.87C13.46 5.99 14.96 5 16.5 5c2 0 3.5 1.5 3.5 3.5 0 2.89-3.14 5.74-7.9 10.05z",delete:"M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z",fullscreen:"M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z","fullscreen-exit":"M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z",refresh:"M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z",pause:"M6 19h4V5H6v14zm8-14v14h4V5h-4z",play:"M8 5v14l11-7z",up:"M4 12l1.41 1.41L11 7.83V20h2V7.83l5.58 5.59L20 12l-8-8-8 8z",down:"M20 12l-1.41-1.41L13 16.17V4h-2v12.17l-5.58-5.59L4 12l8 8 8-8z",right:"M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z",left:"M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z",bookmark:"M17 3H7c-1.1 0-1.99.9-1.99 2L5 21l7-3 7 3V5c0-1.1-.9-2-2-2z","bookmark-outline":"M17 3H7c-1.1 0-1.99.9-1.99 2L5 21l7-3 7 3V5c0-1.1-.9-2-2-2zm0 15l-5-2.18L7 18V5h10v13z",pin:"M 14.490234 2.4902344 A 1.0001 1.0001 0 0 0 13.792969 4.2070312 L 14.388672 4.8027344 L 8.1894531 9.7753906 L 7.2070312 8.7929688 A 1.0001 1.0001 0 0 0 6.4902344 8.4902344 A 1.0001 1.0001 0 0 0 5.7929688 10.207031 L 9.09375 13.507812 L 3.2890625 19.310547 C 2.9020625 19.697547 2.9020625 20.323937 3.2890625 20.710938 C 3.6760625 21.097938 4.3024531 21.097938 4.6894531 20.710938 L 10.492188 14.90625 L 13.792969 18.207031 A 1.0001 1.0001 0 1 0 15.207031 16.792969 L 14.310547 15.896484 L 19.214844 9.6289062 L 19.792969 10.207031 A 1.0001 1.0001 0 1 0 21.207031 8.7929688 L 15.207031 2.7929688 A 1.0001 1.0001 0 0 0 14.490234 2.4902344 z","expand-less":"M12 8l-6 6 1.41 1.41L12 10.83l4.59 4.58L18 14z",carousel:"M7 19h10V4H7v15zm-5-2h4V6H2v11zM18 6v11h4V6h-4z","unfold-more":"M12 5.83L15.17 9l1.41-1.41L12 3 7.41 7.59 8.83 9 12 5.83zm0 12.34L8.83 15l-1.41 1.41L12 21l4.59-4.59L15.17 15 12 18.17z","open-panel":"M19 4H5c-1.11 0-2 .9-2 2v12c0 1.1.89 2 2 2h4v-2H5V8h14v10h-4v2h4c1.1 0 2-.9 2-2V6c0-1.1-.89-2-2-2zm-7 6l-4 4h3v6h2v-6h3l-4-4z",navigation:"M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71L12 2z","near-me":"M17.27 6.73l-4.24 10.13-1.32-3.42-.32-.83-.82-.32-3.43-1.33 10.13-4.23M21 3L3 10.53v.98l6.84 2.65L12.48 21h.98L21 3z"};Ai.define(Hl),Ba.define(Hl);const Fl=(window.location.search||"").indexOf("slick-nls")>=0;class Bl{constructor(e){this.sessionSettings=null,this.context=e}async start(){const t=window.location.pathname+(window.location.search||"");e.subscribe("session-established",(()=>this.onSessionEstablished(t))),e.subscribe("session-disabled",(()=>this.unloadUi()));try{const e=await B();if(!Fl){const i=void 0!==this.context.bootData.abTests&&this.context.bootData.abTests.length>0;this.sessionSettings=await e.getSettings(t),Ze.cachedSettings=this.sessionSettings,i||await this.loadUi(),this.sessionSettings&&Ze.startRouter()}e.deleteSettings(t),Ze.start(this.context)}catch(e){O("app","error","Failed to start App",e),console.error(e)}}async onSessionEstablished(t){const i=Ze.currentSession;if(!i)return;this.sessionSettings=i.settings,await this.loadUi();const s=await B();await s.addSettings(t,this.sessionSettings),function(t){const i=window;i.slickstream||(i.slickstream={v1:new jl(t)},e.subscribe("membership-updated",(()=>{zl("slickstream-favorite-change")})),e.subscribe("membership-status-changed",(()=>{zl("slickstream-user-status-change")})),zl("slickstream-ready"))}(this.sessionSettings.enableInsecureClientApiFeatures||!1),ye(i.identity.status),e.subscribe("membership-updated",(e=>{ye(e.identity.status)}));const o=J().slickstream_reset_code;o&&this._resetPassword(o)}async _resetPassword(e){try{const t=await Ze.validateResetPasswordCode(e);if(!t.isValid)return void window.alert(`Failed to reset your password: ${t.errorMessage||"Invalid reset code"}`)}catch(e){console.error(e)}this._passwordResetDialog||(this._passwordResetDialog=new Dl),this._passwordResetDialog.code=e,this._passwordResetDialog.show()}unloadUi(){El.unloadWidgets(),this.bootLoaderCleanup(),yi(),bi()}bootLoaderCleanup(){this.context.bootLoaderCleanup&&this.context.bootLoaderCleanup()}async loadUi(){if(this.sessionSettings){switch(this.sessionSettings.activation||"active"){case"disable":case"no-widgets":this.unloadUi();break;case"active":await El.loadWidgets(this.sessionSettings)}this.bootLoaderCleanup()}}}async function Ul(e){try{const t=e.d;await async function(e,t){const i=Le();await i.resetExpiredBootData(e,t.siteCode)}(e.rt,t),await async function(e){const t=new Set;t.add(e.appUrl),t.add(e.bootUrl);const i=await B(),s=await i.listCachedUrls(),o=Le();for(const e of s)t.has(e)||(await o.removeUrl(e),await i.deleteCachedUrl(e));for(const e of t)await o.addUrlIfNotCached(e),await i.addCachedUrl(e)}(t),function(e){e.ao&&(URL.revokeObjectURL(e.ao),e.ao=void 0),e.bo&&(URL.revokeObjectURL(e.bo),e.bo=void 0)}(e),await U(),await async function(){if("caches"in self)try{await caches.delete("slickstream1")}catch(e){O("url-cache","error","Failed to delete old cache storage",e)}}()}catch(e){O("app-cleanup","error","Error cleaning up boot",e)}}const Nl=window;window.top===window&&(function(){try{const e=new CustomEvent("dummy-event",{bubbles:!0,composed:!0});if(e.composed||e.__composed||e._composed)Nl.SlickCustomEvent=CustomEvent;else{console.warn("Detected CustomEvent polyfill",e,CustomEvent);const t=document.createElement("iframe");t.src="about:blank";const i=t.style;i.border="none",i.width="0px",i.height="0px",i.opacity="0",i.position="absolute",document.body.appendChild(t);const s=t.contentWindow.CustomEvent;document.body.removeChild(t),Nl.SlickCustomEvent=s,Nl.CustomEvent=s}}catch(e){console.warn("Error recovering polyfills in Slick initialization. This is mostly benign.",e)}}(),function(){if(Nl.$slickEmbedded)return;const e=performance.now(),t=Nl.$slickBoot,i={clientType:document.querySelector('meta[name="slick-extension-active"]')?"browser-extension":"embed",embedCodeRoot:t.rt,bootData:t.d,metrics:{appStart:e,bootStart:t._bs,embedStart:t._es,origin:performance.now()||t._es,appFetch:t._af,bootDataFetch:t._bd,bootFetch:t._bf,sessionStart:0},clientVersion:"2.13.34",embedCodeVersion:t.ev,addCurrentPageAsFavorite:t.addCurrentPageAsFavorite||!1,bootLoaderCleanup:t.bootLoaderCleanup,consentStatus:t.consentStatus||"denied",delay:t.delay,device:t.device};!async function(e){const t=window;t.adthrive=t.adthrive||{},t.adthrive.cmd=t.adthrive.cmd||[];const i=document.querySelector('meta[property="slick:wpversion"]'),s=i?i.getAttribute("content"):null;t.adthrive.cmd.push((()=>{t.adthrive.setTargetingFlag("slkappver",[e]),s&&t.adthrive.setTargetingFlag("slkplgver",[s])}))}(i.clientVersion),Nl.$slickEmbedded=!0,new Bl(i).start(),setTimeout((()=>{Ul(t)}),2e3)}())}();

//# sourceURL=browsertools://slickstream/app.js